% use_d_func.m  Call the d_func.m function
input1 = [3, 4]; % Define input parameter as an array
d_func(input1);  % Call d_func function with one input parameter

input2 = [3, 4]; % Define input parameters separately
d_func(input2(1), input2(2)); % Call d_func function with two input parameters

help d_func; % Display comments using help function