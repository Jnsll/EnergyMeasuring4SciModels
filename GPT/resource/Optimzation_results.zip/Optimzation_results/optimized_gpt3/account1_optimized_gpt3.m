% Optimized and refactored Matlab code for energy efficiency

% Clearing workspace
clc; clear; close all;

% Load data
data = xlsread('cumcm2012B����4_ɽ����ͬ������������ʱ���������������ǿ��.xls');
data1 = data(:, 3); % Horizontal total radiation
data2 = data(:, 4); % Horizontal diffuse radiation
data3 = data1 - data2; % Horizontal direct radiation
hpi = 40.1 * pi / 180; % Latitude of Datong

% Constants
n = 1:365;
delta = 23.5 * sin((2 * pi * (284 + n)) / 365) * pi / 180;

% Preallocate arrays
omegat = zeros(1, 365);
omegap = zeros(1, 365);
Rb = zeros(1, 365);
data4 = zeros(365, 1);

% Calculations for south-facing roof
beta = acos(6400 / 6511.53); % Tilt angle
for i = 1:365
    omegap(i) = acos(-tan(hpi) * tan(delta(i)));
    omegat(i) = min(omegap(i), acos(-tan(hpi - beta) * tan(delta(i)));
    Rb(i) = (cos(hpi - beta) * cos(delta(i)) * sin(omegat(i)) + pi / 180 * sin(hpi - beta) * sin(delta(i))) / (cos(hpi) * cos(delta(i)) * sin(omegap(i)) + pi / 180 * omegap(i) * sin(hpi) * sin(delta(i));
end

for i = 1:365
    data4(24 * i - 23:24 * i) = data3(24 * i - 23:24 * i) .* Rb(i) + (1 + cos(beta)) * data2(24 * i - 23:24 * i) / 2 + (1 - cos(beta)) * data1(24 * i - 23:24 * i) / 2 * 0.25;
end

data5 = data4;
data5(data5 < 80) = 0;

% Calculate total solar irradiance on south-facing roof per year per square meter
power1 = sum(data5);

% Constants for south-facing roof
U = 33.6; I = 8.33; % B3 parameters
S = 1.482 * 0.992; % Panel area
m = 36; % Number of solar panels
price1 = m * 12.5 * U * I; % Panel cost
price2 = 15300 * 2; % Inverter cost
g1 = power1 * S * m / 1000 * 0.1598 * 0.94; % Economic benefit

% Calculations for north-facing roof
beta = acos(700 / 1389.24); % Tilt angle
for i = 1:365
    omegap(i) = acos(-tan(hpi) * tan(delta(i)));
    omegat(i) = min(omegap(i), acos(-tan(hpi - beta) * tan(delta(i)));
    Rb(i) = (cos(hpi - beta) * cos(delta(i)) * sin(omegat(i)) + pi / 180 * sin(hpi - beta) * sin(delta(i))) / (cos(hpi) * cos(delta(i)) * sin(omegap(i)) + pi / 180 * omegap(i) * sin(hpi) * sin(delta(i));
end

data4 = zeros(365, 1);
for i = 1:365
    data4(24 * i - 23:24 * i) = data3(24 * i - 23:24 * i) .* Rb(i) + (1 + cos(beta)) * data2(24 * i - 23:24 * i) / 2 + (1 - cos(beta)) * data1(24 * i - 23:24 * i) / 2 * 0.25;
end

data5 = data4;
data5(data5 < 30) = 0;

% Calculate total solar irradiance on north-facing roof per year per square meter
power2 = sum(data5);

% Constants for north-facing roof
n = 9;
U1 = 138; I1 = 1.22; % C1 parameters
S = 1.3 * 1.1; % Panel area
price3 = n * 12.5 * U1 * I1; % Panel cost
price4 = 6900; % Inverter cost
g2 = power2 * S * n * 0.0699 / 1000 * 0.94; % Economic benefit

% Calculate total economic benefit and cost
g = (g1 + g2) * 0.5; % Total annual energy benefit
price = price1 + price2 + price3 + price4; % Total cost
G = g * 10 + g * 15 * 0.9 + g * 10 * 0.8; % Total economic benefit over 35 years

% Display results
disp('35-year total electricity generation:');
disp(G / 0.5);
disp('35-year economic benefit:');
disp(G - price);

% Calculate payback period
disp('Payback period in years:');
if price / g < 10
    nian = price / g;
elseif price / g > 10 && price / g < 25
    nian = (price - g * 10) / (g * 0.9) + 10;
else
    nian = (price - g * 10 - g * 15 * 0.9) / (g * 0.8) + 25;
end
nian