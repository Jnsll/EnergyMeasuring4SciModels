load monks_A2.mat
load monks_T.mat

[N, m] = size(monks_T);

class = 1;

app_size = size(monks_A2);
test_size = size(monks_T);

Napp = app_size(2);
Ntest = test_size(2);

unique_app_class = unique(monks_A2(class,:));
unique_test_class = unique(monks_T(class,:));

ns = max(monks_T');
clear monks_A2 monks_T;