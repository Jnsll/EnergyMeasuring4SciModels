% Optimize Matlab code for energy efficiency

% Debug Flag
DBG = 0;

BrikName = 'ARzs_CW_avvr.DEL+orig.BRIK';

Opt.Format = 'vector';
[~, Vv, Infov, ~] = BrikLoad(BrikName, Opt);

Opt.Format = 'matrix';
[~, Vm, Infom, ~] = BrikLoad(BrikName, Opt);