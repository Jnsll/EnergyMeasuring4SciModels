% Load data
mushroomsD = load('mushrooms.dat');
mushroomsD = mushroomsD';

[N, m] = size(mushroomsD);
class = 1;

% Convert unique values to integers
for node = 1:N
    UNI = unique(mushroomsD(node,:));
    UNI = UNI(UNI ~= -9999);
    for val = 1:length(UNI)
        mushroomsD(node,mushroomsD(node,:) == UNI(val)) = val;
    end
end

% Remove rows with only one value
ns = max(mushroomsD);
seul = find(ns == 1);
mushroomsD = mushroomsD(setdiff(1:N, seul), :);
[N, m] = size(mushroomsD);
ns = max(mushroomsD);

% Split data into training and testing sets
Napp = ceil(m * 2 / 3);
Ntest = m - Napp;

app = mushroomsD(:, 1:Napp);
test = mushroomsD(:, Napp+1:end);

unique(app(class,:));
unique(test(class,:));

clear mushroomsD seul UNI node val