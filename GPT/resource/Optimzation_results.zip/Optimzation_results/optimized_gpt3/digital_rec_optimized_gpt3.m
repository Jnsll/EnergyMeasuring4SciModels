% digital_rec_refactored.m - Optimized for energy efficiency

%% Clear workspace
clear, clc, close all

%% Read data
disp('Start reading images...');
I = getPicData();
disp('Image reading completed')

%% Feature extraction
x0 = zeros(14, 1000);
disp('Start feature extraction...')
parfor i = 1:1000
    tmp = medfilt2(I(:,:,i), [3,3]);
    x0(:,i) = getFeature(tmp)(:);
end

label = 1:10;
label = repmat(label, 100, 1);
label = label(:);
disp('Feature extraction completed')

%% Neural network model creation
tic
spread = 0.1;
[x, se] = mapminmax(x0);
net = newpnn(x, ind2vec(label'));
ti = toc;
fprintf('Network model established in %f sec\n', ti);

%% Testing
lab0 = net(x);
lab = vec2ind(lab0);
rate = sum(label == lab') / length(label);
fprintf('Testing accuracy on training samples\n  %d%%\n', round(rate*100));

%% Testing with noisy images
I1 = I;
nois = 0.2;
fea0 = zeros(14, 1000);
parfor i = 1:1000
    tmp(:,:,i) = I1(:,:,i);
    tmpn(:,:,i) = imnoise(double(tmp(:,:,i)), 'salt & pepper', nois);
    tmpt = medfilt2(tmpn(:,:,i), [3,3]);
    t = getFeature(tmpt);
    fea0(:,i) = t(:);
end

fea = mapminmax('apply', fea0, se);
tlab0 = net(fea);
tlab = vec2ind(tlab0);

rat = sum(tlab' == label) / length(tlab);
fprintf('Testing accuracy on noisy training samples\n  %d%%\n', round(rat*100));

web -broswer http://www.ilovematlab.cn/forum-222-1.html