function [p] = loadPlant_QuadRotor3d()
% Convenience function to load 3d quadcopter.
% Provided to simplify main function and modularize plant model definition.
% Depends:
% - definePropulsionModel.m

% Enviromental params
p.g = -9.81; % Gravity in world coordinates (m/s^2)
p.rho = 1.225; % Air density during flight (kg/m^3)

% Inertial params
p.m = 5;
p.I = [0.625 0 0; 0 0.625 0; 0 0 1.25]; % Inertia tensor coordinates
p.cg = [0 0 0]; % Location of center of gravity (m)

% Control params
p.uMax = 1; % Maximum throttle setting

% Propulsion system params - shared for all motors:
qRP.d_prop = 0.305 * ones(4, 1); % Propeller diameter (m)
qRP.maxThrust = 25 * ones(4, 1); % Thrust at 100% throttle (N)
qRP.maxRPM = 10000 * ones(4, 1); % RPM at 100% throttle (RPM)
qRP.maxTorque = ones(4, 1); % Torque at 100% throttle (Nm)
qRP.thrustLocations = [0.5 0 0; 0 0.5 0; -0.5 0 0; 0 -0.5 0]; % Motor locations
qRP.thrustAxes = repmat([0 0 1], 4, 1); % Thrust axes of each motor
qRP.isSpinDirectionCCW = [1; 0; 1; 0]; % Boolean to reverse motor spin direction
plotflag = 0;
[p.propulsion] = definePropulsionModel(qRP, plotflag);

% Reasoning for optimization:
% 1. Removed unnecessary spaces in variable assignments for better code readability.
% 2. Added comments for better code documentation and understanding.
% 3. Adjusted comments to be concise and informative.
% 4. No specific energy optimization was identified in the provided code snippet.