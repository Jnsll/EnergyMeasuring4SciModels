% Optimize Matlab code for energy efficiency
close all;                  % Close all figure windows, clear workspace variables, clear all workspace variables
clear all;
clc;
I = imread('lenna.bmp'); % Input image
translations = [50, 50; -50, 50; 50, -50; -50, -50]; % Define translation coordinates

% Loop through different translations
for i = 1:size(translations, 1)
    a = translations(i, 1);
    b = translations(i, 2);
    J = move1(I, a, b); % Move the original image
    set(0,'defaultFigurePosition',[100,100,1000,500]); % Modify default figure position settings
    set(0,'defaultFigureColor',[1 1 1]); % Modify default figure background color settings
    figure,
    subplot(1,2,1), imshow(J), axis on; % Display the moved image
    subplot(1,2,2), imshow(J), axis on; % Display the moved image
end