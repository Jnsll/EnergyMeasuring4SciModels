clear;
close all;
clc;

data_g = load('face1.asc');     % Load point set of face1
data_p = rotate(data_g, 60);    % Rotate the point set of face1 upwards by 60 degrees to represent face2
save_3d_data('face2.txt', data_p);

plot_3d_2(data_g, data_p, -90); % Display the two current point sets

[ data_g, data_p, error, data_pp, R ] = icp_process( data_g, data_p );
log_info(strcat('Iteration: 1, Error: ', num2str(error)));
log_info('Current rotation matrix:');
disp(R);

cnt = 1;
last_error = 0;
last_R = R;
% Stop looping when the error converges
while abs(error - last_error) > 0.01
    cnt = cnt + 1;
    last_error = error;
    last_R = R;
    [ data_g, data_p, error, data_pp, R ] = icp_process( data_g, data_p );
    R = last_R * R;
    log_info(strcat('Iteration: ', num2str(cnt), ', Error: ', num2str(error)));
    log_info('Current rotation matrix:');
    disp(R);
end

plot_3d_2(data_g, data_p, -90);