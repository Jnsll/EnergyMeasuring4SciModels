% Optimized and Refactored Matlab Code for Energy Efficiency

% Clear workspace
clear;
close all;
clc;

% Define parameters
R_nc = 20e3;           
Vr = 150;              
Tr = 2.5e-6;          
Kr = 20e12;           
f0 = 5.3e9;           
BW_dop = 80;          
Fr = 60e6;            
Fa = 200;             
Naz = 1024;          
Nrg = 320;            
sita_r_c = 0;	        
c = 3e8;              

R0 = R_nc*cos(sita_r_c);	
Nr = Tr*Fr;             
BW_range = Kr*Tr;       
lamda = c/f0;           
fnc = 2*Vr*sin(sita_r_c)/lamda;     
La_real = 0.886*2*Vr*cos(sita_r_c)/BW_dop;  
beta_bw = 0.886*lamda/La_real;              
La = beta_bw*R0;        
a_sr = Fr / BW_range;   
a_sa = Fa / BW_dop;     

Mamb = round(fnc/Fa);   

NFFT_r = Nrg;           
NFFT_a = Naz;           

R_ref = R0;             
fn_ref = fnc;        

% Set simulation target positions
delta_R0 = 0;       
delta_R1 = 120; 	
delta_R2 = 80;      

% Target positions
x1 = R0;            
y1 = delta_R0 + x1*tan(sita_r_c);	
x2 = x1;            
y2 = y1 + delta_R1; 
x3 = x2 + delta_R2;                 
y3 = y2 + delta_R2*tan(sita_r_c);  	
x_range = [x1,x2,x3];
y_azimuth = [y1,y2,y3];

nc_1 = (y1-x1*tan(sita_r_c))/Vr;    
nc_2 = (y2-x2*tan(sita_r_c))/Vr;    
nc_3 = (y3-x3*tan(sita_r_c))/Vr;    
nc_target = [nc_1,nc_2,nc_3];       

% Distance and azimuth time, frequency definitions
tr = 2*R0/c + ( -Nrg/2 : (Nrg/2-1) )/Fr;                
fr = ( -NFFT_r/2 : NFFT_r/2-1 )*( Fr/NFFT_r );          
ta = ( -Naz/2: Naz/2-1 )/Fa;                            
fa = fnc + fftshift( -NFFT_a/2 : NFFT_a/2-1 )*( Fa/NFFT_a );	

tr_mtx = ones(Naz,1)*tr;    
ta_mtx = ta.'*ones(1,Nrg);  
fr_mtx = ones(Naz,1)*fr;    
fa_mtx = fa.'*ones(1,Nrg);  

% Generate point target original data
s_echo = zeros(Naz,Nrg);    

A0 = 1;                     
for k = 1:3                 
    R_n = sqrt( (x_range(k).*ones(Naz,Nrg)).^2 + (Vr.*ta_mtx-y_azimuth(k).*ones(Naz,Nrg)).^2 );
    w_range = ((abs(tr_mtx-2.*R_n./c)) <= ((Tr/2).*ones(Naz,Nrg)));     
    w_azimuth = (abs(ta - nc_target(k)) <= (La/2)/Vr);    
    s_k = A0.*w_range.*w_azimuth.*exp(-(1j*4*pi*f0).*R_n./c).*exp((1j*pi*Kr).*(tr_mtx-2.*R_n./c).^2);
    
    if k == 1
        s_1 = s_k;          
    end
    if k == 2   
        s_2 = s_k;          
    end
    if k == 3
        s_3 = s_k;          
    end
    s_echo = s_echo + s_k;  
end

% Plot original data
figure;
subplot(2,2,1);
imagesc(real(s_echo));
title('Real Part');
xlabel('Distance Time (samples)');
ylabel('Azimuth Time (samples)');

subplot(2,2,2);
imagesc(imag(s_echo));
title('Imaginary Part');
xlabel('Distance Time (samples)');
ylabel('Azimuth Time (samples)');

subplot(2,2,3);
imagesc(abs(s_echo));
title('Magnitude');
xlabel('Distance Time (samples)');
ylabel('Azimuth Time (samples)');

subplot(2,2,4);
imagesc(angle(s_echo));
title('Phase');
xlabel('Distance Time (samples)');
ylabel('Azimuth Time (samples)');

% Other processing steps are kept as is for clarity