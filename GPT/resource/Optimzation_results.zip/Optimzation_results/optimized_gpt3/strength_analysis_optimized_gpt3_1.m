% Energy-efficient optimization of correlation analysis
clc;
clear;

% Load the data file
data = load('example_2.txt');
n = size(data, 1);

% Normalize data: Ensure the polarity is the same
for i = 1:n
    data(i, :) = data(i, :) / data(i, 1);
end

ck = data(6:n, :);
m1 = size(ck, 1);
bj = data(1:5, :);
m2 = size(bj, 1);

r = zeros(m1, 1); % Preallocate the result matrix for efficiency

for i = 1:m1
    t = zeros(m2, size(data, 2)); % Preallocate temporary matrix t for efficiency
    for j = 1:m2
        t(j, :) = bj(j, :) - ck(i, :);
    end
    jc1 = min(min(abs(t)));
    jc2 = max(max(abs(t)));
    rho = 0.5;
    ksi = (jc1 + rho * jc2) ./ (abs(t) + rho * jc2);
    rt = sum(ksi, 2) / size(ksi, 2);
    r(i) = rt;
end

% Output the correlation analysis result
disp(r);