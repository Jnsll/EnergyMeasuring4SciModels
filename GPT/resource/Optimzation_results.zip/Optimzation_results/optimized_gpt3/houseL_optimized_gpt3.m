% Load data from the file
houseD = load('-ascii', 'house.dat');
houseD = houseD';

[N, m] = size(houseD);

class = 1;

% Randomize the data
rng(0); % Set random seed for reproducibility
houseD = houseD(:, randperm(m));

Napp = ceil(m * 2 / 3);
Ntest = m - Napp;

app = houseD(:, 1:Napp);
disp(size(app));

test = houseD(:, Napp + 1:end);
disp(size(test));

unique(app(class,:));
unique(test(class,:));

ns = max(houseD');