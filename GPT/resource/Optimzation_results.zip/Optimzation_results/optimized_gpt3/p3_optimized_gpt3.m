clc
clear

a1 = imread('000a.bmp');
b = 0:208;
[m, n] = size(a1);
[H, N] = size(b);
a = zeros(m, n, N*2);

for i = 1:N
    if b(i) < 10
        imageName = strcat('00', num2str(b(i)), 'a.bmp');
    elseif b(i) < 100
        imageName = strcat('0', num2str(b(i)), 'a.bmp');
    else
        imageName = strcat(num2str(b(i)), 'a.bmp');
    end
    a(:, :, i) = imread(imageName);
end

for i = 1:N
    if b(i) < 10
        imageName = strcat('00', num2str(b(i)), 'b.bmp');
    elseif b(i) < 100
        imageName = strcat('0', num2str(b(i)), 'b.bmp');
    else
        imageName = strcat(num2str(b(i)), 'b.bmp');
    end
    a(:, :, i + 209) = imread(imageName);
end

tou1 = zeros(11*19*2, 1);
for i = 1:11*19*2
    s = all(a(1:60, :, i) == 255, 'all');
    tou1(i) = sum(s);
end

s = tou1 == 72;
total = sum(s);
ind2 = find(s == 1);