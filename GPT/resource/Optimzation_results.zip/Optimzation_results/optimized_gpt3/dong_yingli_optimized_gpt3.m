clear; clc;

% Load data from Excel file
battery_info = xlsread('cumcm.xls', 'sheet1', 'B1:H24'); % Battery information
inverter_info = xlsread('cumcm.xls', 'sheet2', 'A1:M18'); % Inverter information
generation_data = xlsread('cumcm.xls', 'sheet3', 'B1:F24'); % Generation data
arrangement_info = xlsread('cumcm.xls', 'sheet3', 'A27:D37304'); % Arrangement information

Q = [];
direction = 2; % Direction, eastward as 2
area = 24; % Area of each side
indices_to_remove = [];

for i = 1:size(arrangement_info, 1)
    q = arrangement_info(i, 3) * arrangement_info(i, 4) * generation_data(arrangement_info(i, 2), direction) * inverter_info(arrangement_info(i, 1), 10) * 0.5 * 31.5 - inverter_info(arrangement_info(i, 1), 13) - arrangement_info(i, 3) * arrangement_info(i, 4) * battery_info(arrangement_info(i, 2), 6);
    q_normalized = q / (arrangement_info(i, 3) * arrangement_info(i, 4) * battery_info(arrangement_info(i, 2), 7));
    Q = [Q; arrangement_info(i,:), q, q_, (arrangement_info(i, 3) * arrangement_info(i, 4) * battery_info(arrangement_info(i, 2), 7))];

    if (arrangement_info(i, 3) * arrangement_info(i, 4) * battery_info(arrangement_info(i, 2), 7)) > area
        indices_to_remove = [indices_to_remove; i];
    end
end

Q(indices_to_remove, :) = [];