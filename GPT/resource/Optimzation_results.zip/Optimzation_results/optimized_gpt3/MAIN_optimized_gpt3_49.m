```matlab
%MAIN.m  --  simple walker trajectory optimization
%
% This script sets up a trajectory optimization problem for a simple model
% of walking, and solves it using OptimTraj. The walking model is a double
% pendulum, with point feet, no ankle torques, impulsive heel-strike (but
% not push-off), and continuous hip torque. Both legs have inertia. Cost
% function is minimize integral of torque-squared.
%
%

clc; clear;
addpath ../../

% Parameters for the dynamics function
param.dyn.m = 10;  %leg mass
param.dyn.I = 1;  %leg inertia about CoM
param.dyn.g = 9.81;  %gravity
param.dyn.l = 1;  %leg length
param.dyn.d = 0.2;  %Leg CoM distance from hip

% Set up function handles
problem.func.dynamics = @(t,x,u)( dynamics(x,u,param.dyn) );
problem.func.pathObj = @(t,x,u)( costFun(u) );
problem.func.bndCst = @(t0,x0,tF,xF)( periodicGait(xF,x0,param.dyn) );

% Set up bounds on time, state, and control
t0 = 0;  tF = 1;
problem.bounds.initialTime.low = t0;
problem.bounds.initialTime.upp = t0;
problem.bounds.finalTime.low = tF;
problem.bounds.finalTime.upp = tF;

% State: [q1;q2;dq1;dq2];
problem.bounds.state.low = [-pi/3; -pi/3; -inf(2,1)];
problem.bounds.state.upp = [ pi/3;  pi/3;  inf(2,1)];

stepAngle = 0.2;
problem.bounds.initialState.low = [stepAngle; -stepAngle; -inf(2,1)];
problem.bounds.initialState.upp = [stepAngle; -stepAngle;  inf(2,1)];

% Create an initial guess for the trajectory
problem.guess.time = [t0, tF];
stepRate = (2*stepAngle)/(tF-t0);
x0 = [stepAngle; -stepAngle; -stepRate; stepRate];
xF = [-stepAngle; stepAngle; -stepRate; stepRate];
problem.guess.state = [x0, xF];
problem.guess.control = [0, 0];

% Options
method = 'hermiteSimpson'; % Choose the transcription method

% First iteration
problem.options(1).nlpOpt = optimset('Display','iter','TolFun',1e-3,'MaxFunEvals',1e4);
problem.options(1).verbose = 3;
problem.options(1).method = method;
problem.options(1).(method).nSegment = 6;

% Second iteration
problem.options(2).nlpOpt = optimset('Display','iter','TolFun',1e-6,'MaxFunEvals',5e4);
problem.options(2).verbose = 3;
problem.options(2).method = method;
problem.options(2).(method).nSegment = 15;

% Solve
soln = optimTraj(problem);

% Plot the solution
t = soln(end).grid.time;
q1 = soln(end).grid.state(1,:);
q2 = soln(end).grid.state(2,:);
dq1 = soln(end).grid.state(3,:);
dq2 = soln(end).grid.state(4,:);
u = soln(end).grid.control;

tInt = linspace(t(1),t(end),10*length(t)+1);
xInt = soln(end).interp.state(tInt);
q1Int = xInt(1,:);
q2Int = xInt(2,:);
dq1Int = xInt(3,:);
dq2Int = xInt(4,:);
uInt = soln(end).interp.control(tInt);

figure(100); clf;

subplot(3,1,1); hold on;
plot(tInt,q1Int,'r-'); plot(tInt,q2Int,'b-');
plot([t(1),t(end)],[0,0],'k--','