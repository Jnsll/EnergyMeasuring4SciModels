% Optimized and refactored Matlab code for energy efficiency

% Part 1: ELM regression fitting - Predicting octane values based on near-infrared spectra

clear all;
clc;

% Generate training and testing sets
load spectra_data.mat;

% Randomly generate training and testing sets
temp = randperm(size(NIR, 1));
P_train = NIR(temp(1:50), :)';
T_train = octane(temp(1:50), :)';
P_test = NIR(temp(51:end), :)';
T_test = octane(temp(51:end), :)';
N = size(P_test, 2);

% Data normalization
[Pn_train, inputps] = mapminmax(P_train);
Pn_test = mapminmax('apply', P_test, inputps);
[Tn_train, outputps] = mapminmax(T_train);
Tn_test = mapminmax('apply', T_test, outputps);

% Create/train ELM
[IW, B, LW, TF, TYPE] = elmtrain(Pn_train, Tn_train, 30, 'sig', 0);

% ELM simulation testing
tn_sim = elmpredict(Pn_test, IW, B, LW, TF, TYPE);
T_sim = mapminmax('reverse', tn_sim, outputps);

% Result comparison
result = [T_test' T_sim'];
E = mse(T_sim - T_test);
R2 = (N * sum(T_sim .* T_test) - sum(T_sim) * sum(T_test))^2 / ((N * sum((T_sim).^2) - (sum(T_sim))^2) * (N * sum((T_test).^2) - (sum(T_test))^2));

% Plotting
figure(1)
plot(1:N, T_test, 'r-*', 1:N, T_sim, 'b:o')
grid on
legend('Actual Value', 'Predicted Value')
xlabel('Sample Number')
ylabel('Octane Value')
title(['Comparison of predicted octane values in the test set (ELM) (mse = ' num2str(E) ' R^2 = ' num2str(R2) ')'])

% Part 2: ELM classification - Iris flower species recognition

clear all;
clc;

% Generate training and testing sets
load iris_data.mat;

P_train = [];
T_train = [];
P_test = [];
T_test = [];
for i = 1:3
    temp_input = features((i-1)*50+1:i*50, :);
    temp_output = classes((i-1)*50+1:i*50, :);
    n = randperm(50);
    P_train = [P_train temp_input(n(1:40), :)'];
    T_train = [T_train temp_output(n(1:40), :)'];
    P_test = [P_test temp_input(n(41:50), :)'];
    T_test = [T_test temp_output(n(41:50), :)'];
end

% Create/train ELM
[IW, B, LW, TF, TYPE] = elmtrain(P_train, T_train, 20, 'sig', 1);

% ELM simulation testing
T_sim_1 = elmpredict(P_train, IW, B, LW, TF, TYPE);
T_sim_2 = elmpredict(P_test, IW, B, LW, TF, TYPE);

% Result comparison
result_1 = [T_train' T_sim_1'];
result_2 = [T_test' T_sim_2'];
k1 = length(find(T_train == T_sim_1));
n1 = length(T_train);
Accuracy_1 = k1 / n1 * 100;
disp(['Training set accuracy = ' num2str(Accuracy_1) '% (' num2str(k1) '/' num2str(n1) ')'])
k2 = length(find(T_test == T_sim_2));
n2 = length(T_test);
Accuracy_2 = k2 / n2 * 100;
disp(['Testing set accuracy = ' num2str(Accuracy_2) '% (' num2str(k2) '/' num2str(n2) ')'])

% Plotting
figure(2)
plot(1:30, T_test, 'bo', 1:30, T_sim_2, 'r-*')
grid on
xlabel('Test Sample Number')
ylabel('Test Sample Class')
title(['Comparison of predicted test set results (ELM) (Accuracy = ' num2str(Accuracy_2) '%)'])
legend('Actual Value', 'ELM Predicted Value');