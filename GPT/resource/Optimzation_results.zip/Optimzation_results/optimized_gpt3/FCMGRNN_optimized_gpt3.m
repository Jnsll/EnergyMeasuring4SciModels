%% Clear environment and load data
clear all;
clc;

%% Extract attack data

% Load attack sample data
load netattack;
P1 = netattack;
T1 = P1(:,39)';
P1(:,39) = [];

% Data size
[R1, C1] = size(P1);
csum = 20;  % Extract how many training data

%% Fuzzy clustering
data = P1;
[center, U, obj_fcn] = fcm(data, 5);    
[~, a1] = max(U);

%% Analyze fuzzy clustering results
Confusion_Matrix_FCM = zeros(6,6);
Confusion_Matrix_FCM(1,:) = 0:5;
Confusion_Matrix_FCM(:,1) = 0:5;
for nf = 1:5
    for nc = 1:5
        Confusion_Matrix_FCM(nf+1, nc+1) = sum(a1(T1 == nf) == nc);
    end
end

%% Extract network training samples
centroids = zeros(5, C1);
for i = 1:5
    centroids(i, :) = mean(P1(a1 == i, :));
end

% Extract samples with minimum norm as training samples
ecent = zeros(R1, 5);
for i = 1:5
    ecent(:, i) = vecnorm(P1 - centroids(i, :), 2, 2);
end

[~, idx] = sort(ecent, 1);
P2 = P1(idx(1:csum, :), :);
T2 = repelem(1:5, csum);

%% Iterative calculation
for nit = 1:10
    %% Generalized regression neural network clustering
    net = newgrnn(P2', T2, 50);   % Train GRNN
    
    a2 = sim(net, P1') ;  % Predict results
    a2(a2 <= 1.5) = 1;
    a2(a2 > 1.5 & a2 <= 2.5) = 2;
    a2(a2 > 2.5 & a2 <= 3.5) = 3;
    a2(a2 > 3.5 & a2 <= 4.5) = 4;
    a2(a2 > 4.5) = 5;
    
    % Extract network training data again
    centroids = zeros(5, C1);
    for i = 1:5
        centroids(i, :) = mean(P1(a2 == i, :));
    end
    
    ecent = zeros(R1, 5);
    for i = 1:5
        ecent(:, i) = vecnorm(P1 - centroids(i, :), 2, 2);
    end
    
    [~, idx] = sort(ecent, 1);
    P2 = P1(idx(1:csum, :), :);
    T2 = repelem(1:5, csum);

    % Calculate confusion matrix for GRNN
    Confusion_Matrix_GRNN = zeros(6,6);
    Confusion_Matrix_GRNN(1,:) = 0:5;
    Confusion_Matrix_GRNN(:,1) = 0:5;
    for nf = 1:5
        for nc = 1:5
            Confusion_Matrix_GRNN(nf+1, nc+1) = sum(a2(T1 == nf) == nc);
        end
    end
    
    pre2 = sum(max(Confusion_Matrix_GRNN(2:6, :)))/R1*100;

end

%% Display results
Confusion_Matrix_FCM
Confusion_Matrix_GRNN