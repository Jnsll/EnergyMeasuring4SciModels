%% Calculate system information and system figures
%% Use discrete enumeration method to calculate system information and system figures for bestx0, besty0 cases
clc
clear

% Constants
H = 18;
N = 1000;
x0 = 20;
m_qiu = 1200;
I = 2;
L = 22.05;

% Initialize variables
v_wind_values = [12, 24, 36];
y0_yn_figure = 1;
xitong_figure = 1;

for i = 1:length(v_wind_values)
    v_wind = v_wind_values(i);
    
    % Calculate besty0 and bestx0
    [besty0, bestx0] = bestpoint(H, N, x0, v_wind, m_qiu, I, L, y0_yn_figure);
    
    % Calculate system parameters
    [y, x, theta, T, stat] = For2D(besty0, bestx0, v_wind, m_qiu, I, L, xitong_figure);
end

%% Use iterative algorithm to calculate system information and system figures for bestx0, besty0 cases
clc
clear

% Constants
y0 = -0.5;
x0 = 20;
H = 18;
eta = 0.001; % Learning rate
maxt = 500;
eps = 0.01;
v_wind = 12;
m_qiu = 1200;
I = 2;
L = 22.05;

% Calculate besty0, bestx0, and bestyn
[besty0, bestx0, bestyn] = bestpoint2(y0, x0, H, eta, maxt, eps, v_wind, m_qiu, I, L);

% Calculate system parameters
xitong_figure = 1;
[y, x, theta, T, stat] = For2D(besty0, bestx0, v_wind, m_qiu, I, L, xitong_figure);

%% Use fzero to calculate system information and system figures for bestx0, besty0 cases
clc
clear

% Constants
H = 18;
x0 = 20;
v_wind = 12;
m_qiu = 1200;
I = 2;
L = 22.05;
xitong_figure = 0;

% Calculate besty0 and bestx0
[besty0, bestx0] = bestpoint3(H, x0, v_wind, m_qiu, I, L, xitong_figure);

% Calculate system parameters
xitong_figure = 1;
[y, x, theta, T, stat] = For2D(besty0, bestx0, v_wind, m_qiu, I, L, xitong_figure);
% Note: fzero function can be replaced with fsolve function