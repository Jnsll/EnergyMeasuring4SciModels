% Optmized and refactored Matlab code for energy efficiency
close all; % Close all figure windows
clear all; % Clear all variables in the workspace
clc;

% Read the image and convert it to HSV color space
J = imread('huangguahua.jpg');
hsv = rgb2hsv(J);

% Extract the hue, saturation, and value components
h = hsv(:, :, 1);
s = hsv(:, :, 2);
v = hsv(:, :, 3);

% Set default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(0, 'defaultFigureColor', [1 1 1]);

% Display the original image and grayscale images based on hue, saturation, and value
figure;
subplot(121);
imshow(J);
title('Original Image');

subplot(122);
imshow(h);
title('Hue Component');

figure;
subplot(121);
imshow(s);
title('Saturation Component');

subplot(122);
imshow(v);
title('Value Component');

% Display histograms of the hue, saturation, and value components
figure;
subplot(131);
imhist(h);
title('Hue Histogram');

subplot(132);
imhist(s);
title('Saturation Histogram');

subplot(133);
imhist(v);
title('Value Histogram');