% web browser http://www.ilovematlab.cn/thread-65144-1-1.html
%% Clear environment variables
clc
clear

%% Network parameter configuration
load traffic_flux input output input_test output_test

M = size(input, 2); % Number of input nodes
N = size(output, 2); % Number of output nodes

n = 6; % Number of hidden nodes
lr1 = 0.01; % Learning rate
lr2 = 0.001; % Learning rate
maxgen = 100; % Number of iterations

% Weight initialization
Wjk = randn(n, M); Wjk_1 = Wjk; Wjk_2 = Wjk_1;
Wij = randn(N, n); Wij_1 = Wij; Wij_2 = Wij_1;
a = randn(1, n); a_1 = a; a_2 = a_1;
b = randn(1, n); b_1 = b; b_2 = b_1;

% Node initialization
y = zeros(1, N);
net = zeros(1, n);
net_ab = zeros(1, n);

% Weight learning increment initialization
d_Wjk = zeros(n, M);
d_Wij = zeros(N, n);
d_a = zeros(1, n);
d_b = zeros(1, n);

%% Normalize input and output data
[inputn, inputps] = mapminmax(input');
[outputn, outputps] = mapminmax(output');
inputn = inputn';
outputn = outputn';

%% Network training
for i = 1:maxgen
    
    % Error accumulation
    error(i) = 0;
    
    % Training loop
    for kk = 1:size(input, 1)
        x = inputn(kk, :);
        yqw = outputn(kk, :);
   
        for j = 1:n
            for k = 1:M
                net(j) = net(j) + Wjk(j, k) * x(k);
                net_ab(j) = (net(j) - b(j)) / a(j);
            end
            temp = mymorlet(net_ab(j));
            for k = 1:N
                y = y + Wij(k, j) * temp;
            end
        end
        
        % Calculate error sum
        error(i) = error(i) + sum(abs(yqw - y));
        
        % Weight adjustment
        for j = 1:n
            % Calculate d_Wij
            temp = mymorlet(net_ab(j));
            for k = 1:N
                d_Wij(k, j) = d_Wij(k, j) - (yqw(k) - y(k)) * temp;
            end
            % Calculate d_Wjk
            temp = d_mymorlet(net_ab(j));
            for k = 1:M
                for l = 1:N
                    d_Wjk(j, k) = d_Wjk(j, k) + (yqw(l) - y(l)) * Wij(l, j);
                end
                d_Wjk(j, k) = -d_Wjk(j, k) * temp * x(k) / a(j);
            end
            % Calculate d_b
            for k = 1:N
                d_b(j) = d_b(j) + (yqw(k) - y(k)) * Wij(k, j);
            end
            d_b(j) = d_b(j) * temp / a(j);
            % Calculate d_a
            for k = 1:N
                d_a(j) = d_a(j) + (yqw(k) - y(k)) * Wij(k, j);
            end
            d_a(j) = d_a(j) * temp * ((net(j) - b(j)) / b(j)) / a(j);
        end
        
        % Weight parameter update      
        Wij = Wij - lr1 * d_Wij;
        Wjk = Wjk - lr1 * d_Wjk;
        b = b - lr2 * d_b;
        a = a - lr2 * d_a;
    
        d_Wjk = zeros(n, M);
        d_Wij = zeros(N, n);
        d_a = zeros(1, n);
        d_b = zeros(1, n);

        y = zeros(1, N);
        net = zeros(1, n);
        net_ab = zeros(1, n);
        
        Wjk_1 = Wjk; Wjk_2 = Wjk_1;
        Wij_1 = Wij; Wij_2 = Wij_1;
        a_1 = a; a_2 = a_1;
        b_1 = b; b_2 = b_1;
    end
end

%% Network prediction
% Normalize input for prediction
x = mapminmax('apply', input_test', inputps);
x = x';

% Network prediction
for i = 1:92
    x_test = x(i, :);

    for j = 1:n
        for k = 1:M
            net(j) = net(j) + Wjk(j, k) * x_test(k);
            net_ab(j) = (net(j) - b(j)) / a(j);
        end
        temp = mymorlet(net_ab(j));
        for k = 1:N
            y(k) = y(k) + Wij(k, j) * temp; 
        end
    end

    yuce(i) = y(k);
    y = zeros(1, N);
    net = zeros(1, n);
    net_ab = zeros(1, n);
end
% Reverse normalize predicted output
ynn = mapminmax('reverse', yuce, outputps);

%% Result analysis
figure(1)
plot(ynn, 'r*:')
hold on
plot(output_test, 'bo--')
title('Predicted traffic flow', 'fontsize', 12)
legend('Predicted traffic flow', 'Actual traffic flow')
xlabel('Time point')
ylabel('Traffic flow')

% web browser http://www.ilovematlab.cn/thread-65144-1-1.html