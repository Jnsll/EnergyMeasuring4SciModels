% Optimized Matlab code for energy efficiency

% Load images
I = imread('hua.jpg'); % Flower image
J = imread('yezi.jpg'); % Leaf image
K = imread('flower1.jpg'); % Original image

% Calculate RGB component averages and standard deviations for flower image
Ravg1 = mean2(double(I(:,:,1)));
Gavg1 = mean2(double(I(:,:,2)));
Bavg1 = mean2(double(I(:,:,3)));
Rstd1 = std(double(I(:,:,1)(:)));
Gstd1 = std(double(I(:,:,2)(:)));
Bstd1 = std(double(I(:,:,3)(:)));

% Calculate RGB component averages and standard deviations for leaf image
Ravg2 = mean2(double(J(:,:,1)));
Gavg2 = mean2(double(J(:,:,2)));
Bavg2 = mean2(double(J(:,:,3)));
Rstd2 = std(double(J(:,:,1)(:)));
Gstd2 = std(double(J(:,:,2)(:)));
Bstd2 = std(double(J(:,:,3)(:)));

% Display images
figure('Position',[100,100,1000,500],'Color',[1 1 1]);
subplot(131), imshow(K); % Original image
subplot(132), imshow(I); % Flower image
subplot(133), imshow(J); % Leaf image