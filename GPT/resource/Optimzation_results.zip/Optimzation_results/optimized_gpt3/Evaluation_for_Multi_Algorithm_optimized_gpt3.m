clc
clear all

names = {'DenseFuse', 'RFN-Nest', 'FusionGAN', 'SeAFusion', 'PIAFusion', 'IFCNN', 'PMGI', 'SDNet', 'U2Fusion'};
rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'];
easy = 1; % 1 for testing EN, SF, SD, PSNR, MSE, MI, VIF, AG, CC, SCD, Qabf, 0 for testing Nabf, SSIM, MS_SSIM, FMI_pixel, FMI_dct, FMI_w
dataset = 'TNO';
row_name1 = 'row1';
row_data1 = 'row2';

for i = 1:length(names)
    method_name = cellstr(names(i));
    row = rows(i);
    row_name = strrep(row_name1, 'row', row);
    row_data = strrep(row_data1, 'row', row);
    fileFolder = fullfile('../Image/Source-Image', dataset, 'ir'); % Source image A folder
    dirOutput = dir(fullfile(fileFolder, '*.*'));
    fileNames = {dirOutput.name};
    [m, num] = size(fileNames);   
    ir_dir = fullfile('../Image/Source-Image', dataset, 'ir'); % Source image A folder
    vi_dir = fullfile('../Image/Source-Image', dataset, 'vi'); % Source image B folder
    Fused_dir = '../';
    Fused_dir = fullfile(Fused_dir, 'Image', 'Algorithm', strcat(cell2mat(names(i)), '_', dataset)); % Fusion result folder
    
    metric_set = struct('EN', [], 'SF', [], 'SD', [], 'PSNR', [], 'MSE', [], 'MI', [], 'VIF', [], 'AG', [], 'CC', [], 'SCD', [], 'Qabf', [], 'Nabf', [], 'SSIM', [], 'MS_SSIM', [], 'FMI_pixel', [], 'FMI_dct', [], 'FMI_w', []);
    
    for j = 1:num
        if (isequal(fileNames{j}, '.') || isequal(fileNames{j}, '..'))
            continue;
        else
            fileName_source_ir = fullfile(ir_dir, fileNames{j});
            fileName_source_vi = fullfile(vi_dir, fileNames{j}); 
            fileName_Fusion = fullfile(Fused_dir, fileNames{j});
            ir_image = imread(fileName_source_ir);
            vi_image = imread(fileName_source_vi);
            fused_image = imread(fileName_Fusion);
            
            ir_image = convertToGray(ir_image);
            vi_image = convertToGray(vi_image);
            fused_image = convertToGray(fused_image);
            
            [m, n] = size(fused_image);
            
            ir_size = size(ir_image);
            vi_size = size(vi_image);
            fusion_size = size(fused_image);
            
            if length(ir_size) < 3 && length(vi_size) < 3
                metric_set = analyzeAndStoreMetrics(metric_set, fused_image, ir_image, vi_image, easy);
            else
                disp('Unsuccessful!')
                disp(fileName_Fusion)
            end
            
            fprintf('Fusion Method: %s, Image Name: %s\n', cell2mat(names(i)), fileNames{j})
        end
    end
    
    saveMetricsToExcel(metric_set, names(i), dataset, easy);
end

function image = convertToGray(image)
    if size(image, 3) > 2
        image = rgb2gray(image);
    end
end

function metric_set = analyzeAndStoreMetrics(metric_set, fused_image, ir_image, vi_image, easy)
    [EN, SF, SD, PSNR, MSE, MI, VIF, AG, CC, SCD, Qabf, Nabf, SSIM, MS_SSIM, FMI_pixel, FMI_dct, FMI_w] = analysis_Reference(fused_image, ir_image, vi_image, easy);
    
    fields = fieldnames(metric_set);
    for k = 1:numel(fields)
        metric_set.(fields{k}) = [metric_set.(fields{k}), eval(fields{k})];
    end
end

function saveMetricsToExcel(metric_set, method_name, dataset, easy)
    save_dir = '../Metric'; % Folder to store Excel results
    if exist(save_dir, 'dir') == 0
        mkdir(save_dir);
    end
    
    file_name = fullfile(save_dir, strcat('Metric_', dataset, '.xlsx')); % Excel file name
    
    fields = fieldnames(metric_set);
    
    for k = 1:numel(fields)
        metric_table = table(metric_set.(fields{k})');
        writetable(metric_table, file_name, 'Sheet', fields{k}, 'Range', 'row2');
        writetable(table(cellstr(method_name)), file_name, 'Sheet', fields{k}, 'Range', 'row1');
    end
end