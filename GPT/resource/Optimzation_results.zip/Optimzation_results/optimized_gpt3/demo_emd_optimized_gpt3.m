% Optimized and Refactored Matlab Code for Energy Efficiency

% Generate random weights w1 and w2
n = 400;
w1 = rand(1, n);
w2 = rand(1, n);

% Normalize the weights
w1 = w1 / sum(w1);
w2 = w2 / sum(w2);

% Calculate the Euclidean distance between w1 and w2
C = pdist2(w1', w2');

% Call the optimized function to calculate Earth Mover's Distance
[e, Flow] = emd_mex(w1, w2, C);