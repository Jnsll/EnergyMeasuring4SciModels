clear;
clc;
x=[51 27 56 21 4 6 58 71 54 40 94 18 89 33 12 25 24 58 71 94 17 38 13 82 12 58 45 11 47 4]';
y=[14 81 67 92 64 19 98 18 62 69 30 54 10 46 34 18 42 69 61 78 16 40 10 7 32 17 21 26 35 90]';
position = 100 * randn(40, 2);
epochs = 50;
ants = 50;
alpha = 1.4;
beta = 2.2;
rho = 0.15;
Q = 10^6;
cities = size(position, 1);
Distance = pdist2(position, position);
Distance(logical(eye(cities))) = eps;
Eta = 1./Distance;
Tau = ones(cities, cities);
Route = zeros(ants, cities);
R_best = zeros(epochs, cities);
L_best = inf .* ones(epochs, 1);
L_ave = zeros(epochs, 1);
epoch = 1;

while epoch <= epochs
    RandPos = randperm(cities);
    Route(:, 1) = RandPos(1:ants)';
    for j = 2:cities
        for i = 1:ants
            Visited = Route(i, 1:j-1);
            NoVisited = setdiff(1:cities, Visited);
            P = (Tau(Visited(end), NoVisited).^alpha) .* (Eta(Visited(end), NoVisited).^beta);
            P = P / sum(P);
            Pcum = cumsum(P);
            select = find(Pcum >= rand);
            to_visit = NoVisited(select(1));
            Route(i, j) = to_visit;
        end
    end
    if epoch >= 2
        Route(1, :) = R_best(epoch - 1, :);
    end
    Distance_epoch = sum(Distance(sub2ind([ants, cities], repmat(1:ants, 1, cities), Route)));
    L_best(epoch) = min(Distance_epoch);
    pos = find(Distance_epoch == L_best(epoch));
    R_best(epoch, :) = Route(pos(1), :);
    L_ave(epoch) = mean(Distance_epoch);
    
    Delta_Tau = zeros(cities, cities);
    for i = 1:ants
        Delta_Tau(sub2ind([cities, cities], Route(i, 1:end-1), Route(i, 2:end))) = Delta_Tau(sub2ind([cities, cities], Route(i, 1:end-1), Route(i, 2:end)) + Q ./ Distance_epoch(i);
        Delta_Tau(Route(i, end), Route(i, 1)) = Delta_Tau(Route(i, end), Route(i, 1)) + Q ./ Distance_epoch(i);
    end
    Tau = (1 - rho) .* Tau + Delta_Tau;
    Route = zeros(ants, cities);
    epoch = epoch + 1;
end

Pos = find(L_best == min(L_best));
Short_Route = R_best(Pos(1), :);
Short_Length = L_best(Pos(1), :);
figure
DrawRoute(position, Short_Route);