% Optimize Matlab code for energy efficiency

% Store the current directory
cur_dir = pwd;

% Change directory to the location of the current script
cd(fileparts(mfilename('fullpath')));

try
    fprintf('Downloading caffe_mex...\n');
    
    % Use websave instead of urlwrite for downloading file
    websave('caffe_mex.zip', 'https://onedrive.live.com/download?resid=36FEC490FBC32F1A!111&authkey=!AFVWFGTbViiX5tg&ithint=file%2czip');

    fprintf('Unzipping...\n');
    
    % Unzip directly to the current directory
    unzip('caffe_mex.zip', '.');

    fprintf('Done.\n');
    
    % Delete the downloaded zip file
    delete('caffe_mex.zip');
catch
    fprintf('Error in downloading, please try links in README.md https://github.com/ShaoqingRen/faster_rcnn'); 
end

% Change back to the original directory
cd(cur_dir);