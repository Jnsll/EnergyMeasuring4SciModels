function [sig, mixedsig] = demosig_optimized()
% Optimized function for generating test signals and mixed signals

% Parameters
N = 500; % Data size

v = 0:N-1;
sig = zeros(4, N);

% Create source signals (independent components)
sig(1, :) = sin(v/2); % Sinusoid
sig(2, :) = ((rem(v, 23) - 11) / 9) .^ 5; % Funny curve
sig(3, :) = ((rem(v, 27) - 13) / 9); % Saw-tooth
sig(4, :) = ((rand(1, N) < 0.5) * 2 - 1) .* log(rand(1, N)); % Impulsive noise

% Normalize signals
for t = 1:4
    sig(t, :) = sig(t, :) / std(sig(t, :));
end

% Remove mean
[sig, ~] = remmean(sig);

% Create mixtures
Aorig = rand(4); % Adjusted size to match the number of signals
mixedsig = Aorig * sig;