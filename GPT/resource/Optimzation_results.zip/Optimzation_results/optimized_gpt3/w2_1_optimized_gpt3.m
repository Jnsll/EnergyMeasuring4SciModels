function main()
    global w h a W r x lamda;
    w = 2.5;
    h = 67;
    a = 1;
    W = 80;
    lamda = 1.5;
    r = sqrt(40*40 + w*w);
    x = (2.5:2.5:40)';
    ts0 = [pi/4, h/2];
    lb = [0, 0];
    ub = [pi/2, h];
    ts = fmincon(@objfun, ts0, [], [], [], [], lb, ub, @confun);
end

function fval = objfun(ts)
    fval = sin(ts(1)) + cos(ts(2));
end

function [c, ceq] = confun(ts)
    c = [];
    ceq = ts(1) + ts(2) - 2*pi;
end