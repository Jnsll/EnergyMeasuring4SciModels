% bsb_test.m
x = [-0.5; -0.4];
beta = 0.5;
c = 100;
bsb(x, beta, c);
text(-0.5, -0.4, '(-0.5, -0.4)');