function movieList = loadMovieList()
%LOADMOVIELIST reads the fixed movie list in movie_ids.txt and returns a
%cell array of the movie names
%   movieList = LOADMOVIELIST() reads the fixed movie list in movie_ids.txt 
%   and returns a cell array of the movie names in movieList.

% Open the file containing movie names
fid = fopen('movie_ids.txt');

% Initialize cell array to store movie names
n = 1682;  % Total number of movies 
movieList = cell(n, 1);

% Read each line in the file and extract the movie name
for i = 1:n
    line = fgetl(fid);  % Read line
    [~, movieName] = strtok(line, ' ');  % Extract movie name
    movieList{i} = strtrim(movieName);  % Store movie name
end

fclose(fid);  % Close the file

end