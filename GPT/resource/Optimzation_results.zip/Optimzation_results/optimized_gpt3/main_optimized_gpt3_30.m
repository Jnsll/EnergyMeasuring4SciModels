%% Clearing Environment Variables
warning off             % Disable warnings
close all               % Close all figure windows
clear                   % Clear all variables
clc                     % Clear command window

%% Importing Data (Single column time series data)
result = xlsread('���ݼ�.xlsx');

%% Data Analysis
num_samples = length(result);  % Number of samples
kim = 15;                      % Delay step (using kim historical data as independent variables)
zim =  1;                      % Predicting across zim time points

%% Constructing Dataset
res = zeros(num_samples - kim - zim + 1, kim + 1);
for i = 1: num_samples - kim - zim + 1
    res(i, :) = [result(i: i + kim - 1)', result(i + kim + zim)];
end

%% Splitting Training and Testing Sets
temp = 1: 1: 922;

P_train = res(temp(1: 700), 1: 15)';
T_train = res(temp(1: 700), 16)';
M = size(P_train, 2);

P_test = res(temp(701: end), 1: 15)';
T_test = res(temp(701: end), 16)';
N = size(P_test, 2);

%% Data Normalization
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%% Creating Model
num_hiddens = 20;        % Number of hidden layer nodes
activate_model = 'sig';  % Activation function
[IW, B, LW, TF, TYPE] = elmtrain(p_train, t_train, num_hiddens, activate_model, 0);

%% Simulation Testing
t_sim1 = elmpredict(p_train, IW, B, LW, TF, TYPE);
t_sim2 = elmpredict(p_test , IW, B, LW, TF, TYPE);

%% Data Denormalization
T_sim1 = mapminmax('reverse', t_sim1, ps_output);
T_sim2 = mapminmax('reverse', t_sim2, ps_output);

%% Root Mean Square Error
error1 = sqrt(sum((T_sim1 - T_train).^2) ./ M);
error2 = sqrt(sum((T_sim2 - T_test ).^2) ./ N);

%% Plotting
figure
plot(1: M, T_train, 'r-', 1: M, T_sim1, 'b-', 'LineWidth', 1)
legend('Actual Value', 'Predicted Value')
xlabel('Predicted Sample')
ylabel('Prediction Result')
string = {'Comparison of Training Set Predictions'; ['RMSE=' num2str(error1)]};
title(string)
xlim([1, M])
grid

figure
plot(1: N, T_test, 'r-', 1: N, T_sim2, 'b-', 'LineWidth', 1)
legend('Actual Value', 'Predicted Value')
xlabel('Predicted Sample')
ylabel('Prediction Result')
string = {'Comparison of Testing Set Predictions'; ['RMSE=' num2str(error2)]};
title(string)
xlim([1, N])
grid

%% Calculating Correlation Metrics
% R2
R1 = 1 - norm(T_train - T_sim1)^2 / norm(T_train - mean(T_train))^2;
R2 = 1 - norm(T_test  - T_sim2)^2 / norm(T_test  - mean(T_test ))^2;

disp(['R2 of Training Set Data: ', num2str(R1)])
disp(['R2 of Testing Set Data: ', num2str(R2)])

% MAE
mae1 = sum(abs(T_sim1 - T_train)) ./ M ;
mae2 = sum(abs(T_sim2 - T_test )) ./ N ;

disp(['MAE of Training Set Data: ', num2str(mae1)])
disp(['MAE of Testing Set Data: ', num2str(mae2)])

% MBE
mbe1 = sum(T_sim1 - T_train) ./ M ;
mbe2 = sum(T_sim2 - T_test ) ./ N ;

disp(['MBE of Training Set Data: ', num2str(mbe1)])
disp(['MBE of Testing Set Data: ', num2str(mbe2)])

%% Scatter Plot
sz = 25;
c = 'b';

figure
scatter(T_train, T_sim1, sz, c)
hold on
plot(xlim, ylim, '--k')
xlabel('Actual Values (Training Set)');
ylabel('Predicted Values (Training Set)');
xlim([min(T_train) max(T_train)])
ylim([min(T_sim1) max(T_sim1)])
title('Predicted Values vs. Actual Values (Training Set)')

figure
scatter(T_test, T_sim2, sz, c)
hold on
plot(xlim, ylim, '--k')
xlabel('Actual Values (Testing Set)');
ylabel('Predicted Values (Testing Set)');
xlim([min(T_test) max(T_test)])
ylim([min(T_sim2) max(T_sim2)])
title('Predicted Values vs. Actual Values (Testing Set)')