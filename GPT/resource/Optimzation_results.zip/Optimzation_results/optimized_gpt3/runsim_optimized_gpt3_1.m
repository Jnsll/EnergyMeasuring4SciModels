% Optmized and Refactored Matlab Code

% Clear workspace, close figures, and command window
clear all;
close all;
clc;

% Add necessary paths
addpath(genpath('./'));

% Function to plan path
function planPath(mapFile, resolution, inflate, margin, start, stop)
    disp('Planning ...');
    map = load_map(mapFile, resolution, inflate, margin);
    nquad = length(start);
    for qn = 1:nquad
        tic
        path{qn} = dijkstra(map, start{qn}, stop{qn}, true);
        toc
    end
    if nquad == 1
        plot_path(map, path{1});
    else
        % Modify plot_path to handle multiple robots
    end
end

% Plan path 1
mapFile1 = 'maps/map1.txt';
resolution1 = 0.1;
inflate1 = 2;
margin1 = 0.25;
start1 = {[0.0 -4.9 0.2]};
stop1 = {[6.0 18.0-1 5.0]};
planPath(mapFile1, resolution1, inflate1, margin1, start1, stop1);

% Plan path 3
mapFile3 = 'maps/map3.txt';
resolution3 = 0.2;
inflate3 = 0.5;
margin3 = 0.25;
start3 = {[0.0, 5, 5.0]};
stop3 = {[20, 5, 5]};
planPath(mapFile3, resolution3, inflate3, margin3, start3, stop3);

% Additional init script
init_script;

% Run trajectory
trajectory = test_trajectory(start, stop, map, path, true); % with visualization