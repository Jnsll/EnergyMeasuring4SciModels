%% Quiver calculations optimization
% This optimized code aims to reduce unnecessary symbolic computations and streamline the angle calculation process for improved efficiency.

clc; 
clear variables;
close all;

%% Parameters
x = randn(); y = randn(); z = randn();
u = randn(); v = randn(); w = randn();
alpha = 0.33;
beta = alpha;
epsilon = 0;
is2D = true;

%% Coordinates as defined in MATLAB
A = [x y z].';
delta = [u v w].';
B = A + delta;
C = B - alpha*[u+beta*(v+epsilon);
               v-beta*(u+epsilon)
               w];
D = B - alpha*[u-beta*(v+epsilon);
               v+beta*(u+epsilon)
               w];

if is2D
    A = A(1:2);
    B = B(1:2);
    C = C(1:2);
    D = D(1:2);
    delta = delta(1:2);
end

%% Calculating the angle of the arrowhead
unitVector = @(v) v/norm(v);
cosAngleBetween = @(a,b,c) unitVector(a-b).' * unitVector(c-b);

cosTwiceTheta = cosAngleBetween(C,B,D);
theta = acos(cosTwiceTheta) / 2;

thetaVal = rad2deg(theta)

% For the MATLAB parameters alpha=beta=0.33, we get theta = 18.263 degrees.