% elman_stock_optimized.m
%% Clear workspace variables and figures
clearvars
close all

% Load 337 periods of Shanghai Stock Exchange Index opening prices
load elm_stock

%% Construct sample set
n = length(price); % Number of data points
price = price(:); % Ensure price is a column vector
L = 6; % Predict x(n) using x(n-1), x(n-2), ..., x(n-L)

% Construct samples
price_n = zeros(L+1, n-L);
for i = 1:n-L
    price_n(:,i) = price(i:i+L);
end

%% Split training and testing samples
trainx = price_n(1:6, 1:280);
trainy = price_n(7, 1:280);

testx = price_n(1:6, 290:end);
testy = price_n(7, 290:end);

%% Create Elman neural network
net = elmannet(1:2, 15, 'traingdx');

% Set training parameters
net.trainParam.show = 1;
net.trainParam.epochs = 2000;
net.trainParam.goal = 0.00001;
net.trainParam.max_fail = 5;
net = init(net);

%% Train the network
[trainx1, st1] = mapminmax(trainx);
[trainy1, st2] = mapminmax(trainy);

testx1 = mapminmax('apply', testx, st1);
testy1 = mapminmax('apply', testy, st2);

[net, per] = train(net, trainx1, trainy1);

%% Test the network
train_ty1 = sim(net, trainx1);
train_ty = mapminmax('reverse', train_ty1, st2);

test_ty1 = sim(net, testx1);
test_ty = mapminmax('reverse', test_ty1, st2);

%% Display results
% Training data results
figure(1)
x = 1:length(train_ty);
plot(x, trainy, 'b-');
hold on
plot(x, train_ty, 'r--')
legend('Actual Price', 'Elman Network Output')
title('Training Data Results');

figure(2)
plot(x, train_ty - trainy)
title('Residuals of Training Data Results')

mse1 = mse(train_ty - trainy);
fprintf('    mse = \n     %f\n', mse1)

disp('    Relative Errors:')
fprintf('%f  ', (train_ty - trainy) ./ trainy);
fprintf('\n')

% Testing data results
figure(3)
x = 1:length(test_ty);
plot(x, testy, 'b-');
hold on
plot(x, test_ty, 'r--')
legend('Actual Price', 'Elman Network Output')
title('Testing Data Results');

figure(4)
plot(x, test_ty - testy)
title('Residuals of Testing Data Results')

mse2 = mse(test_ty - testy);
fprintf('    mse = \n     %f\n', mse2)

disp('    Relative Errors:')
fprintf('%f  ', (test_ty - testy) ./ testy);
fprintf('\n')