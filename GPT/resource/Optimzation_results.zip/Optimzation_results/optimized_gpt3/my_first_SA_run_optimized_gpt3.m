% Energy-Optimized and Refactored Matlab Code

% Define the objective function
ObjectiveFunction = @my_first_SA;

% Set the initial point and bounds
X0 = [2.5 2.5];
lb = [-5 -5];
ub = [5 5];

% Set the optimization options
options = saoptimset('MaxIter', 500, 'StallIterLim', 500, 'TolFun', 1e-100, ...
    'AnnealingFcn', @annealingfast, 'InitialTemperature', 100, 'TemperatureFcn', @temperatureexp, ...
    'ReannealInterval', 500, 'PlotFcns', {@saplotbestx, @saplotbestf, @saplotx, @saplotf, @saplottemperature});

% Perform simulated annealing optimization
[x, fval] = simulannealbnd(ObjectiveFunction, X0, lb, ub, options);