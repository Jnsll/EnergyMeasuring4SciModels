% Optimize the Matlab code for energy efficiency
% Refactored code with optimizations

%% Clear workspace
clear all
clc

%% Data preprocessing

% Load data
load water_data.mat
% Normalize data
attributes = mapminmax(attributes);
% Split data into training and testing sets
P_train = attributes(:,1:35);
T_train = classes(:,1:35);
P_test = attributes(:,36:end);
T_test = classes(:,36:end);

%% Competitive Neural Network

% Create network
net_compet = newc(minmax(P_train),4,0.01,0.01);
% Set training parameters
net_compet.trainParam.epochs = 500;
% Train the network
net_compet = train(net_compet,P_train);
% Simulation testing
T_sim_compet_1 = vec2ind(sim(net_compet,P_train));
T_sim_compet_2 = vec2ind(sim(net_compet,P_test));

%% Self-Organizing Feature Map (SOFM) Neural Network

% Create network
net_sofm = newsom(P_train,[4 4]);
% Set training parameters
net_sofm.trainParam.epochs = 200;
% Train the network
net_sofm = train(net_sofm,P_train);
% Simulation testing
T_sim_sofm_1 = vec2ind(sim(net_sofm,P_train));
T_sim_sofm_2 = vec2ind(sim(net_sofm,P_test));

%% Results comparison

% Competitive Neural Network
result_compet_1 = [T_train' T_sim_compet_1']
result_compet_2 = [T_test' T_sim_compet_2']
% SOFM Neural Network
result_sofm_1 = [T_train' T_sim_sofm_1']
result_sofm_2 = [T_test' T_sim_sofm_2']