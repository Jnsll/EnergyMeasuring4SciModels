% Optmized Matlab code for energy efficiency
clear, clc

%% Load data
data = xlsread('cumcm2012B_����3_�������͵Ĺ�����(A������B�ྦྷ��C�Ǿ��象Ĥ)�����Ʋ������г��۸�.xls');
prices = [14.9 12.5 4.8];
lengths = data(:, 2); % Length
widths = data(:, 3); % Width
voltages = data(:, 4); % Voltage
currents = data(:, 5); % Current
efficiencies = data(:, 6); % Conversion efficiency
powers = voltages .* currents;
areas = lengths .* widths / 1000;

%% Calculate cost per square meter for each type
p1 = zeros(size(data, 1), 1);
for i = 1:6
    p1(i) = powers(i) * prices(1) / areas(i);
end % A Monocrystalline Silicon
for i = 7:13
    p1(i) = powers(i) * prices(2) / areas(i);
end % B Polycrystalline Silicon
for i = 14:24
    p1(i) = powers(i) * prices(3) / areas(i);
end % C Amorphous Silicon Thin Film

%% Calculate cost-effectiveness per square meter
ratio = efficiencies ./ p1';

% Plotting
figure;
plot(1:6, ratio(1:6), 'k-*');
hold on;
plot(7:13, ratio(7:13), 'k-s');
hold on;
plot(14:24, ratio(14:24), 'k-d');
xlabel('Component Index');
ylabel('Cost-Effectiveness per Square Meter');
title('Cost-Effectiveness Analysis for Different PV Cell Types');
legend('Monocrystalline Silicon', 'Polycrystalline Silicon', 'Amorphous Silicon Thin Film');
set(gca, 'xtick', 1:24);