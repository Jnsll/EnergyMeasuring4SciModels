% Optmized and refactored Matlab code for energy efficiency

% Clearing workspace, closing all figures, and clearing command window
clear all;
close all;
clc;

% Define quantization value N
N = 64;

% Define variables
m = 15;
L = 2.0;

% Generate RL filter
[x, h] = RLfilter(N, L);

% Extract a portion of x and h
x1 = x(N-m:N+m);
h1 = h(N-m:N+m);

% Modify default figure properties for better visualization
set(0, 'defaultFigurePosition', [100, 100, 1200, 450]);
set(0, 'defaultFigureColor', [1 1 1]);

% Plot original and extracted waveforms
figure,
subplot(121),
plot(x, h), axis tight, grid on; % Display waveform
subplot(122),
plot(x1, h1), axis tight, grid on; % Display waveform