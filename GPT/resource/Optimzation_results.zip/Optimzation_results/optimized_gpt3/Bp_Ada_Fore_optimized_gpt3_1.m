% Optimized and refactored Matlab code for energy efficiency

clc
clear

% Load data
load data1 input output

% Initialize weights
k = rand(1, 2000);
[~, n] = sort(k);

% Training and testing samples
input_train = input(n(1:1900), :)';
output_train = output(n(1:1900), :)';
input_test = input(n(1901:2000), :)';
output_test = output(n(1901:2000), :)';

% Sample weights
[~, nn] = size(input_train);
D(1, :) = ones(1, nn) / nn;

% Normalize training samples
[inputn, inputps] = mapminmax(input_train);
[outputn, outputps] = mapminmax(output_train);

K = 10;
for i = 1:K
    % Train weak predictor
    net = newff(inputn, outputn, 5);
    net.trainParam.epochs = 20;
    net.trainParam.lr = 0.1;
    net = train(net, inputn, outputn);

    % Predict with weak predictor
    an1 = sim(net, inputn);
    BPoutput = mapminmax('reverse', an1, outputps);

    % Prediction error
    erroryc(i, :) = output_train - BPoutput;

    % Predict test data
    inputn1 = mapminmax('apply', input_test, inputps);
    an2 = sim(net, inputn1);
    test_simu(i, :) = mapminmax('reverse', an2, outputps);

    % Adjust D values
    Error(i) = 0;
    for j = 1:nn
        if abs(erroryc(i, j)) > 0.2
            Error(i) = Error(i) + D(i, j);
            D(i+1, j) = D(i, j) * 1.1;
        else
            D(i+1, j) = D(i, j);
        end
    end

    % Calculate weak predictor weight
    at(i) = 0.5 / exp(abs(Error(i)));

    % Normalize D values
    D(i+1, :) = D(i+1, :) / sum(D(i+1, :));
end

% Predict with strong predictor
at = at / sum(at);

% Result statistics
output = at * test_simu;
error = output_test - output;
plot(abs(error), '-*')
hold on
for i = 1:8
    error1(i, :) = test_simu(i, :) - output;
end
plot(mean(abs(error1)), '-or')

title('Strong Predictor Prediction Absolute Error', 'fontsize', 12)
xlabel('Predicted Samples', 'fontsize', 12)
ylabel('Absolute Error', 'fontsize', 12)