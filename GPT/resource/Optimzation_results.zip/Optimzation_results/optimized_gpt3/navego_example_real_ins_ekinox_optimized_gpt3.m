% Optimize the Matlab code for energy efficiency

clc; % Clear the command window
close all; % Close all figures
clear; % Clear the workspace
matlabrc; % Run the startup file

addpath('../../ins/', '../../ins-gnss/', '../../conversions/', '../../performance-analysis/', '../../misc/', '../../plot/'); % Add necessary paths

navego_print_version; % Print NaveGo version

fprintf('\nNaveGo: starting real INS/GNSS integration... \n')

% Define parameters
INS_GNSS = 'ON';
PLOT = 'ON';

% Check if parameters exist
if ~exist('INS_GNSS', 'var')
    INS_GNSS = 'OFF';
end
if ~exist('PLOT', 'var')
    PLOT = 'OFF';
end

% Define conversion constants
G = 9.80665; % Gravity constant, m/s^2
D2R = pi/180; % Degrees to radians

% Load reference and sensor data
load ref
load ekinox_imu
load ekinox_gnss

% Suppress warnings
warning('off','all');

% Calculate navigation time
to = ref.t(end) - ref.t(1);
fprintf('NaveGo: navigation time is %.2f minutes or %.2f seconds. \n', to/60, to)

% Perform INS/GNSS integration
if strcmp(INS_GNSS, 'ON')
    fprintf('NaveGo: processing INS ... \n')
    nav_ekinox = ins(ekinox_imu, ekinox_gnss, 'quaternion'); 
    save nav_ekinox.mat nav_ekinox
else
    load nav_ekinox
end

% Calculate traveled distance
distance = gnss_distance(nav_ekinox.lat, nav_ekinox.lon);
fprintf('NaveGo: distance traveled by the vehicle is %.2f meters or %.2f km. \n', distance, distance/1000)

% Analyze performance for a certain part of the dataset
tmin_rmse = ref.t(1); 
tmax_rmse = ref.t(end); 
idx = find(ref.t > tmin_rmse, 1, 'first' );
fdx = find(ref.t < tmax_rmse, 1, 'last' );
if(isempty(idx) || isempty(fdx))
    error('ref: empty index')
end
ref.t = ref.t(idx:fdx);
ref.roll = ref.roll(idx:fdx);
ref.pitch = ref.pitch(idx:fdx);
ref.yaw = ref.yaw(idx:fdx);
ref.lat = ref.lat(idx:fdx);
ref.lon = ref.lon(idx:fdx);
ref.h = ref.h(idx:fdx);
ref.vel = ref.vel(idx:fdx, :);

% Interpolate dataset
[nav_i, ref_n] = navego_interpolation(nav_ekinox, ref);
[gnss_i, ref_g] = navego_interpolation(ekinox_gnss, ref);

% Calculate navigation RMSE
rmse_v = print_rmse(nav_i, gnss_i, ref_n, ref_g, 'Ekinox INS/GNSS');

% Write RMSE to CSV file
csvwrite('ekinox.csv', rmse_v);

% Write navigation data to CSV file
fprintf('\n');
navego_nav2csv(nav_ekinox); 

% Plot data if PLOT is 'ON'
if strcmp(PLOT, 'ON')
    navego_plot_main(ref, ekinox_gnss, nav_ekinox, gnss_i, nav_i, ref_g, ref_n)
end

% Perform Kalman filter performance analysis
fprintf('\nNaveGo: Kalman filter performance analysis...\n') 
kf_analysis(nav_ekinox)