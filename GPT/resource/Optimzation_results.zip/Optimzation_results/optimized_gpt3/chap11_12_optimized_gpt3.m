% Optimized Matlab code for energy efficiency

% Load and convert the image to grayscale
I = imread('leaf1.bmp');
bwI = im2bw(rgb2gray(I), graythresh(I));

% Process the binary image
bwIfilt = medfilt2(~bwI); % Median filtering
bwIfiltfh = imfill(bwIfilt, 'holes'); % Fill holes in the image

% Find and extract the largest boundary
bdI = bwboundaries(bwIfiltfh, 'noholes');
d = cellfun(@length, bdI);
[dmax, k] = max(d);
B4 = bdI{k};

% Generate a binary image from the boundary
[m, n] = size(bwIfiltfh);
xmin = min(B4(:, 2));
ymin = min(B4(:, 1));
bim = poly2mask(B4(:, 2) - ymin + 1, B4(:, 1) - xmin + 1, m, n);

% Find and connect the minimum perimeter polygon
[x, y] = minperim(bwIfiltfh, 4);
b2 = poly2mask(x - ymin + 1, y - xmin + 1, m, n);

% Plot the results
figure('Position', [100, 100, 1000, 500], 'Color', [1 1 1]);
subplot(1, 2, 1);
imshow(bim);
title('Original Image Boundary');
subplot(1, 2, 2);
imshow(b2);
title('Approximated Boundary using Minimum Perimeter Polygon');