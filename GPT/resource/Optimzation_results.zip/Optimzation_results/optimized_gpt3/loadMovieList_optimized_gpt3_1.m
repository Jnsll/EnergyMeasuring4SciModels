function movieList = loadMovieList()
%LOADMOVIELIST reads the fixed movie list in movie_ids.txt and returns a
%cell array of the movie names
%   movieList = LOADMOVIELIST() reads the fixed movie list in movie_ids.txt 
%   and returns a cell array of the movie names in movieList.

% Open the file containing movie names
fid = fopen('movie_ids.txt');

% Total number of movies 
n = 1682;  

% Initialize the cell array to store movie names
movieList = cell(n, 1);

% Read each line and extract movie name
for i = 1:n
    line = fgetl(fid); % Read line
    [~, movieName] = strtok(line, ' '); % Extract movie name
    movieList{i} = strtrim(movieName); % Store movie name in cell array
end

fclose(fid); % Close the file

end