clear
clc
tic 
pop_size = 15;
chromosome_size = 10;
epochs = 50;
cross_rate = 0.4;
mutation_rate = 0.1;
a0 = 0.7;
zpop_size = 5;
best_fitness = 0;
nf = 0;
number = 0;
Image = imread('bird.bmp');
q = isRgb(Image);
if q == 1
    Image = rgb2gray(Image);
end
[m, n] = size(Image);
p = imhist(Image);
p = p';
p = p / (m * n);
figure(1);
subplot(121);
imshow(Image);
title('ԭʼͼƬ');
hold on;
pop = round(rand(pop_size, chromosome_size));
for epoch = 1: epochs
    [fitness, threshold, number] = fitnessty(pop, chromosome_size, Image, pop_size, m, n, number);
    [best_fitness, nf, thres] = updateBestFitness(fitness, best_fitness, nf, threshold);
    [pop, number] = optimizePopulation(pop, fitness, cross_rate, mutation_rate, chromosome_size, pop_size, a0, zpop_size, Image, m, n, number);
    if epoch == epochs
        [fitness, threshold, number] = fitnessty(pop, chromosome_size, Image, pop_size, m, n, number);
    end
    drawResult(Image, thres);
    subplot(122)
    fprintf('threshold = %d', thres);
%     title('�ָ��Ľ��');
end
toc
subplot(122);
drawResult(Image, thres);
title('�ָ��Ժ�Ľ��');