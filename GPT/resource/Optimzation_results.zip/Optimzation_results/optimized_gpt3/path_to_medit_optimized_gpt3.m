function [s] = path_to_medit_optimized()
    % PATH_TO_MEDIT_OPTIMIZED Return path to medit executable in an optimized way
    %
    % s = path_to_medit_optimized()
    %
    % Outputs:
    %   s path to medit executable
    %
    % See also: medit
    %

    if ispc
        s = 'c:/prg/lib/medit/Release/medit.exe';
    elseif isunix || ismac
        % I guess this means linux
        [status, s] = system('which medit');
        s = strtrim(s);
        if status ~= 0
            guesses = { ...
                '/usr/local/bin/medit', ...
                '/opt/local/bin/medit'};
            s = find_first_path(guesses);
        end
    end
end

function path = find_first_path(paths)
    % FIND_FIRST_PATH Find the first existing path from a cell array of paths
    %
    % path = find_first_path(paths)
    %
    % Inputs:
    %   paths: cell array of paths to check
    %
    % Outputs:
    %   path: first existing path found, empty if none exist
    %
    
    for i = 1:length(paths)
        if exist(paths{i}, 'file') == 2
            path = paths{i};
            return;
        end
    end
    path = ''; % Return empty if no existing path found
end