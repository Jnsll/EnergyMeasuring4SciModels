% Optimized Matlab code for energy efficiency
clear;
clc;
%% Input parameters
county_size = 10;
countys_size = 40;
epoch = 200;
m = 2;      % Normalization elimination acceleration index, larger for larger values, smaller for smaller values
cross_rate = 0.4;
mutation_rate = 0.2;
%% Generate basic matrices
% Generate city coordinates
position = randn(county_size, 2);
% Generate distance matrix between cities
distance = pdist2(position, position);
% Generate initial population
population = zeros(countys_size, county_size);
for i = 1: countys_size
    population(i, :) = randperm(county_size);
end
%% Initialize population and fitness function
fitness = zeros(countys_size, 1);
len = arrayfun(@(x) myLength(distance, population(x, :)), 1:countys_size);
maxlen = max(len);
minlen = min(len);
fitness = fit(len, m, maxlen, minlen);
rr = find(len == minlen);  % Debug query result
pop = population(rr(1), :);
fprintf('%d  ', pop);
fprintf('\n');
fitness = fitness/sum(fitness);
distance_min = zeros(epoch + 1, 1);
population_sel = zeros(countys_size + 1, county_size);
%% Start iteration
while epoch >= 0
    fprintf('Iteration number: %d\n', epoch);
    nn = 0;
    p_fitness = cumsum(fitness);
    len_1 = arrayfun(@(x) myLength(distance, population(x, :)), 1:countys_size);
    for i = 1:size(population, 1)
        jc = rand;
        j = find(p_fitness > jc, 1);
        nn = nn + 1;
        population_sel(nn, :) = population(j, :);
    end
    % Save the best population each time it is selected
    population_sel = population_sel(1:nn, :);
    [len_m, len_index] = min(len_1);
    [len_max, len_index_max] = max(len_1);
    population_sel(len_index_max, :) = population_sel(len_index, :);
    % Crossover operation
    nnper = randperm(nn);
    A = population_sel(nnper(1), :);
    B = population_sel(nnper(2), :);
    for i = 1 : nn * cross_rate
        [A, B] = cross(A, B);
        population_sel(nnper(1), :) = A;
        population_sel(nnper(2), :) = B;
    end
    % Mutation operation
    for i = 1: nn
        pick = rand;
        if pick <= mutation_rate
            population_sel(i, :) = mutation(population_sel(i, :));
        end
    end
    % Reverse function
    for i = 1: nn
        population_sel(i,:) = reverse(population_sel(i,:), distance);
    end
    % Update fitness function
    len = arrayfun(@(x) myLength(distance, population_sel(x, :)), 1:size(population_sel, 1));
    maxlen = max(len);
    minlen = min(len);
    distance_min(epoch+1) = minlen;
    fitness = fit(len, m, maxlen, minlen);
    rr = find(len == minlen);  % Debug query result
    fprintf('minlen: %d\n', minlen);
    pop = population(rr(1), :);
    fprintf('%d  ', pop);
    fprintf('\n');
    population = population_sel;
    epoch = epoch - 1;
end
figure(3);
plot_route(position, pop)
xlabel('x');
ylabel('y');
title('Optimal city path distribution');
axis([-3, 3, -3, 3]);