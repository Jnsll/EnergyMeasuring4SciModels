% Load table calibration data
load('table_calibration.mat')

% Load global path data
load('global_path.mat')

vs_state = -1;
StopMode = -1;

% Mapping of right wheel ground angles to steering wheel angles
right_wheel_ground = -70:2.8:70;
rack_displacement = -39.14:1.27:29.94;

% Steering system C factor
c_factor = 43.75; % Unit: mm/rev

% Parameters
DEG2RAD = pi/180;
RAD2DEG = 180/pi;

% Vehicle parameters
cf = -175016;
cr = -130634;
m = 2020;
Iz = 4095.0;
la = 1.265;
lb = 1.682;

% LQR parameters
LQR_Q1 = 25;
LQR_Q2 = 3;
LQR_Q3 = 10;
LQR_Q4 = 4;
LQR_R = 15;

% Longitudinal double PID parameters
KP_PID_distance = 0.5;
KI_PID_distance = 0.0;
KD_PID_distance = 0.0;
KP_PID_speed = 1.8;
KI_PID_speed = 0;
KD_PID_speed = 0;

% LQR offline calculation
k = zeros(5000, 4);
vx_break_point = 0.01:0.01:50;

for i = 1:5000
    A = [0, 1, 0, 0;
         0, (cf+cr)/(m*vx_break_point(i)), -(cf+cr)/m, (la*cf-lb*cr)/(m*vx_break_point(i));
         0, 0, 0, 1;
         0, (la*cf-lb*cr)/(Iz*vx_break_point(i)), -(la*cf-lb*cr)/Iz, (la*la*cf+lb*lb*cr)/(Iz*vx_break_point(i))];
    B = [0;
         -cf/m;
         0;
         -la*cf/Iz];
    LQR_Q = 1*[LQR_Q1, 0, 0, 0;
               0, LQR_Q2, 0, 0;
               0, 0, LQR_Q3, 0;
               0, 0, 0, LQR_Q4];
    k(i, :) = lqr(A, B, LQR_Q, LQR_R);
end

LQR_K1 = k(:, 1)';
LQR_K2 = k(:, 2)';
LQR_K3 = k(:, 3)';
LQR_K4 = k(:, 4)';

% Initial vehicle position
host_x_init = 0;
host_y_init = 0;