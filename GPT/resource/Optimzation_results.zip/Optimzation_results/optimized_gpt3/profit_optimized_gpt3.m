% Optimize the Matlab code for energy efficiency
% Refactored code:

clear; % Clear workspace variables
close all; % Close all figures

% Load data from Excel file
data = xlsread('cumcm2012B����4_ɽ����ͬ������������ʱ���������������ǿ��.xls');
radiation_data = data(:, end-3:end); % Extract radiation data for four directions

% Filter out radiation values less than 30
radiation_data(radiation_data < 30) = 0;

% Calculate hourly energy for each direction
hourly_energy = sum(radiation_data);

% Convert hourly energy to daily energy
daily_energy = hourly_energy / 1000;

% Calculate annual energy production per square meter
annual_energy = daily_energy * 10 + daily_energy * 15 * 0.9 + daily_energy * 10 * 0.8;

% Calculate the economic benefit over 35 years per square meter without inverter efficiency
economic_benefit = annual_energy * 0.5;

% Load data for PV module design parameters and market prices
pv_data = xlsread('cumcm2012B_����3_�������͵Ĺ�����(A������B�ྦྷ��C�Ǿ��象Ĥ)�����Ʋ������г��۸�.xls');
module_price = 4.8;
length = pv_data(:, 2); % Length
width = pv_data(:, 3); % Width
voltage = pv_data(:, 4); % Voltage
current = pv_data(:, 5); % Current
efficiency = pv_data(:, 6); % Conversion efficiency

% Calculate power output of each PV module
power_output = voltage .* current;

% Calculate area of each PV module in square meters
area = length .* width / 1000000;

% Calculate price of each PV module
module_price_per_module = module_price .* power_output;

% Initialize matrix for storing profits over 35 years without considering inverter
profits = zeros(24, 4);

% Calculate profits for each PV module over 35 years without inverter
for i = 1:24
    profits(i, :) = economic_benefit * area(i) * efficiency(i) - module_price_per_module(i);
end

% Extract profits for C-type modules installed on all four walls over 35 years
profits_C_type = profits(14:24, :);