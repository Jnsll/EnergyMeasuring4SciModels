%% Optimize the Matlab code for energy efficiency

% Load city data
load citys_data.mat

% Calculate distance between cities using vectorized operations
n = size(citys,1);
D = sqrt(sum((permute(citys,[1,3,2]) - permute(citys,[3,1,2])).^2, 3);
D(1:n+1:end) = 1e-4;

% Initialize parameters
m = 50;
alpha = 1;
beta = 5;
rho = 0.1;
Q = 1;
Eta = 1./D;
Tau = ones(n,n);
Table = zeros(m,n);
iter = 1;
iter_max = 200;
Route_best = zeros(iter_max,n);
Length_best = zeros(iter_max,1);
Length_ave = zeros(iter_max,1);

while iter <= iter_max
    start = randi(n,m,1);
    Table(:,1) = start;
    
    for i = 1:m
        tabu = zeros(1,n);
        for j = 2:n
            tabu(j-1) = Table(i,j-1);
            allow = setdiff(1:n, tabu);
            P = Tau(tabu(end),allow).^alpha .* Eta(tabu(end),allow).^beta;
            P = P/sum(P);
            target = randsample(allow,1,true,P);
            Table(i,j) = target;
        end
    end
    
    Length = sum(D(sub2ind([n,n],Table(:,n),Table(:,1))));
    Length_best(iter) = min(Length_best(iter),Length);
    Length_ave(iter) = mean(Length);
    
    Delta_Tau = zeros(n,n);
    for i = 1:m
        for j = 1:n-1
            Delta_Tau(Table(i,j),Table(i,j+1)) = Delta_Tau(Table(i,j),Table(i,j+1)) + Q/Length;
        end
        Delta_Tau(Table(i,n),Table(i,1)) = Delta_Tau(Table(i,n),Table(i,1)) + Q/Length;
    end
    Tau = (1-rho) * Tau + Delta_Tau;
    
    iter = iter + 1;
end

[Shortest_Length,index] = min(Length_best);
Shortest_Route = Route_best(index,:);
disp(['Shortest distance: ' num2str(Shortest_Length)]);
disp(['Shortest path: ' num2str([Shortest_Route Shortest_Route(1)])]);

% Plot results
figure(1)
plot([citys(Shortest_Route,1);citys(Shortest_Route(1),1)],...
     [citys(Shortest_Route,2);citys(Shortest_Route(1),2)],'o-');
grid on
for i = 1:size(citys,1)
    text(citys(i,1),citys(i,2),['   ' num2str(i)]);
end
text(citys(Shortest_Route(1),1),citys(Shortest_Route(1),2),'       Start');
text(citys(Shortest_Route(end),1),citys(Shortest_Route(end),2),'       End');
xlabel('City X Position')
ylabel('City Y Position')
title(['Ant Colony Optimization Path (Shortest Distance: ' num2str(Shortest_Length) ')'])
figure(2)
plot(1:iter_max,Length_best,'b',1:iter_max,Length_ave,'r:')
legend('Shortest Distance','Average Distance')
xlabel('Iteration')
ylabel('Distance')
title('Comparison of Shortest and Average Distances')