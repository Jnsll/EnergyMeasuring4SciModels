%% Face Recognition using BP Neural Network

%% Clear Environment
clear all
clc

%% Extracting Facial Features
% Number of individuals
M = 10;
% Number of facial orientation categories
N = 5;
% Extracting feature vectors
pixel_value = feature_extraction(M, N);

%% Generating Training and Testing Sets
% Generating a random sequence of image indices
rand_label = randperm(M*N);
% Facial orientation labels
direction_label = [1 0 0; 1 1 0; 0 1 0; 0 1 1; 0 0 1];
% Training set
train_label = rand_label(1:30);
P_train = pixel_value(train_label, :)';
dtrain_label = train_label - floor(train_label/N)*N;
dtrain_label(dtrain_label == 0) = N;
T_train = direction_label(dtrain_label, :)';
% Testing set
test_label = rand_label(31:end);
P_test = pixel_value(test_label, :)';
dtest_label = test_label - floor(test_label/N)*N;
dtest_label(dtest_label == 0) = N;
T_test = direction_label(dtest_label, :)';

%% Creating BP Neural Network
net = newff(minmax(P_train), [10, 3], {'tansig', 'purelin'}, 'trainlm');
% Setting training parameters
net.trainParam.epochs = 1000;
net.trainParam.show = 10;
net.trainParam.goal = 1e-3;
net.trainParam.lr = 0.1;

%% Training the Network
net = train(net, P_train, T_train);

%% Simulation Testing
T_sim = sim(net, P_test);
T_sim(T_sim < 0.5) = 0;
T_sim(T_sim >= 0.5) = 1;
T_sim
T_test