% Optimized and refactored Matlab code for energy efficiency

% Clearing unnecessary variables and plots
clear variables;
close all;

% Setting parameters
fishnum = 50; % Number of artificial fish
MAXGEN = 50; % Maximum number of iterations
try_number = 100; % Maximum number of trials
visual = 1; % Perception distance
delta = 0.618; % Crowding factor
step = 0.1; % Step size

% Initializing fish population
lb_ub = [-1, 2, 1];
X = AF_init(fishnum, lb_ub);
LBUB = repelem(lb_ub(:, 1:2), lb_ub(:, 3), 1);

gen = 1;
BestY = -ones(1, MAXGEN); % Best function value at each step
BestX = -ones(1, MAXGEN); % Best independent variable at each step
besty = -100; % Best function value

Y = AF_foodconsistence(X);

while gen <= MAXGEN
    fprintf('Iteration: %d\n', gen)
    
    for i = 1:fishnum
        % Flocking behavior
        [Xi1, Yi1] = AF_swarm(X, i, visual, step, delta, try_number, LBUB, Y);
        
        % Following behavior
        [Xi2, Yi2] = AF_follow(X, i, visual, step, delta, try_number, LBUB, Y);
        
        if Yi1 > Yi2
            X(:, i) = Xi1;
            Y(1, i) = Yi1;
        else
            X(:, i) = Xi2;
            Y(1, i) = Yi2;
        end
    end
    
    [Ymax, index] = max(Y);
    
    if Ymax > besty
        besty = Ymax;
        bestx = X(:, index);
        BestY(gen) = Ymax;
        BestX(:, gen) = X(:, index);
    else
        BestY(gen) = BestY(gen - 1);
        BestX(:, gen) = BestX(:, gen - 1);
    end
    
    gen = gen + 1;
end

% Plotting the optimization process
figure;
plot(1:MAXGEN, BestY);
xlabel('Iterations');
ylabel('Optimization Value');
title('Optimization Process of Artificial Fish Algorithm');

disp(['Optimal Solution X: ', num2str(bestx', '%1.4f')]);
disp(['Optimal Solution Y: ', num2str(besty, '%1.4f')]);