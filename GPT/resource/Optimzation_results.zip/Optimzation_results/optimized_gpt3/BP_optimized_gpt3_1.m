%% Optimize the Matlab code for energy efficiency

% Load data directly without displaying messages
input = rand(4000, 10);
output = rand(4000, 1);

% Randomly shuffle data indices
n = randperm(4000);

% Extract training and testing data
input_train = input(n(1:3900), :)';
output_train = output(n(1:3900), :)';
input_test = input(n(3901:4000), :)';
output_test = output(n(3901:4000), :)';

% Normalize input and output data
[inputn, inputps] = mapminmax(input_train);
[outputn, outputps] = mapminmax(output_train);

% Initialize and train the neural network
net = newff(inputn, outputn, 5);
net.trainParam.epochs = 100;
net.trainParam.lr = 0.1;
net.trainParam.goal = 0.0000004;
net = train(net, inputn, outputn);

% Normalize test input data and predict output
inputn_test = mapminmax('apply', input_test, inputps);
an = sim(net, inputn_test);

% Reverse normalize the predicted output
BPoutput = mapminmax('reverse', an, outputps);

% Calculate prediction error
error = BPoutput - output_test;

% Display results
figure;
plot(BPoutput, ':og');
hold on;
plot(output_test, '-*');
legend('Predicted Output', 'Expected Output', 'fontsize', 12);
title('Neural Network Prediction Output', 'fontsize', 12);
xlabel('Sample', 'fontsize', 12);
ylabel('Output', 'fontsize', 12);

figure;
plot(error, '-*');
title('Neural Network Prediction Error');

figure;
plot((output_test - BPoutput) ./ BPoutput, '-*');
title('Neural Network Prediction Error Percentage');

errorsum = sum(abs(error));

save data net inputps outputps;