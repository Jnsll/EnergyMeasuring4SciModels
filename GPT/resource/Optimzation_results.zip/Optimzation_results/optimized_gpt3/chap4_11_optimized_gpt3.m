% Optimize Matlab code for energy efficiency

% Read the image 'house.jpg' and store it in variable A
A = imread('house.jpg');

% Create variables B and C by multiplying image A with scaling factors 1.5 and 0.5 respectively
B = immultiply(A, 1.5);
C = immultiply(A, 0.5);

% Set default figure properties for position and background color
set(groot,'defaultFigurePosition',[100,100,1000,500]);
set(groot,'defaultFigureColor',[1 1 1]);

% Display the images B and C in a subplot
figure;
subplot(1,2,1);
imshow(B);
axis on;
subplot(1,2,2);
imshow(C);
axis on;