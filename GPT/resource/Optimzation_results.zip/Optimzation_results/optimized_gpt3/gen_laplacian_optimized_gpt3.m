addpath matting/
addpath gaimc/
N = 60;

prefix = '../examples/input/';
for i = 1:N
    in_name = [prefix 'in' int2str(i) '.png']; 
    disp(['Working on image index = ' int2str(i)]);
    
    input = im2double(imread(in_name));
    input = reshape_img(input, 700);
    
    figure; imshow(input);
    
    [h, w, ~] = size(input);
    
    disp('Compute Laplacian');
    A = getLaplacian1(input, zeros(h, w), 1e-7, 1);
    
    disp('Save to disk');
    [Ai, Aj, Aval] = find(A);
    CSR = [sort(Ai), Aj, Aval];
    save(['Input_Laplacian_3x3_1e-7_CSR' int2str(i) '.mat'], 'CSR');
end