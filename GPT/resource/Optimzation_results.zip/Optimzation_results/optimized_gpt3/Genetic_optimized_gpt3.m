% Clear workspace
clc
clear

% Load data
load data input output

% Define network structure
inputnum = 2;
hiddennum = 5;
outputnum = 1;

% Split data into training and testing sets
input_train = input(1:1900, :)';
input_test = input(1901:2000, :)';
output_train = output(1:1900)';
output_test = output(1901:2000)';

% Normalize input and output data
[inputn, inputps] = mapminmax(input_train);
[outputn, outputps] = mapminmax(output_train);

% Build the network
net = newff(inputn, outputn, hiddennum);

% Genetic algorithm parameters initialization
maxgen = 10;
sizepop = 10;
pcross = 0.3;
pmutation = 0.1;

% Calculate total number of nodes in the network
numsum = inputnum * hiddennum + hiddennum + hiddennum * outputnum + outputnum;

lenchrom = ones(1, numsum);
bound = [-3 * ones(numsum, 1) 3 * ones(numsum, 1)];

% Initialize population
individuals = struct('fitness', zeros(1, sizepop), 'chrom', []);
avgfitness = [];
bestfitness = [];
bestchrom = [];

% Initialize population
for i = 1:sizepop
    individuals.chrom(i, :) = Code(lenchrom, bound);
    x = individuals.chrom(i, :);
    individuals.fitness(i) = fun(x, inputnum, hiddennum, outputnum, net, inputn, outputn);
end

[bestfitness, bestindex] = min(individuals.fitness);
bestchrom = individuals.chrom(bestindex, :);
avgfitness = sum(individuals.fitness) / sizepop;
trace = [avgfitness bestfitness];

% Evolution process
for i = 1:maxgen
    individuals = Select(individuals, sizepop);
    avgfitness = sum(individuals.fitness) / sizepop;
    individuals.chrom = Cross(pcross, lenchrom, individuals.chrom, sizepop, bound);
    individuals.chrom = Mutation(pmutation, lenchrom, individuals.chrom, sizepop, i, maxgen, bound);

    for j = 1:sizepop
        x = individuals.chrom(j, :);
        individuals.fitness(j) = fun(x, inputnum, hiddennum, outputnum, net, inputn, outputn);
    end

    [newbestfitness, newbestindex] = min(individuals.fitness);
    [worestfitness, worestindex] = max(individuals.fitness);

    if bestfitness > newbestfitness
        bestfitness = newbestfitness;
        bestchrom = individuals.chrom(newbestindex, :);
    end

    individuals.chrom(worestindex, :) = bestchrom;
    individuals.fitness(worestindex) = bestfitness;

    avgfitness = sum(individuals.fitness) / sizepop;
    
    trace = [trace; avgfitness bestfitness];
end

% Plot fitness curve
figure(1)
[r, ~] = size(trace);
plot([1:r]', trace(:, 2), 'b--');
title(['Fitness Curve  ' 'Termination Generation = ' num2str(maxgen)]);
xlabel('Generation');
ylabel('Fitness');
legend('Average Fitness', 'Best Fitness');
disp('Fitness                   Variables');
x = bestchrom;

% Assign optimized values to the network for prediction
w1 = x(1:inputnum*hiddennum);
B1 = x(inputnum*hiddennum+1:inputnum*hiddennum+hiddennum);
w2 = x(inputnum*hiddennum+hiddennum+1:inputnum*hiddennum+hiddennum+hiddennum*outputnum);
B2 = x(inputnum*hiddennum+hiddennum+hiddennum*outputnum+1:inputnum*hiddennum+hiddennum+hiddennum*outputnum+outputnum);

net.IW{1, 1} = reshape(w1, hiddennum, inputnum);
net.LW{2, 1} = reshape(w2, outputnum, hiddennum);
net.b{1} = reshape(B1, hiddennum, 1);
net.b{2} = B2;

% Train the network
net.trainParam.epochs = 100;
net.trainParam.lr = 0.1;

[net, ~] = train(net, inputn, outputn);

% Predict using the trained network
inputn_test = mapminmax('apply', input_test, inputps);
an = sim(net, inputn_test);
test_simu = mapminmax('reverse', an, outputps);
error = test_simu - output_test;