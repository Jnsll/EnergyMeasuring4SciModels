% Clear environment variables
warning('off')           % Disable warning messages
close all                 % Close all figure windows
clear                     % Clear workspace variables
clc                       % Clear command window

% Load saved files
load('net.mat')
load('ps_input.mat')
load('ps_output.mat')

% Read data to be predicted
kes = xlsread('待预测数据.xlsx');

% Transpose the data
kes = kes';

% Normalize the data
n_test = mapminmax('apply', kes, ps_input);

% Perform simulation test
t_sim3 = sim(net, n_test);

% Reverse the normalization of the data
T_sim3 = mapminmax('reverse', t_sim3, ps_output);

% Save the results
xlswrite('预测结果.xlsx', T_sim3)