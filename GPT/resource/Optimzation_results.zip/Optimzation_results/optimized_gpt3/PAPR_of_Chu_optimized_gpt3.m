% Optimized and Refactored Matlab Code for Energy Efficiency
% PAPR_of_Chu_optimized.m

% MIMO-OFDM Wireless Communications with MATLAB�� Yong Soo Cho, Jaekwon Kim, Won Young Yang and Chung G. Kang
% 2010 John Wiley & Sons (Asia) Pte Ltd

clear; clf;

% Parameters
N = 16;
L = 4;
i = 0:N-1;
k = 3;

% Generate X
X = exp(1j*k*pi/N*(i.^2));

% Perform IFFT oversampling
[x, time] = IFFT_oversampling(X, N);
PAPRdB = PAPR(x);

% Perform IFFT oversampling with factor L
[x_os, time_os] = IFFT_oversampling(X, N, L);
PAPRdB_os = PAPR(x_os);

% Plotting
subplot(2, 2, 1);
plot(x, 'o');
hold on;
plot(x_os, 'k*');
axis([-0.4 0.4 -0.4 0.4]);
axis equal;
plot(0.25*exp(1j*pi/180*(0:359))); % Circle with radius 0.25

subplot(2, 2, 2);
plot(time, abs(x), 'o', time_os, abs(x_os), 'k:*');

PAPRdB_without_and_with_oversampling = [PAPRdB, PAPRdB_os];