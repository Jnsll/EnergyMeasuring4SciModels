% =============================
% = Testing standard matrices =
% =============================

% Generate random data
data = randn(4,9);

% Save and load full matrices in different formats
om_save_full(data,'test.txt','ascii');
om_save_full(data,'test.bin','binary');
om_save_full(data,'test.mat','matlab');

data_txt = om_load_full('test.txt','ascii');
data_bin = om_load_full('test.bin','binary');
data_mat = om_load_full('test.mat','matlab');

% Calculate and display differences
norm(data_txt - data)
norm(data_bin - data)
norm(data_mat - data)

% Clean up created files
delete 'test.txt'
delete 'test.bin'
delete 'test.mat'

% =============================
% = Testing symmetric matrices =
% =============================

% Generate symmetric data
randn('seed',0);
data = randn(5,5);
data = (data+data')/2;

% Save and load symmetric matrices in different formats
om_save_sym(data,'test.txt','ascii');
om_save_sym(data,'test.bin','binary');
om_save_sym(data,'test.mat','matlab');

data_txt = om_load_sym('test.txt','ascii');
data_bin = om_load_sym('test.bin','binary');
data_mat = om_load_sym('test.mat','matlab');

% Calculate and display differences
norm(data_txt - data)
norm(data_bin - data)
norm(data_mat - data)

% Clean up created files
delete 'test.txt'
delete 'test.bin'
delete 'test.mat'

% =============================
% = Testing sparse matrices =
% =============================

% Generate sparse data
data = sprand(5,5,0.5);

% Save and load sparse matrices in different formats
om_save_sparse(data,'test.txt','ascii');
om_save_sparse(data,'test.bin','binary');
om_save_sparse(data,'test.mat','matlab');

data_txt = om_load_sparse('test.txt','ascii');
data_bin = om_load_sparse('test.bin','binary');
data_mat = om_load_sparse('test.mat','matlab');

% Calculate and display differences
norm(full(data_txt - data))
norm(full(data_bin - data))
norm(full(data_mat - data))

% Clean up created files
delete 'test.txt'
delete 'test.bin'
delete 'test.mat'