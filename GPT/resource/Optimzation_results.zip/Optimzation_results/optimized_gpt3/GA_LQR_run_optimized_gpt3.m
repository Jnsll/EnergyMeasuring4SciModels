% Optimized and refactored Matlab code for energy efficiency

clear; % Clear the workspace
clc; % Clear the command window

% Define the fitness function handle
fitnessfcn = @GA_LQR;

% Define the number of variables for each individual
nvars = 3;

% Define the lower and upper bounds for the variables
LB = [0.1, 0.1, 0.1];
UB = [1e6, 1e6, 1e6];

% Set the options for the genetic algorithm
options = gaoptimset('PopulationSize', 100, 'PopInitRange', [LB; UB], 'EliteCount', 10, ...
    'CrossoverFraction', 0.4, 'Generations', 20, 'StallGenLimit', 20, 'TolFun', 1e-100, ...
    'PlotFcns', {@gaplotbestf, @gaplotbestindiv});

% Run the genetic algorithm to find the best solution
[x_best, fval] = ga(fitnessfcn, nvars, [], [], [], [], LB, UB, [], options);