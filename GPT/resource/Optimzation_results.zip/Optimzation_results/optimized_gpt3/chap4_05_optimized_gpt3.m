% Optimize Matlab code for energy efficiency
% Refactored code

% Clear all variables and close all figures
clear variables;
close all;

% Read the image 'flower.tif'
I = imread('flower.tif');

% Increase each pixel value by 30
J = imadd(I, 30);

% Set default figure position and background color
set(groot, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(groot, 'defaultFigureColor', [1, 1, 1]);

% Display original and modified images
subplot(1, 2, 1);
imshow(I);
title('Original Image');

subplot(1, 2, 2);
imshow(J);
title('Image with Increased Brightness');