% Optimized and refactored code for energy efficiency

% Store the current directory
cur_dir = pwd;

% Change directory to the location of the current script
cd(fileparts(mfilename('fullpath')));

try
    fprintf('Downloading region proposals...\n');
    url = 'https://onedrive.live.com/download?resid=F371D9563727B96F!91965&authkey=!AErVqYD6NhjxAfw';
    
    % Use websave instead of urlwrite for improved performance
    websave('proposals.zip', url);

    fprintf('Unzipping...\n');
    unzip('proposals.zip', '..');

    fprintf('Done.\n');
    
    % Delete the downloaded zip file after extraction
    delete('proposals.zip');
catch
    fprintf('Error in downloading, please try links in README.md https://github.com/daijifeng001/R-FCN'); 
end

% Change back to the original directory
cd(cur_dir);