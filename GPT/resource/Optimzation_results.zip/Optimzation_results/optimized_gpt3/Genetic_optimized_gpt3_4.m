% Clear the workspace
clc
clear

% Genetic algorithm parameters
maxgen = 30;             % Number of generations
sizepop = 100;           % Population size
pcross = 0.6;            % Crossover probability
pmutation = 0.01;        % Mutation probability
lenchrom = [1 1];        % Chromosome length
bound = [-5 5; -5 5];   % Variable bounds

% Individual initialization
individuals = struct('fitness', zeros(1, sizepop), 'chrom', []);  
avgfitness = [];                                               
bestfitness = [];                                              
bestchrom = [];                                                
% Initialize population
for i = 1:sizepop
    individuals.chrom(i, :) = Code(lenchrom, bound);       
    x = individuals.chrom(i, :);
    individuals.fitness(i) = fun(x);                     
end

% Find the best chromosome
[bestfitness, bestindex] = min(individuals.fitness);
bestchrom = individuals.chrom(bestindex, :);  
avgfitness = sum(individuals.fitness) / sizepop; 

% Evolution loop
trace = []; 
for i = 1:maxgen
     % Selection
     individuals = Select(individuals, sizepop); 
     avgfitness = sum(individuals.fitness) / sizepop;
     % Crossover
     individuals.chrom = Cross(pcross, lenchrom, individuals.chrom, sizepop, bound);
     % Mutation
     individuals.chrom = Mutation(pmutation, lenchrom, individuals.chrom, sizepop, [i maxgen], bound);
    
    % Calculate fitness 
    for j = 1:sizepop
        x = individuals.chrom(j, :);
        individuals.fitness(j) = fun(x);   
    end
    
    % Update best chromosome
    [newbestfitness, newbestindex] = min(individuals.fitness);
    [worestfitness, worstindex] = max(individuals.fitness);
    
    if bestfitness > newbestfitness
        bestfitness = newbestfitness;
        bestchrom = individuals.chrom(newbestindex, :);
    end
    individuals.chrom(worestindex, :) = bestchrom;
    individuals.fitness(worestindex) = bestfitness;
    
    avgfitness = sum(individuals.fitness) / sizepop;
    
    trace = [trace; avgfitness bestfitness]; 
end

% Display results
[r, c] = size(trace);
figure
plot([1:r]', trace(:, 1), 'r-', [1:r]', trace(:, 2), 'b--');
title(['Fitness Curve  ' 'Generations = ' num2str(maxgen)], 'fontsize', 12);
xlabel('Generations', 'fontsize', 12); ylabel('Fitness', 'fontsize', 12);
legend('Average Fitness', 'Best Fitness', 'fontsize', 12);
ylim([-0.5 5])
disp('Fitness                   Variables');
disp([bestfitness x]);