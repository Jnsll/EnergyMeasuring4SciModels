%% Load and preprocess data
clear all
clc
load class.mat

% Combine classes into target vector
T = [class_1 class_2 class_3 class_4 class_5];

% Create Hopfield network
net = newhop(T);

% Load and prepare samples for classification
load sim.mat
A = {sim_1 sim_2 sim_3 sim_4 sim_5};

% Simulate the network
Y = sim(net, {25 20}, {}, A);

% Display results
Y1 = Y{20}(:, 1:5);
Y2 = Y{20}(:, 6:10);
Y3 = Y{20}(:, 11:15);
Y4 = Y{20}(:, 16:20);
Y5 = Y{20}(:, 21:25);

% Visualize results
result = {T; A{1}; Y{20}};
figure
for p = 1:3
    for k = 1:5
        subplot(3, 5, (p-1)*5 + k)
        temp = result{p}(:, (k-1)*5 + 1:k*5);
        [m, n] = size(temp);
        imagesc(temp);
        colormap(gray);
        title(['class' num2str(k)]) % Update subplot title
    end
end

% Generate noisy data for testing
noisy = [1 -1 -1 -1 -1; -1 -1 -1 1 -1; -1 1 -1 -1 -1; -1 1 -1 -1 -1;
         1 -1 -1 -1 -1; -1 -1 1 -1 -1; -1 -1 -1 1 -1; -1 -1 -1 -1 1;
         -1 1 -1 -1 -1; -1 -1 -1 1 -1; -1 -1 1 -1 -1];

% Test the network with noisy data
y = sim(net, {5 100}, {}, {noisy});
a = y{100};