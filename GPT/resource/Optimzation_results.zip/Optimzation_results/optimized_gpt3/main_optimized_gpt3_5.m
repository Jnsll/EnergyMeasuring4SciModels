% This is the refactored and optimized version of the Matlab script for solving the Traveling Salesman Problem using Genetic Algorithm.

clear; clc;

% Load geographic information and plot the map of China
load china;
plotcities(province, border, city);

% Parameters
numberofcities = length(city);
dis = distancematrix(city);
popSize = 100;
max_generation = 1000;
probmutation = 0.16;

% Initialize population with random routes
pop = zeros(popSize, numberofcities);
for i = 1:popSize
    pop(i, :) = randperm(numberofcities);
end

for generation = 1:max_generation
    % Evaluate fitness of individuals in the population
    popDist = totaldistance(pop, dis);
    fitness = 1./popDist;

    % Find the best route and distance
    [mindist, bestID] = min(popDist);
    bestPop = pop(bestID, :);

    % Update best route on figure every 10 generations
    if mod(generation, 10) == 0
        plotroute(city, bestPop, mindist, generation);
    end

    % Select individuals for the next generation
    pop = select(pop, fitness, popSize, 'competition');

    % Apply crossover
    pop = crossover(pop);

    % Apply mutation
    pop = mutation(pop, probmutation);

    % Save elitism (best path) and include it in the next generation
    pop = [bestPop; pop];
end

% Return the best route
[mindist, bestID] = min(popDist);
bestPop = pop(bestID, :);

% Plot and output the final solution
plotroute(city, bestPop, mindist, generation);
fpdfprinter('Final Solution');