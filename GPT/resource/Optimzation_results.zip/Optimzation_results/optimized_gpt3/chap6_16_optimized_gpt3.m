clear all; close all;

% Load the image
I = imread('cameraman.tif');
I = im2double(I);

% Get image dimensions
[m, n] = size(I);

% Upscale image dimensions
M = 2 * m;
N = 2 * n;

% Create frequency grids
u = -m/2 : m/2 - 1;
v = -n/2 : n/2 - 1;
[U, V] = meshgrid(u, v);

% Compute distance matrix
D = sqrt(U.^2 + V.^2);
D0 = 130;

% Generate filter
H = exp(-(D.^2) / (2 * (D0^2)));

% Add Gaussian noise
N = 0.01 * ones(size(I));
N = imnoise(N, 'gaussian', 0, 0.001);

% Apply filtering
J = fftfilter(I, H) + N;

% Display original and filtered images
figure;
subplot(121); imshow(I);
subplot(122); imshow(J, []);

% High-pass filtering
HC = zeros(m, n);
M1 = H > 0.1;
HC(M1) = 1 ./ H(M1);
K = fftfilter(J, HC);

% Low-pass filtering
HC = zeros(m, n);
M2 = H > 0.01;
HC(M2) = 1 ./ H(M2);
L = fftfilter(J, HC);

% Display filtered images
figure;
subplot(121); imshow(K, []);
subplot(122); imshow(L, []);