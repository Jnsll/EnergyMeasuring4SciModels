clear; clc;

% Load data from Excel file
fushe = xlsread('cumcm.xls', 'sheet', 'E4:M8763');
dianban = xlsread('cumcm.xls', 'sheet1', 'B1:F24');

% Calculate required variables
tz_zs = fushe(:, 1) - fushe(:, 2);
thta = 59.76 / 57.3;
sa = sin(thta);
ca = cos(thta);
fushe_renyi = tz_zs * ca + fushe(:, 2) * (pi - thta) / pi;

P = 52.5; % Module rated power
p0 = 30; % Minimum intensity

% Optimize the energy efficiency loop
fushe(fushe < p0) = 0;
% fushe(fushe < 200) = fushe(fushe < 200) * 0.05; % Commented out as per optimization

Q = sum(fushe * P / 1000) / 1000;