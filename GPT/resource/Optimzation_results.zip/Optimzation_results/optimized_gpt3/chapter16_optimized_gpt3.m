%% Load and Split Data
clc
clear

load gene.mat;
data = gene;
P = data(1:40, :)';
T = data(41:60, :)';

%% Normalize Data
Q = minmax(P);

%% Create and Train Neural Network
net = newc(Q, 2, 0.1);
net = init(net);
net.trainParam.epochs = 20;
net = train(net, P);

%% Validate Network Performance
a = sim(net, P);
ac = vec2ind(a);

%% Predict with Test Data
Y = sim(net, T);
yc = vec2ind(Y);