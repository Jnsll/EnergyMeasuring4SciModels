% Optimized Matlab code for energy efficiency

clc; 

% Define directories
dir1 = 'debug_coke_update_1\'; 
dir2 = 'debug_coke_update_2\'; 
dir3 = 'debug_coke_update_3\'; 
dirO = 'coke_1-2-3\';         

% Create output directory if it doesn't exist
if ~isfolder(dirO)
    mkdir(dirO);
end

% Get image files from directories
files1 = img_dir(dir1);
files2 = img_dir(dir2);
files3 = img_dir(dir3);

% Iterate through the files
for i = 1:numel(files1)
    
    img1 = imread(files1(i).name);
    img2 = imread(files2(i).name);
    img3 = imread(files3(i).name);
    
    % Concatenate images horizontally
    imgO = cat(2, img1, img2, img3);
   
    % Write the concatenated image to the output directory
    imwrite(imgO, [dirO, n2s(i, 5), '.jpg'], 'jpeg');
    
end