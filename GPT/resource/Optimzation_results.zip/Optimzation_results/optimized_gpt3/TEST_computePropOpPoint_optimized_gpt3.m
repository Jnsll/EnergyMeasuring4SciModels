disp('Running: TEST_computePropOpPoint.m')

%% Single operating points
% define some basic parameters
rho = 1.225;
d_prop = 0.305;
C_t = 0.0849;
C_q = 0.0111;

%% RPM = 0 
disp('Test 1 - RPM = 0')
[RPM_values, thrust_values, torque_values] = deal(0, 0, 0);
[RPM_values(2), thrust_values(2), torque_values(2)] = deal(1000, 0, 0);
[RPM_values(3), thrust_values(3), torque_values(3)] = deal([1000 2000 3000], 0, 0);

for i = 1:numel(RPM_values)
    RPM = RPM_values(i);
    [thrust, torque] = computePropOpPoint(RPM, rho, d_prop, C_t, C_q);
    thrust_values(i) = thrust;
    torque_values(i) = torque;
    disp(['Test ', num2str(i), ' - RPM = ', num2str(RPM)]);
end

disp('TEST_computePropOpPoint.m ran without error');