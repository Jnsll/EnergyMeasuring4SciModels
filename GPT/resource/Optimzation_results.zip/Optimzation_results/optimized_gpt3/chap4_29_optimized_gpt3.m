% Optimize Matlab code for energy efficiency
% Refactored code

% Read the image
I = imread('peppers.png');

% Rotate blocks by 30 degrees
fun_rotate = @(block_struct) imrotate(block_struct.data, 30);
I_rotated = blockproc(I, [64 64], fun_rotate);

% Calculate standard deviation of blocks
fun_std = @(block_struct) std2(block_struct.data);
I_std = blockproc(I, [32 32], fun_std);

% Rearrange color channels
fun_rearrange = @(block_struct) block_struct.data(:, :, [3 1 2]);
blockproc(I, [100 100], fun_rearrange, 'Destination', 'brg_peppers.tif');

% Set default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(0, 'defaultFigureColor', [1 1 1]);

% Display processed results
figure
subplot(131), imshow(I_rotated);
subplot(132), imshow(I_std, []);
subplot(133), imshow('brg_peppers.tif');