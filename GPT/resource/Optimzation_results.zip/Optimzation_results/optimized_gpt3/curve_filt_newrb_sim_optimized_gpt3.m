% curve_filt_newrb_sim_optimized.m

% Original training data
x = -9:8;
y = [129, -32, -118, -138, -125, -97, -55, -23, -4, 2, 1, -31, -72, -121, -142, -174, -155, -77];

% Test data
xx = -9:0.2:8;

% Load trained model saved in example.mat
load curve_filt_newrb_build.mat net

% Network simulation
yy = sim(net, xx);

% Plot original data points and simulated fitting data
figure;
plot(x, y, 'o');
hold on;
plot(xx, yy, '-');
hold off;

% Legend and title
legend('Original Data', 'Fitted Data');
title('Curve Fitting with Radial Basis Functions');