% Clear environment variables
clc
clear

%% Network structure setup
% Load data
load data input output

% Number of nodes
inputnum = 2;
hiddennum = 5;
outputnum = 1;

% Training and testing data
input_train = input(1:1900, :)';
input_test = input(1901:2000, :)';
output_train = output(1:1900)';
output_test = output(1901:2000)';

% Normalize input and output data
[inputn, inputps] = mapminmax(input_train);
[outputn, outputps] = mapminmax(output_train);

% Build the network
net = newff(inputn, outputn, hiddennum);

%% Genetic algorithm parameter initialization
maxgen = 10; % Number of generations
sizepop = 10; % Population size
pcross = 0.3; % Crossover probability
pmutation = 0.1; % Mutation probability

% Total number of nodes
numsum = inputnum * hiddennum + hiddennum + hiddennum * outputnum + outputnum;

lenchrom = ones(1, numsum);
bound = [-3 * ones(numsum, 1), 3 * ones(numsum, 1)]; % Data range

% Population initialization
individuals = struct('fitness', zeros(1, sizepop), 'chrom', []);
avgfitness = []; % Average fitness of each generation
bestfitness = []; % Best fitness of each generation
bestchrom = []; % Best chromosome
% Initialize population
for i = 1:sizepop
    individuals.chrom(i, :) = Code(lenchrom, bound);
    x = individuals.chrom(i, :);
    individuals.fitness(i) = fun(x, inputnum, hiddennum, outputnum, net, inputn, outputn);
end

% Find the best chromosome
[bestfitness, bestindex] = min(individuals.fitness);
bestchrom = individuals.chrom(bestindex, :);
avgfitness = sum(individuals.fitness) / sizepop;
trace = [avgfitness, bestfitness];

%% Iteratively find the optimal threshold and weights
% Evolution process
for i = 1:maxgen
    % Selection
    individuals = Select(individuals, sizepop);
    avgfitness = sum(individuals.fitness) / sizepop;
    % Crossover
    individuals.chrom = Cross(pcross, lenchrom, individuals.chrom, sizepop, bound);
    % Mutation
    individuals.chrom = Mutation(pmutation, lenchrom, individuals.chrom, sizepop, i, maxgen, bound);

    % Calculate fitness
    for j = 1:sizepop
        x = individuals.chrom(j, :);
        individuals.fitness(j) = fun(x, inputnum, hiddennum, outputnum, net, inputn, outputn);
    end

    [newbestfitness, newbestindex] = min(individuals.fitness);
    [worestfitness, worestindex] = max(individuals.fitness);

    if bestfitness > newbestfitness
        bestfitness = newbestfitness;
        bestchrom = individuals.chrom(newbestindex, :);
    end
    individuals.chrom(worestindex, :) = bestchrom;
    individuals.fitness(worestindex) = bestfitness;

    avgfitness = sum(individuals.fitness) / sizepop;

    trace = [trace; avgfitness, bestfitness];
end

%% Genetic algorithm result analysis
figure(1)
[r, c] = size(trace);
plot([1:r]', trace(:, 2), 'b--');
title(['Fitness Curve  ' 'Termination Generation = ' num2str(maxgen)]);
xlabel('Generation');
ylabel('Fitness');
legend('Average Fitness', 'Best Fitness');
disp('Fitness                   Variables');
x = bestchrom;

%% Assign the optimal threshold and weights to the network for prediction
w1 = x(1:inputnum * hiddennum);
B1 = x(inputnum * hiddennum + 1:inputnum * hiddennum + hiddennum);
w2 = x(inputnum * hiddennum + hiddennum + 1:inputnum * hiddennum + hiddennum + hiddennum * outputnum);
B2 = x(inputnum * hiddennum + hiddennum + hiddennum * outputnum + 1:inputnum * hiddennum + hiddennum + hiddennum * outputnum + outputnum);

net.iw{1, 1} = reshape(w1, hiddennum, inputnum);
net.lw{2, 1} = reshape(w2, outputnum, hiddennum);
net.b{1} = reshape(B1, hiddennum, 1);
net.b{2} = B2;

%% Train the BP network
% Network evolution parameters
net.trainParam.epochs = 100;
net.trainParam.lr = 0.1;

% Train the network
[net, per2] = train(net, inputn, outputn);

%% Predict using the BP network
inputn_test = mapminmax('apply', input_test, inputps);
an = sim(net, inputn_test);
test_simu = mapminmax('reverse', an, outputps);
error = test_simu - output_test;