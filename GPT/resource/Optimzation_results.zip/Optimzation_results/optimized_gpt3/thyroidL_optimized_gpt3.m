load thyroid_app
load thyroid_test
thyroid_test = thyroid_test';

[N, Napp] = size(thyroid_app);
[~, Ntest] = size(thyroid_test);

m = Napp + Ntest;

class = 1;

app = thyroid_app;
test = thyroid_test;

unique_app = unique(app(class,:));
unique_test = unique(test(class,:));

ns = max(thyroid_app');
clear thyroid_app thyroid_test;