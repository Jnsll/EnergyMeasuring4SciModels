% Consider matching sources to detections

% Define sources and detections coordinates
sources = [0.1 0.7; 0.6 0.4];
detections = [0.2 0.2; 0.2 0.8; 0.7 0.1];

% Calculate squared distances between sources and detections
dst = pdist2(sources, detections, 'squaredeuclidean');

% Find optimal matching based on the calculated distances
a = optimalMatching(dst);