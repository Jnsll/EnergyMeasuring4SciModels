% Optimized and refactored code for energy efficiency

% Store the current directory
cur_dir = pwd;

% Change directory to the location of the current script
script_dir = fileparts(mfilename('fullpath'));
cd(script_dir);

try
    % Download the model_ResNet-50L
    fprintf('Downloading model_ResNet-50L...\n');
    url = 'https://onedrive.live.com/download?resid=F371D9563727B96F!91962&authkey=!AET2I7W3WzcDyf8';
    filename = 'models_ResNet-50L.zip';
    websave(filename, url);

    % Unzip the downloaded file to the parent directory
    fprintf('Unzipping...\n');
    unzip(filename, '..');

    % Display completion message
    fprintf('Done.\n');

    % Delete the downloaded zip file
    delete(filename);
catch
    % Display error message if download fails
    fprintf('Error in downloading, please try links in README.md https://github.com/daijifeng001/R-FCN'); 
end

% Change back to the original directory
cd(cur_dir);