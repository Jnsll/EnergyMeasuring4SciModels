% �������ں��ڴ�
clear
clc

% Parameters
N = 20; % Number of cities
M = N - 1; % Population size

% Generate city coordinates
pos = randn(N, 2);

% Calculate distances between cities
D = pdist2(pos, pos);

% Intermediate results storage
TmpResult = [];
TmpResult1 = [];

% Parameters
pCharChange = 1; % Character swap probability
pStrChange = 0.4; % String swap probability
pStrReverse = 0.4; % String reverse probability
pCharReCompose = 0.4; % Character recombination probability
MaxIterateNum = 100; % Maximum number of iterations

% Initialize data
mPopulation = zeros(N-1, N);
mRandM = randperm(N-1) + 1; % Initial best path

for rol = 1:N-1
    mPopulation(rol, :) = randperm(N); % Generate initial antibodies
    mPopulation(rol, :) = DisplaceInit(mPopulation(rol, :)); % Pre-process
end

% Iterations
count = 0;
figure(2);
best_pop = zeros(MaxIterateNum, N);
while count < MaxIterateNum
    % Generate new antibodies
    B = Mutation(mPopulation, [pCharChange, pStrChange, pStrReverse, pCharReCompose]);
    mPopulation = SelectAntigen(mPopulation, B);
    
    % Plot and display results
    hold on
    plot(count, TmpResult(end), 'o');
    drawnow
    disp(TmpResult(end));
    disp(TmpResult1(end));
    best_pop(count + 1, :) = mPopulation(1, :);
    
    count = count + 1;
end

hold on
plot(TmpResult, '-r');
title('Best Fitness Trend')
xlabel('Iterations')
ylabel('Best Fitness')
figure(1)
DrawRouteGif(pos, best_pop);