% Simulated Annealing Algorithm
clear;

% Program parameters setting
Coord = [0.6683 0.6195 0.4 0.2439 0.1707 0.2293 0.5171 0.8732 0.6878 0.8488; ...
         0.2536 0.2634 0.4439 0.1463 0.2293 0.761 0.9414 0.6536 0.5219 0.3609];
t0 = 1; % Initial temperature t0
iLk = 20; % Maximum iterations for inner loop iLk
oLk = 50; % Maximum iterations for outer loop oLk
lam = 0.95; % �� lambda
istd = 0.001; % Stop if the variance of inner loop function values is less than istd
ostd = 0.001; % Stop if the variance of outer loop function values is less than ostd
ilen = 5; % Number of target function values saved in the inner loop
olen = 5; % Number of target function values saved in the outer loop

% Main program
m = length(Coord); % Number of cities m
fare = distance(Coord); % Path cost fare
path = 1:m; % Initial path
pathfar = pathfare(fare, path); % Path cost pathfare
ores = zeros(1, olen); % Target function values saved in the outer loop
e0 = pathfar; % Initial energy value e0
t = t0; % Temperature t
for out = 1:oLk
    ires = zeros(1, ilen); % Target function values saved in the inner loop
    for in = 1:iLk
        [newpath, ~] = swap(path, 1); % Generate new state
        e1 = pathfare(fare, newpath); % Energy of the new state
        r = min(1, exp(- (e1 - e0) / t)); % Metropolis sampling stability criterion
        if rand < r
            path = newpath; % Update the best state
            e0 = e1;
        end
        ires = [ires(2:end), e0]; % Save the energy of the new state
        if std(ires, 1) < istd % Stop criterion for inner loop: variance of energy values less than istd
            break;
        end
    end
    ores = [ores(2:end), e0]; % Save the energy of the new state
    if std(ores, 1) < ostd % Stop criterion for outer loop: variance of energy values less than ostd
        break;
    end
    t = lam * t;
end
pathfar = e0;

% Output results
fprintf('Approximate optimal path:\n');
disp(path);
fprintf('Approximate optimal path cost\tpathfare=');
disp(pathfar);
myplot(path, Coord, pathfar);