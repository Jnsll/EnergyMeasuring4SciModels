% Optimize the Matlab code for energy efficiency

clc;
clear;

% Load the data file
data = load('example_2.txt');
n = size(data, 1);

% Standardize the data: make all rows have the same polarity
data = data ./ data(:, 1);

ck = data(6:n, :);
m1 = size(ck, 1);

bj = data(1:5, :);
m2 = size(bj, 1);

r = zeros(m1, 1);

for i = 1:m1
    t = bj - ck(i, :);
    jc1 = min(min(abs(t)));
    jc2 = max(max(abs(t)));
    rho = 0.5;
    ksi = (jc1 + rho * jc2) ./ (abs(t) + rho * jc2);
    rt = sum(ksi, 2) / size(ksi, 2);
    r(i) = rt;
end

% Display the result
disp(r);