% Optimized and Refactored Matlab Code for Energy Efficiency

% Load data
data = xlsread('cumcm2012B����4_ɽ����ͬ������������ʱ���������������ǿ��.xls');
data1 = data(:,3); % Total horizontal radiation intensity
data2 = data(:,4); % Horizontal scattered radiation intensity
data3 = data1 - data2; % Horizontal direct radiation intensity
hpi = 40.1 * pi / 180; % Latitude of Datong

% Parameters
n = 1:365;
beta = 38.1 * pi / 180; % Inclination angle
delta = 23.5 * sin((2 * pi * (284 + n)) / 365) * pi / 180;
omegat = zeros(1,365);
omegap = zeros(1,365);
Rb = zeros(1,365);

for i = 1:365
    omegap(i) = acos(-tan(hpi) * tan(delta(i)));
    omegat(i) = min(omegap(i), acos(-tan(hpi - beta) * tan(delta(i))));
    Rb(i) = (cos(hpi - beta) * cos(delta(i)) * sin(omegat(i)) + pi / 180 * sin(hpi - beta) * sin(delta(i))) / (cos(hpi) * cos(delta(i)) * sin(omegap(i)) + pi / 180 * omegap(i) * sin(hpi) * sin(delta(i)));
end

data4 = zeros(365,1);
for i = 1:365
    data4(24*i-23:24*i,1) = data3(24*i-23:24*i,1) .* Rb(i) + (1 + cos(beta)) * data2(24*i-23:24*i,1) / 2 + (1 - cos(beta)) * data1(24*i-23:24*i,1) / 2 * 0.25;
end

data5 = data4;
data5(data5 < 80) = 0;

% Total annual sunlight intensity per square meter of rooftop PV cells
power1 = sum(data5);

U = 33.6; I = 8.33; % B3 parameters
S = 1.482 * 0.992; % Area of B4
m = 56; % Number of PV cells
price1 = m * 12.5 * U * I; % Cost of PV cells
price2 = 45700; % Cost of inverter SN17
g1 = power1 * S * m / 1000 * 0.1598 * 0.973; % Annual economic benefit from electricity generation

% Output results
disp('Total electricity generation over 35 years')
G = g1 * 10 + g1 * 15 * 0.9 + g1 * 10 * 0.8;
disp('Economic benefits')
g = g1 * 0.5; % Annual economic benefit from electricity generation
price = price1 + price2; % Total cost

% Calculate payback period
disp('Payback period')
if price / g < 10
    nian = price / g;
elseif (price / g > 10) && (price / g < 25)
    nian = (price - g * 10) / (g * 0.9) + 10;
else
    nian = (price - g * 10 - g * 15 * 0.9) / (g * 0.8) + 25;
end
nian