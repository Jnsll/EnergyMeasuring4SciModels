% Optimized Matlab code for energy efficiency
% Refactored and optimized code for improved performance

% Load the two images
X1 = imread('girl.bmp');
X2 = imread('lenna.bmp');

% Perform image fusion using 'mean' method
FUSmean = wfusimg(X1, X2, 'db2', 5, 'mean', 'mean');

% Perform image fusion using 'max-min' method
FUSmaxmin = wfusimg(X1, X2, 'db2', 5, 'max', 'min');

% Set default figure properties for display
set(groot, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(groot, 'defaultFigureColor', [1 1 1]);

% Display the fused images
figure
subplot(121), imshow(uint8(FUSmean))
subplot(122), imshow(uint8(FUSmaxmin))