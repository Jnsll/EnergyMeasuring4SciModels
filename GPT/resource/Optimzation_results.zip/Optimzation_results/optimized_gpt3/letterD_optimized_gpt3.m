% Load data
letter_A = load('-ascii', 'letter_A');
letter_T = load('-ascii', 'letter_T');

% Get dimensions of letter_A
[N, m] = size(letter_A);

% Determine the class
class = N;

% Display sizes of letter_A and letter_T
app = letter_A;
test = letter_T;

[Napp_rows, Napp_cols] = size(app);
[Ntest_rows, Ntest_cols] = size(test);

% Display unique elements in the class-th row of letter_A and letter_T
unique_app_class = unique(app(class, :));
unique_test_class = unique(test(class, :));

% Find the maximum values in each row of letter_A and letter_T and determine the overall maximum
max_values_A = max(letter_A, [], 2);
max_values_T = max(letter_T, [], 2);
ns = max(max_values_A, max_values_T);

clear letter_A letter_T max_values_A max_values_T;

% Display relevant information
disp([N, ns(class), Napp_cols, Ntest_cols, mean(ns)]);