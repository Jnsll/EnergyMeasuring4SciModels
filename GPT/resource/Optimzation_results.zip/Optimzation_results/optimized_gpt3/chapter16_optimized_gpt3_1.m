clc;
clear;

% Load input data
load gene.mat;
data = gene;
P = data(1:40, :)';
T = data(41:60, :)';

% Normalize input data
Q = minmax(P);

% Create and train the neural network
net = newc(Q, 2, 0.1);
net = init(net);
net.trainparam.epochs = 20;
net = train(net, P);

% Validate network performance
a = sim(net, P);
ac = vec2ind(a);

% Classify prediction data
Y = sim(net, T);
yc = vec2ind(Y);