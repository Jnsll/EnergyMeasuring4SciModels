% Optimize the Matlab code for energy efficiency by reducing unnecessary operations and improving code structure.

% The main goal of this optimization is to remove redundant code, reduce memory usage, and improve overall code readability.

% Remove unnecessary comments and sections that do not contribute to the optimization process.
clc; close all; clear; matlabrc;

% Add only necessary paths to improve code loading time and reduce memory usage.
addpath ../../ins/;
addpath ../../ins-gnss/;
addpath ../../conversions/;

% Load required functions for the optimization process.
navego_print_version;

% Define conversion constants inline to avoid unnecessary memory allocation.
G = 9.80665; G2MSS = G; MSS2G = 1/G; D2R = pi/180; R2D = 180/pi; KT2MS = 0.514444; MS2KMH = 3.6;

% Load essential data for the optimization process.
load ref; load ekinox_imu; load ekinox_gnss;

% Perform necessary calculations and display relevant information.
to = ref.t(end) - ref.t(1);
fprintf('NaveGo: navigation time is %.2f minutes or %.2f seconds. \n', to/60, to);

% Check if INS/GNSS integration is required and execute the integration process accordingly.
if ~exist('INS_GNSS', 'var'), INS_GNSS = 'OFF'; end
if strcmp(INS_GNSS, 'ON')
    fprintf('NaveGo: processing INS/GNSS integration... \n');
    nav_ekinox = ins_gnss(ekinox_imu, ekinox_gnss, 'quaternion');
    save nav_ekinox.mat nav_ekinox;
else
    load nav_ekinox;
end

% Calculate the distance traveled by the vehicle using relevant data.
distance = gnss_distance(nav_ekinox.lat, nav_ekinox.lon);
fprintf('NaveGo: distance traveled by the vehicle is %.2f meters or %.2f km. \n', distance, distance/1000);

% Perform performance analysis for a specific part of the INS/GNSS dataset.
tmin_rmse = ref.t(1); tmax_rmse = ref.t(end);
idx = find(ref.t > tmin_rmse, 1, 'first');
fdx = find(ref.t < tmax_rmse, 1, 'last');
ref = structfun(@(x) x(idx:fdx), ref, 'UniformOutput', false);

% Interpolate INS/GNSS estimates and GNSS data based on the reference dataset.
[nav_i, ref_n] = navego_interpolation(nav_ekinox, ref);
[gnss_i, ref_g] = navego_interpolation(ekinox_gnss, ref);

% Print navigation RMSE and write data to a CSV file.
rmse_v = print_rmse(nav_i, gnss_i, ref_n, ref_g, 'Ekinox INS/GNSS');
csvwrite('ekinox.csv', rmse_v);

% Write navigation data to a CSV file and plot relevant information if required.
fprintf('\n'); navego_nav2csv(nav_ekinox);
if strcmp(PLOT, 'ON')
    navego_plot_main(ref, ekinox_gnss, nav_ekinox, gnss_i, nav_i, ref_g, ref_n);
end

% Perform Kalman filter performance analysis.
fprintf('\nNaveGo: Kalman filter performance analysis...\n');
kf_analysis(nav_ekinox);