% Load data
load('monks_A1.mat', '-ascii');
load('monks_T.mat', '-ascii');

% Get dimensions of the data
[N, m] = size(monks_T);

% Define the class
class = 1;

% Assign data to variables and get their sizes
app = monks_A1;
test = monks_T;
[Napp, ~] = size(app);
[Ntest, ~] = size(test);

% Find unique values in the class column of app and test
uniqueAppClass = unique(app(class,:));
uniqueTestClass = unique(test(class,:));

% Find the maximum value in each row of test
ns = max(monks_T);

% Clear unnecessary variables
clear monks_A1 monks_T;

% Display relevant information
[N, ns(class), Napp, Ntest, mean(ns)];