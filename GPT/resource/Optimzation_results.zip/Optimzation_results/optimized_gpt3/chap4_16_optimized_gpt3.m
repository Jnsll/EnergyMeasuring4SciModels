% Optimized and refactored Matlab code for energy efficiency

% Clearing workspace and closing all figures
close all;
clc;
clear;

% Reading the images
I = imread('ipexroundness_01.png');
J = imread('ipexroundness_04.png');

% Converting images to binary
I_binary = im2bw(I);
J_binary = im2bw(J);

% Performing logical operations on the binary images
intersection = I_binary & J_binary;
union = I_binary | J_binary;
complement_I = ~I_binary;
xor_operation = xor(I_binary, J_binary);

% Setting default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(0, 'defaultFigureColor', [1, 1, 1]);

% Displaying original and binary images
figure,
subplot(121);
imshow(I_binary);
axis on;
subplot(122);
imshow(J_binary);
axis on;

% Displaying logical operation results
figure,
subplot(121);
imshow(intersection);
axis on;
subplot(122);
imshow(union);
axis on;

figure,
subplot(121);
imshow(complement_I);
axis on;
subplot(122);
imshow(xor_operation);
axis on;