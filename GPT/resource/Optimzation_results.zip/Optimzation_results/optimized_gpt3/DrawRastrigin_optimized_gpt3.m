function DrawRastrigin()
x = -4: 0.05: 4;
[X, Y] = meshgrid(x, x);
z = arrayfun(@(h,l) Rastrigin([X(h, l), Y(h, l)]), 1:numel(X));
Z = reshape(z, size(X));
surf(X, Y, Z);
shading interp
end