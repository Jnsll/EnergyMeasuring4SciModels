% Optimize Matlab code for energy efficiency

% Load images
I = imread('trees.tif'); % Load image
J1 = I'; % Transpose the image

I1 = imread('lenna.bmp'); % Load image
J2 = I1'; % Transpose the image

% Set default figure properties
set(groot,'defaultFigurePosition',[100,100,1000,500]); % Set default figure position
set(groot,'defaultFigureColor',[1 1 1]); % Set default figure background color

% Display images
figure,
subplot(1,2,1), imshow(J1); % Display transposed image 1
subplot(1,2,2), imshow(J2); % Display transposed image 2