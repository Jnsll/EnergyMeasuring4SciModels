%% LVQ Neural Network for Face Recognition

% Clear environment variables
clear all
clc;

% Extracting face feature vectors
M = 10; % Number of people
N = 5;  % Number of face orientation categories
pixel_value = feature_extraction(M, N);

% Generating training and testing sets
rand_label = randperm(M*N);  
direction_label = repmat(1:N, 1, M);

% Training set
train_label = rand_label(1:30);
P_train = pixel_value(train_label,:)';
Tc_train = direction_label(train_label);
T_train = ind2vec(Tc_train);

% Testing set
test_label = rand_label(31:end);
P_test = pixel_value(test_label,:)';
Tc_test = direction_label(test_label);

% Creating LVQ network
for i = 1:5
    rate{i} = length(find(Tc_train == i)) / 30;
end
net = newlvq(minmax(P_train), 20, cell2mat(rate), 0.01, 'learnlv1');

% Setting training parameters
net.trainParam.epochs = 100;
net.trainParam.goal = 0.001;
net.trainParam.lr = 0.1;

% Training the network
net = train(net, P_train, T_train);

% Face recognition testing
T_sim = sim(net, P_test);
Tc_sim = vec2ind(T_sim);
result = [Tc_test; Tc_sim];

% Displaying results
% Training set face labels
strain_label = sort(train_label);
htrain_label = ceil(strain_label / N);
dtrain_label = strain_label - floor(strain_label / N) * N;
dtrain_label(dtrain_label == 0) = N;

disp('Training set images:');
for i = 1:30 
    str_train = [num2str(htrain_label(i)) '_' num2str(dtrain_label(i)) '  '];
    fprintf('%s', str_train)
    if mod(i, 5) == 0
        fprintf('\n');
    end
end

% Testing set face labels
stest_label = sort(test_label);
htest_label = ceil(stest_label / N);
dtest_label = stest_label - floor(stest_label / N) * N;
dtest_label(dtest_label == 0) = N;

disp('Testing set images:');
for i = 1:20 
    str_test = [num2str(htest_label(i)) '_' num2str(dtest_label(i)) '  '];
    fprintf('%s', str_test)
    if mod(i, 5) == 0
        fprintf('\n');
    end
end

% Displaying misclassified images
error = Tc_sim - Tc_test;
location = {'left' 'left front' 'front' 'right front' 'right'};
for i = 1:length(error)
    if error(i) ~= 0
        herror_label = ceil(test_label(i) / N);
        derror_label = test_label(i) - floor(test_label(i) / N) * N;
        derror_label(derror_label == 0) = N;
        standard = location{Tc_test(i)};
        identify = location{Tc_sim(i)};
        str_err = strcat(['Image ' num2str(herror_label) '_' num2str(derror_label) ' misclassified.']);
        disp([str_err '(Correct orientation: ' standard ' ; Identified orientation: ' identify ')']);
    end
end

% Displaying recognition rate
disp(['Recognition rate: ' num2str(length(find(error == 0)) / 20 * 100) '%']);