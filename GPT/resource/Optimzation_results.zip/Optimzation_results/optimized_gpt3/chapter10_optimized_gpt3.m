% Optimize the Matlab code for energy efficiency
% Refactored code:

% Load data
load class.mat
T = [class_1 class_2 class_3 class_4 class_5];

% Create network
net = newhop(T);

% Load samples for classification
load sim.mat
A = {[sim_1 sim_2 sim_3 sim_4 sim_5]};

% Network simulation
Y = sim(net, {25, 20}, {}, A);

% Display results
Y1 = Y{20}(:, 1:5);
Y2 = Y{20}(:, 6:10);
Y3 = Y{20}(:, 11:15);
Y4 = Y{20}(:, 16:20);
Y5 = Y{20}(:, 21:25);

% Plot results
result = {T; A{1}; Y{20}};
figure
for p = 1:3
    for k = 1:5 
        subplot(3, 5, (p-1)*5 + k)
        temp = result{p}(:, (k-1)*5 + 1:k*5);
        [m, n] = size(temp);
        imagesc(temp);
        colormap(gray);
        title(sprintf('class%d', k));
    end                
end

% Add noisy data and simulate
noisy = [1 -1 -1 -1 -1; -1 -1 -1 1 -1;
         -1 1 -1 -1 -1; -1 1 -1 -1 -1;
         1 -1 -1 -1 -1; -1 -1 1 -1 -1;
         -1 -1 -1 1 -1; -1 -1 -1 -1 1;
         -1 1 -1 -1 -1; -1 -1 -1 1 -1;
         -1 -1 1 -1 -1];
y = sim(net, {5, 100}, {}, {noisy});
a = y{100};