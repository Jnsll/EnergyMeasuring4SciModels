%% Clear the workspace
clc
clear

%% Genetic Algorithm Parameters
maxgen = 30;          % Number of generations
sizepop = 100;        % Population size
pcross = 0.6;         % Crossover probability
pmutation = 0.01;     % Mutation probability
lenchrom = [1 1];     % Chromosome length
bound = [-5 5; -5 5]; % Variable bounds

%% Initialize individuals
individuals = struct('fitness', zeros(1, sizepop), 'chrom', []); % Population structure
avgfitness = [];                                                  % Average fitness of the population
bestfitness = [];                                                 % Best fitness of the population
bestchrom = [];                                                   % Best chromosome
% Initialize population
for i = 1:sizepop
    individuals.chrom(i, :) = Code(lenchrom, bound); % Generate random individual
    x = individuals.chrom(i, :);
    individuals.fitness(i) = fun(x);                 % Individual fitness
end

% Find the best chromosome
[bestfitness, bestindex] = min(individuals.fitness);
bestchrom = individuals.chrom(bestindex, :); % Best chromosome
avgfitness = sum(individuals.fitness) / sizepop; % Average fitness of the chromosomes
% Record the best fitness and average fitness in each generation
trace = [];

%% Evolution starts
for i = 1:maxgen
    
    % Selection operation
    individuals = Select(individuals, sizepop);
    avgfitness = sum(individuals.fitness) / sizepop;
    % Crossover operation
    individuals.chrom = Cross(pcross, lenchrom, individuals.chrom, sizepop, bound);
    % Mutation operation
    individuals.chrom = Mutation(pmutation, lenchrom, individuals.chrom, sizepop, [i maxgen], bound);
    
    if mod(i, 10) == 0
        warning off
        individuals.chrom = nonlinear(individuals.chrom, sizepop);
    end
    
    % Calculate fitness
    for j = 1:sizepop
        x = individuals.chrom(j, :);
        individuals.fitness(j) = fun(x);
    end
    
    % Find the chromosome with the minimum and maximum fitness and their positions in the population
    [newbestfitness, newbestindex] = min(individuals.fitness);
    [worestfitness, worestindex] = max(individuals.fitness);
    % Replace the best chromosome from the previous evolution
    if bestfitness > newbestfitness
        bestfitness = newbestfitness;
        bestchrom = individuals.chrom(newbestindex, :);
    end
    individuals.chrom(worestindex, :) = bestchrom;
    individuals.fitness(worestindex) = bestfitness;
    
    avgfitness = sum(individuals.fitness) / sizepop;
    
    trace = [trace; avgfitness bestfitness]; % Record the best and average fitness in each generation
end
% Evolution ends

%% Display results
[r, c] = size(trace);
figure
plot([1:r]', trace(:, 1), 'r-', [1:r]', trace(:, 2), 'b--');
title(['Function Value Curve  ' 'Termination Generation = ' num2str(maxgen)], 'fontsize', 12);
xlabel('Generation', 'fontsize', 12);
ylabel('Function Value', 'fontsize', 12);
legend('Average Value of Each Generation', 'Best Value of Each Generation', 'fontsize', 12);
ylim([1.5 8])
disp('Function Value                   Variables');
ylim([-0.5 8])
grid on
% Display in the console
disp([bestfitness x]);