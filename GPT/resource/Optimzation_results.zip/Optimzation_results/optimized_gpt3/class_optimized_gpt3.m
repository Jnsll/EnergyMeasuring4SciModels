% Optimized and Refactored Matlab Code for Energy Efficiency

% Define the left end points
b33=[4 6	14	24	36	79	84	89	91	106	166	173	187	200	219	264	299	309	324	346	353	356];

% Load the reference image
a1=imread('000a.bmp');

% Initialize variables
b=0:208;
[m,n]=size(a1);
[H,N]=size(b);
a=zeros(m,n,N*2);

% Load images for both left and right ends
for i=1:N
    for k=1:2
        for j=1:m
            imageName = sprintf('%03da.bmp', b(i));
            if k == 2
                imageName = sprintf('%03db.bmp', b(i));
            end
            a(:,:,i+(k-1)*N) = imread(imageName);
        end
    end
end

% Calculate the white pixel count for each image
t=zeros(m,2*11*29);
for i=1:2*11*19
    for j=1:m
        t(j,i)=sum(a(j,:,i)==0);
    end
end

% Find the maximum difference between consecutive white pixel counts
dt=diff(t);
[~,ind]=max(dt);

% Find the upper limit
t=zeros(m,2*11*19);
for i=1:2*11*19
    for j=1:m
        t(j,i)=sum(a(j,:,i)==255);
    end
end

dt=diff(t);
[~,ind]=max(dt);

% Fill in the blanks
N=63;
ind=ind+1;
for i=1:2*11*19
    z=fix(ind(i)/N);
    ind(i)=ind(i)-z*N;
    for j=1:ind(i)
        t(j,i)=0;
    end
    for k=0:2
        for j=ind(i)+k*N:ind(i)+k*N+N/3
            t(j,i)=1;
        end
        for j=ind(i)+k*N+N/3:ind(i)+k*N+N
            t(j,i)=0;
        end
    end
end

% Calculate the matching degree for each row
s3=zeros(2*11*19, 2*11);
for k=1:2*11
    for i=1:2*11*19
        s3(i,k)=0;
        for j=1:180
            if b33(k)<=209 && i<=209
                if t(j,b33(k))==t(j,i) && t(j,b33(k)+209)==t(j,i+209)
                    s3(i,k)=s3(i,k)+1;
                end
            elseif b33(k)<=209 && i>209
                if t(j,b33(k))==t(j,i) && t(j,b33(k)+209)==t(j,i-209)
                    s3(i,k)=s3(i,k)+1;
                end
            elseif b33(k)>209 && i<=209
                if t(j,b33(k))==t(j,i) && t(j,b33(k)-209)==t(j,i+209)
                    s3(i,k)=s3(i,k)+1;
                end
            else
                if t(j,b33(k))==t(j,i) && t(j,b33(k)-209)==t(j,i-209)
                    s3(i,k)=s3(i,k)+1;
                end
            end
        end
    end
end

% Find the row with the maximum matching degree
[~,ind4]=max(s3');
s31=zeros(22,60);
for i=1:22
    a=sum(ind4==i);
    s31(i,1:a)=find(ind4==i);
end

s32 = zeros(22,60);
for i=1:22
    for j=1:60
        if s31(i,j)~=0
            s32(i,j)=s3(s31(i,j),i);
        end
    end
end

[r32,~]=sort(s32');
[r3,~]=sort(s3);