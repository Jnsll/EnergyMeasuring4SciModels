%% Clearing environment variables
warning off             % Turn off warnings
close all               % Close all figure windows
clear                   % Clear variables
clc                     % Clear command window

%% Importing data
res = xlsread('���ݼ�.xlsx');

%% Splitting into training and testing sets
temp = randperm(103);

P_train = res(temp(1: 80), 1: 7)';
T_train = res(temp(1: 80), 8)';
M = size(P_train, 2);

P_test = res(temp(81: end), 1: 7)';
T_test = res(temp(81: end), 8)';
N = size(P_test, 2);

%% Normalizing data
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%% Transposing for model compatibility
p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';

%% Training the model
trees = 100;                                      % Number of decision trees
leaf  = 5;                                        % Minimum number of leaves
OOBPrediction = 'on';                             % Enable error plot
OOBPredictorImportance = 'on';                    % Calculate feature importance
Method = 'regression';                            % Regression method
net = TreeBagger(trees, p_train, t_train, 'OOBPredictorImportance', OOBPredictorImportance,...
      'Method', Method, 'OOBPrediction', OOBPrediction, 'minleaf', leaf);
importance = net.OOBPermutedPredictorDeltaError;  % Importance

%% Simulation testing
t_sim1 = predict(net, p_train);
t_sim2 = predict(net, p_test );

%% Denormalizing data
T_sim1 = mapminmax('reverse', t_sim1, ps_output);
T_sim2 = mapminmax('reverse', t_sim2, ps_output);

%% Root mean square error
error1 = sqrt(sum((T_sim1' - T_train).^2) ./ M);
error2 = sqrt(sum((T_sim2' - T_test ).^2) ./ N);

%% Plotting
plotResults(T_train, T_sim1, M, error1, 'Training Set');
plotResults(T_test, T_sim2, N, error2, 'Testing Set');

%% Plotting error curve
plotErrorCurve(net, trees);

%% Plotting feature importance
plotFeatureImportance(importance);

%% Calculating metrics
calculateMetrics(T_train, T_sim1, T_test, T_sim2);

%% Scatter plots
scatterPlots(T_train, T_sim1, 'Training Set');
scatterPlots(T_test, T_sim2, 'Testing Set');

function plotResults(actual, predicted, numSamples, error, titleText)
    figure
    plot(1: numSamples, actual, 'r-*', 1: numSamples, predicted, 'b-o', 'LineWidth', 1)
    legend('Actual', 'Predicted')
    xlabel('Sample')
    ylabel('Result')
    title({[titleText ' Prediction Results Comparison']; ['RMSE=' num2str(error)]})
    xlim([1, numSamples])
    grid
end

function plotErrorCurve(net, trees)
    figure
    plot(1: trees, oobError(net), 'b-', 'LineWidth', 1)
    legend('Error Curve')
    xlabel('Number of Decision Trees')
    ylabel('Error')
    xlim([1, trees])
    grid
end

function plotFeatureImportance(importance)
    figure
    bar(importance)
    legend('Importance')
    xlabel('Feature')
    ylabel('Importance')
end

function calculateMetrics(T_train, T_sim1, T_test, T_sim2)
    R1 = 1 - norm(T_train - T_sim1')^2 / norm(T_train - mean(T_train))^2;
    R2 = 1 - norm(T_test  - T_sim2')^2 / norm(T_test  - mean(T_test ))^2;

    disp(['Training set R2: ', num2str(R1)])
    disp(['Testing set R2: ', num2str(R2)])

    mae1 = sum(abs(T_sim1' - T_train)) ./ length(T_train);
    mae2 = sum(abs(T_sim2' - T_test )) ./ length(T_test);

    disp(['Training set MAE: ', num2str(mae1)])
    disp(['Testing set MAE: ', num2str(mae2)])

    mbe1 = sum(T_sim1' - T_train) ./ length(T_train);
    mbe2 = sum(T_sim2' - T_test ) ./ length(T_test);

    disp(['Training set MBE: ', num2str(mbe1)])
    disp(['Testing set MBE: ', num2str(mbe2)])
end

function scatterPlots(actual, predicted, titleText)
    sz = 25;
    c = 'b';

    figure
    scatter(actual, predicted, sz, c)
    hold on
    plot(xlim, ylim, '--k')
    xlabel([titleText ' Actual Value']);
    ylabel([titleText ' Predicted Value']);
    xlim([min(actual) max(actual)])
    ylim([min(predicted) max(predicted)])
    title([titleText ' Predicted Value vs. Actual Value'])
end