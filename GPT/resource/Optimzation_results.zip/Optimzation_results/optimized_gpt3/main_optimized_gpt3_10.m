```matlab
%% Clear the environment
clc;
clear;

%% Load obstacle data
position = load('barrier.txt');
plot([0,200],[0,200],'.');
hold on;
B = load('barrier.txt');
xlabel('km','fontsize',12);
ylabel('km','fontsize',12);
title('2D Planning Space','fontsize',12);

%% Define start and end points
S = [20,180];
T = [160,90];
plot([S(1),T(1)],[S(2),T(2)],'.');

% Label points
text(S(1)+2,S(2),'S');
text(T(1)+2,T(2),'T');

%% Draw obstacle shapes
for i = 1:4:13
    fill(position(i:i+3,1),position(i:i+3,2),[0,0,0]);
end

% Load link endpoint data
L = load('lines.txt');

%% Draw lines and midpoints
v = zeros(size(L,1),2);
for i = 1:size(L,1)
    plot([position(L(i,1),1),position(L(i,2),1)],[position(L(i,1),2),position(L(i,2),2)],'color','black','LineStyle','--');
    v(i,:) = (position(L(i,1),:)+position(L(i,2),:))/2;
    plot(v(i,1),v(i,2),'*');
    text(v(i,1)+2,v(i,2),strcat('v',num2str(i)));
end

%% Draw feasible paths
sign = load('matrix.txt');
[n,m] = size(sign);

for i = 1:n
    for j = 2:i
        if i == m
            plot([T(1),v(j-1,1)],[T(2),v(j-1,2)],'color','black','Linewidth',2,'LineStyle','-');
        else
            plot([v(i-1,1),v(j-1,1)],[v(i-1,2),v(j-1,2)],'color','black','Linewidth',2,'LineStyle','-');
        end
    end
end

path = DijkstraPlan(position,sign);
j = path(22);
plot([T(1),v(j-1,1)],[T(2),v(j-1,2)],'color','yellow','LineWidth',3,'LineStyle','-.');

i = path(22);
j = path(i);
count = 0;
while true
    plot([v(i-1,1),v(j-1,1)],[v(i-1,2),v(j-1,2)],'color','yellow','LineWidth',3,'LineStyle','-.');

    count = count + 1;
    i = j;
    j = path(i);
    if i == 1 || j == 1
        break;
    end
end

plot([S(1),v(i-1,1)],[S(2),v(i-1,2)],'color','yellow','LineWidth',3,'LineStyle','-.');

count = count + 3;
pathtemp(count) = 22;
j = 22;
for i = 2:count
    pathtemp(count-i+1) = path(j);
    j = path(j);
end

path = pathtemp;
path = [1,9,8,7,13,14,12,22];

%% Ant Colony Optimization Algorithm Parameters Initialization
pathCount = length(path) - 2;          % Number of line segments
pheCacuPara = 2;                       % Pheromone calculation parameter
pheThres = 0.8;                        % Pheromone selection threshold
pheUpPara = [0.1,0.0003];              % Pheromone update parameters
qfz = zeros(pathCount,10);             % Heuristic values

phePara = ones(pathCount,10) * pheUpPara(2);   % Pheromone
qfzPara1 = ones(10,1) * 0.5;           % Heuristic information parameter
qfzPara2 = 1.1;                        % Heuristic information parameter
m = 10;                                % Population size
NC = 500;                              % Number of iterations
pathk = zeros(pathCount,m);            % Search result record
shortestpath = zeros(1,NC);            % Evolution process record

%% Initial shortest path
dijpathlen = 0;
vv = [S; v; T];
for i = 1:pathCount-1
    dijpathlen = dijpathlen + norm(vv(path(i),:) - vv(path(i+1),:));
end
LL = dijpathlen;

%% Lines passed through
lines = B(L(path(2:end)-1,:));

%% Loop search
for num = 1:NC
    % Ant iteration for optimization
    for i = 1:pathCount
        for k = 1:m
            q = rand();
            qfz(i,:) = (qfzPara2 - abs((1:10)'/10 - qfzPara1)) / qfzPara2; % Heuristic information
            if q <= pheThres
                arg = phePara(i,:) .* (qfz(i,:).^pheCacuPara);
                j = find(arg == max(arg));
                pathk(i,k) = j(1);
            else
                arg = phePara(i,:) .* (qfz(i,:).^pheCacuPara);
                sumarg = sum(arg);
                qq = (q - pheThres) / (1 - pheThres);
                qtemp = 0;
                j = 1;
                while qtemp < qq
                    qtemp = qtemp + (phePara(i,j) * (qfz(i,j)^pheCacuPara)) / sumarg;
                    j = j + 1;
                end
                j = j - 1;
                pathk(i,k) = j(1);
            end
            % Update pheromone
            phePara(i,j) = (1 - p