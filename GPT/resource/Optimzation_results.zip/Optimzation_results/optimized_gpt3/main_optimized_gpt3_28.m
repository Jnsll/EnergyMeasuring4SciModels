%% Clear environment variables
warning off             % Disable warnings
close all               % Close all figure windows
clear                   % Clear variables
clc                     % Clear command window

%% Import data
res = xlsread('���ݼ�.xlsx');

%% Split into training and testing sets
temp = randperm(103);

P_train = res(temp(1:80), 1:7)';
T_train = res(temp(1:80), 8)';
M = size(P_train, 2);

P_test = res(temp(81:end), 1:7)';
T_test = res(temp(81:end), 8)';
N = size(P_test, 2);

%% Data normalization
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%% Create model
num_hiddens = 50;        % Number of hidden layer nodes
activate_model = 'sig';  % Activation function
[IW, B, LW, TF, TYPE] = elmtrain(p_train, t_train, num_hiddens, activate_model, 0);

%% Simulation testing
t_sim1 = elmpredict(p_train, IW, B, LW, TF, TYPE);
t_sim2 = elmpredict(p_test, IW, B, LW, TF, TYPE);

%% Data reverse normalization
T_sim1 = mapminmax('reverse', t_sim1, ps_output);
T_sim2 = mapminmax('reverse', t_sim2, ps_output);

%% Root mean square error
error1 = sqrt(sum((T_sim1 - T_train).^2) / M);
error2 = sqrt(sum((T_sim2 - T_test).^2) / N);

%% Plotting
plotResults(T_train, T_sim1, M, error1, 'ѵ����Ԥ�����Ա�');
plotResults(T_test, T_sim2, N, error2, '���Լ�Ԥ�����Ա�');

%% Calculate performance metrics
calculateMetrics(T_train, T_sim1, 'ѵ����');
calculateMetrics(T_test, T_sim2, '���Լ�');

%% Scatter plots
scatterPlot(T_train, T_sim1, 'ѵ����');
scatterPlot(T_test, T_sim2, '���Լ�');

function plotResults(actual, predicted, dataSize, error, titleText)
    figure
    plot(1:dataSize, actual, 'r-*', 1:dataSize, predicted, 'b-o', 'LineWidth', 1)
    legend('��ʵֵ', 'Ԥ��ֵ')
    xlabel('Ԥ������')
    ylabel('Ԥ����')
    title({titleText; ['RMSE=' num2str(error)]})
    xlim([1, dataSize])
    grid
end

function calculateMetrics(actual, predicted, datasetType)
    R = 1 - norm(actual - predicted)^2 / norm(actual - mean(actual))^2;
    mae = sum(abs(predicted - actual)) / length(actual);
    mbe = sum(predicted - actual) / length(actual);

    disp([datasetType '���ݵ�R2Ϊ��', num2str(R)])
    disp([datasetType '���ݵ�MAEΪ��', num2str(mae)])
    disp([datasetType '���ݵ�MBEΪ��', num2str(mbe)])
end

function scatterPlot(actual, predicted, plotTitle)
    sz = 25;
    c = 'b';

    figure
    scatter(actual, predicted, sz, c)
    hold on
    plot(xlim, ylim, '--k')
    xlabel([plotTitle '��ʵֵ']);
    ylabel([plotTitle 'Ԥ��ֵ']);
    xlim([min(actual) max(actual)])
    ylim([min(predicted) max(predicted)])
    title([plotTitle 'Ԥ��ֵ vs. ' plotTitle '��ʵֵ'])
end