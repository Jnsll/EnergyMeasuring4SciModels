% Load data files only once
cd('./');
clear;
load('2400m����������.mat');

% Refactored code to optimize energy efficiency
function plot_and_save(data, score, filename_prefix)
    % Plot and save data analysis
    figure;
    cla;
    surface(data,'EdgeColor','none');
    colorbar;
    saveas(gcf, [filename_prefix, '����.png']);

    % Plot and save score evaluation
    cla;
    surf(score,'EdgeColor','none');
    colorbar;
    saveas(gcf, [filename_prefix, '����.png']);
end

% Optimize code by calling the refactored function
plot_and_save(data4, score, '2400m��');

clear;
load('100m����������.mat');

% Optimize code by calling the refactored function
plot_and_save(data4, score, '100m��');

clear;
calc_proc2;
saveas(gcf,'��һ�׶ν���y-x�켣.png');

cla;
hold on;
plot(history(:,1), history(:,3), 'b', 'LineWidth',2);
plot(history(:,1), history(:,4), 'red', 'LineWidth',2);
legend ('\fontsize {17}Vx', '\fontsize {17}Vy');
xlabel 't/s';
ylabel 'V/(m/s)';
saveas(gcf,'��һ�׶ν���Vx��Vy-t�켣.png');

cla;
hold on;
plot(history(:,1), history(:,5), 'black', 'LineWidth',2);
axis([0, 450, 0, 0.45]);
xlabel 't/s';
ylabel '��/rad';
saveas(gcf,'��һ�׶ν���sita-t�켣.png');

clear;
calc_proc;
saveas(gcf,'����һ����y-x�켣.png');

cla;
hold on;
plot(history(:,1), history(:,3), 'b', 'LineWidth',2);
plot(history(:,1), history(:,4), 'red', 'LineWidth',2);
legend ('\fontsize {17}Vx', '\fontsize {17}Vy');
xlabel 't/s';
ylabel 'V/(m/s)';
saveas(gcf,'����һ����Vx��Vy-t�켣.png');

cla;
hold on;
plot(history(:,1), history(:,5), 'black', 'LineWidth',2);
axis([0, 450, 0, 0.8]);
xlabel 't/s';
ylabel '��/rad';
saveas(gcf,'����һ����sita-t�켣.png');

% Optimize energy efficiency for miscellaneous calculations
clear;
load('2400m����������.mat');

% Refactored code for energy optimization
function plot_gray_distribution(A, data, data4)
    plotdata = [];
    for i = 1:1:255
        plotdata = [plotdata; i, sum(sum(A == i))];
    end

    max_values = zeros(1, 4);
    for i = 1:1:460
        for j = 1:1:460
            idx = data4(i,j) + 1;
            if(data(i,j) > max_values(idx))
                max_values(idx) = data(i,j);
            end
        end
    end

    hold on
    plot(plotdata(:,1), plotdata(:,2), 'black', 'LineWidth',1.5);
    for idx = 1:4
        plot([max_values(idx)+0.5 max_values(idx)+0.5], [0, 3.5e5], 'red', 'LineWidth',2,'linestyle',':');
    end
    axis([0 255 0 400000])
    saveas(gcf,'�ҽ׷ֲ�.png');
end

plot_gray_distribution(A, data, data4);