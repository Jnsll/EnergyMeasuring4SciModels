% Optimized Matlab code for energy efficiency

% Generate projection data for head model
proj1 = 90; N1 = 128; % Input projection data size
degree1 = projdata(proj1, N1); % Call function projdata to generate projection data for head model

proj2 = 180; N2 = 256; % Input projection data size
degree2 = projdata(proj2, N2); % Call function projdata to generate projection data for head model

% Set default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1200, 450]); % Modify default figure position settings
set(0, 'defaultFigureColor', [1, 1, 1]); % Modify default figure background color settings

% Display head models
figure
subplot(121)
pcolor(degree1) % Display 180*128 head model
subplot(122)
pcolor(degree2) % Display 180*256 head model