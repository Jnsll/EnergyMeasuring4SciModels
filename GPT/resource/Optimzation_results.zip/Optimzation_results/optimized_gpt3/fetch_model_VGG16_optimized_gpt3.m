% Optimized and refactored code for energy efficiency

% Store the current directory
cur_dir = pwd;

% Change directory to the location of the current script
cd(fileparts(mfilename('fullpath')));

try
    % Inform user about downloading model_VGG16
    fprintf('Downloading model_VGG16...\n');
    
    % Download the model_VGG16.zip file from the specified URL
    websave('model_VGG16.zip', 'https://onedrive.live.com/download?resid=36FEC490FBC32F1A!114&authkey=!AE8uV9B07dREbhM&ithint=file%2czip');
    
    % Inform user about unzipping the downloaded file
    fprintf('Unzipping...\n');
    
    % Unzip the downloaded model_VGG16.zip file to the parent directory
    unzip('model_VGG16.zip', '..');
    
    % Inform user about completion
    fprintf('Download and Unzip completed.\n');
    
    % Delete the downloaded model_VGG16.zip file
    delete('model_VGG16.zip');
catch
    % Inform user about any errors during the process
    fprintf('Error occurred during downloading. Please check the links in README.md at https://github.com/ShaoqingRen/faster_rcnn\n');
end

% Change back to the original directory
cd(cur_dir);