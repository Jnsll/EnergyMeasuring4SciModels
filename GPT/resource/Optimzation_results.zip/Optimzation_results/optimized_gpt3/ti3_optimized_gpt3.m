%  Optimize the Matlab code for energy efficiency
%  Refactored code:
load('ti3data.mat')
data = data.*[360,1,360,1];
x1 = data(:,1);
x2 = data(:,2);
x3 = data(:,3);
y = data(:,4);

% x1: actual passing capacity of the accident cross-section
% x2: accident duration
% x3: upstream traffic flow on the road section

%  Observing the relationship between the queue length of vehicles on the road section and the actual passing capacity of the accident cross-section, accident duration, and upstream traffic flow

figure;
plot(x1,y,'o')
figure;
plot(x2,y,'o')
figure;
plot(x3,y,'o')

data1 = data(:,1:3);