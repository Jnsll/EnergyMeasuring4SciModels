clear; clc;

% Load data from Excel sheets
battery_info = xlsread('cumcm.xls','sheet1','B1:H24');
inverter_info = xlsread('cumcm.xls','sheet2','A1:M18');
power_generation = xlsread('cumcm.xls','sheet3','B1:H24');
arrangement_info = xlsread('cumcm.xls','sheet3','A27:D37304');

Q = [];
direction = 7; % Roof direction
area = 14; % Area of each side
indices_to_remove = [];

for i = 1:size(arrangement_info, 1)
    q = arrangement_info(i, 3) * arrangement_info(i, 4) * power_generation(arrangement_info(i, 2), direction) * inverter_info(arrangement_info(i, 1), 10) * 0.5 * 31.5 - inverter_info(arrangement_info(i, 1), 13) - arrangement_info(i, 3) * arrangement_info(i, 4) * battery_info(arrangement_info(i, 2), 6);
    q_ = q / (arrangement_info(i, 3) * arrangement_info(i, 4) * battery_info(arrangement_info(i, 2), 7));
    Q = [Q; arrangement_info(i,:), q, q_, (arrangement_info(i, 3) * arrangement_info(i, 4) * battery_info(arrangement_info(i, 2), 7))];

    if (arrangement_info(i, 3) * arrangement_info(i, 4) * battery_info(arrangement_info(i, 2), 7)) > area
        indices_to_remove = [indices_to_remove; i];
    end
end

Q(indices_to_remove, :) = [];