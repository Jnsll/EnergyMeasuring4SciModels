% Optmized and refactored Matlab code for energy efficiency
clear; % Clear workspace
close all; % Close all figures
clc; % Clear command window

% Read images
B = imread('girl2.bmp');
C = imread('boy1.bmp');

% Perform face detection
BW1 = face_detection(B);
BW2 = face_detection(C);

% Set default figure properties
set(0,'defaultFigurePosition',[100,100,1200,450]);
set(0,'defaultFigureColor',[1 1 1]);

% Display original and processed images
figure;
subplot(121); imshow(B); title('Original Image');
subplot(122); imshow(BW1); title('Face Detection Result for Image B');

figure;
subplot(121); imshow(C); title('Original Image');
subplot(122); imshow(BW2); title('Face Detection Result for Image C');