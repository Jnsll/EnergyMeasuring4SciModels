% Optmized Matlab code for energy efficiency

% Save current directory
cur_dir = pwd;

% Change directory to the location of the current script
cd(fileparts(mfilename('fullpath')));

try
    % Display message for downloading caffe_mex
    fprintf('Downloading caffe_mex...\n');
    
    % Use websave instead of urlwrite for downloading the file
    websave('caffe_mex.zip', 'https://onedrive.live.com/download?resid=F371D9563727B96F!91961&authkey=!AOkZbLTBfuMB69Y');

    % Display message for unzipping
    fprintf('Unzipping...\n');
    
    % Unzip the downloaded file to the parent directory
    unzip('caffe_mex.zip', '..');

    % Display completion message
    fprintf('Done.\n');
    
    % Delete the downloaded zip file
    delete('caffe_mex.zip');
catch
    % Display error message if download fails
    fprintf('Error in downloading, please try links in README.md https://github.com/daijifeng001/R-FCN'); 
end

% Change back to the original directory
cd(cur_dir);