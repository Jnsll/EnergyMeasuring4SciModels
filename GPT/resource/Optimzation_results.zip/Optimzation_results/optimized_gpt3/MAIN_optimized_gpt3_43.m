% Optmized and Refactored Matlab Code for Energy Efficiency
%
% This refactored code aims to optimize energy efficiency by reducing unnecessary computations and improving code readability.

clc; clear;
addpath ../../

% Define Kinematic Limits:
xLim = [0, 4]; % position
vLim = [-2, 2]; % velocity
aLim = [-4, 4]; % acceleration
jLim = 5*[-8, 8]; % jerk 

% Set Boundary Values:
xBegin = xLim(1);  % initial state
vBegin = 0;
aBegin = 0;
xFinal = xLim(2);  % final state
vFinal = 0;
aFinal = 0;

% Define User Functions:
problem.func.dynamics = @(t,x,u)( scalarChainIntegrator(x,u) );
problem.func.bndObj = @(t0,x0,tF,xF)( tF - t0 ); % minimum time
problem.func.pathObj = @(t,x,u)( 0.001*u.^2 ); % minimum jerk

% Set Problem Bounds:
problem.bounds.initialTime.low = 0;
problem.bounds.initialTime.upp = 0;
problem.bounds.finalTime.low = 0.1;
problem.bounds.finalTime.upp = 10;

problem.bounds.state.low = [xLim(1); vLim(1); aLim(1)];
problem.bounds.state.upp = [xLim(2); vLim(2); aLim(2)];
problem.bounds.initialState.low = [xBegin; vBegin; aBegin];
problem.bounds.initialState.upp = [xBegin; vBegin; aBegin];
problem.bounds.finalState.low = [xFinal; vFinal; aFinal];
problem.bounds.finalState.upp = [xFinal; vFinal; aFinal];

problem.bounds.control.low = jLim(1);
problem.bounds.control.upp = jLim(2); 

% Set Initial Guess:
problem.guess.time = [0,2];
problem.guess.state = [[xBegin; vBegin; aBegin], [xFinal; vFinal; aFinal]];
problem.guess.control = [0, 0];

% Select Solver Options:
problem.options(1).method = 'trapezoid';
problem.options(1).trapezoid.nGrid = 8;
problem.options(2).method = 'trapezoid';
problem.options(2).trapezoid.nGrid = 16;
problem.options(3).method = 'hermiteSimpson';
problem.options(3).hermiteSimpson.nSegment = 15;

% Solve the Problem:
soln = optimTraj(problem);
t = soln(end).grid.time;
q = soln(end).grid.state(1,:);
dq = soln(end).grid.state(2,:);
ddq = soln(end).grid.state(3,:);
u = soln(end).grid.control;

% Plot the Solution:
figure(1); clf;

for i = 1:4
    subplot(4,1,i)
    plot(t, soln(end).grid.state(i,:))
    ylabel(['q', 'dq', 'ddq', 'dddq'](i))
    title('Minimum-time boundary value problem');
end