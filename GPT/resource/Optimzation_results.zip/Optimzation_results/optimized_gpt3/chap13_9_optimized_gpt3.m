% Optimized Matlab code for energy efficiency
close all;                  % Close all figures, clear workspace variables, and clear all workspace variables
clear all;
clc;
X = imread('flower.tif');    % Read the image for grayscale conversion
X_gray = rgb2gray(X);        % Convert the image to grayscale

% Wavelet decomposition
[c,s] = wavedec2(X_gray, 2, 'db4');    % 2-level wavelet decomposition
siz = s(end, :);                      % Extract the size of the wavelet coefficients matrix
ca2 = appcoef2(c, s, 'db4', 2);       % Extract the approximation coefficients of level 1
chd2 = detcoef2('h', c, s, 2);        % Extract the horizontal detail coefficients of level 1
cvd2 = detcoef2('v', c, s, 2);        % Extract the vertical detail coefficients of level 1
cdd2 = detcoef2('d', c, s, 2);        % Extract the diagonal detail coefficients of level 1
a2 = upcoef2('a', ca2, 'db4', 2, siz); % Reconstruct the 2nd level wavelet coefficients
hd2 = upcoef2('h', chd2, 'db4', 2, siz); 
vd2 = upcoef2('v', cvd2, 'db4', 2, siz);
dd2 = upcoef2('d', cdd2, 'db4', 2, siz);
A1 = a2 + hd2 + vd2 + dd2;

[ca1, ch1, cv1, cd1] = dwt2(X_gray, 'db4');    % Single-level wavelet decomposition
a1 = upcoef2('a', ca1, 'db4', 1, siz);         % Reconstruct the 1st level wavelet coefficients
hd1 = upcoef2('h', cd1, 'db4', 1, siz); 
vd1 = upcoef2('v', cv1, 'db4', 1, siz);
dd1 = upcoef2('d', cd1, 'db4', 1, siz);
A0 = a1 + hd1 + vd1 + dd1;

% Modify default figure settings
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]); % Modify default figure position settings
set(0, 'defaultFigureColor', [1 1 1]);                   % Modify default figure background color settings

% Display wavelet components
figure
subplot(141); imshow(uint8(a2));
subplot(142); imshow(hd2);
subplot(143); imshow(vd2);
subplot(144); imshow(dd2);

figure
subplot(141); imshow(uint8(a1));
subplot(142); imshow(hd1);
subplot(143); imshow(vd1);
subplot(144); imshow(dd1);

% Display original image and reconstructed images
figure
subplot(131); imshow(X_gray);
subplot(132); imshow(uint8(A1));
subplot(133); imshow(uint8(A0));