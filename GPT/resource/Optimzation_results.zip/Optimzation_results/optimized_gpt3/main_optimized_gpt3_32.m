%% Clearing environment variables
warning off             % Disable warning messages
close all               % Close all open figure windows
clear                   % Clear workspace variables
clc                     % Clear command window

%% Importing data
res = xlsread('���ݼ�.xlsx');

%% Splitting data into training and testing sets
temp = randperm(357);

P_train = res(temp(1:240), 1:12)';
T_train = res(temp(1:240), 13)';
M = size(P_train, 2);

P_test = res(temp(241:end), 1:12)';
T_test = res(temp(241:end), 13)';
N = size(P_test, 2);

%% Data normalization
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);
t_train = T_train;
t_test = T_test;

%% Transposing for model compatibility
p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';

%% Setting parameters
pso_option = struct('c1', 1.5, 'c2', 1.7, 'maxgen', 100, 'sizepop', 5, 'k', 0.6, 'wV', 1, 'wP', 1, 'v', 3, ...
    'popcmax', 100, 'popcmin', 0.1, 'popgmax', 100, 'popgmin', 0.1);

%% Extracting best parameters c and g
[bestacc, bestc, bestg] = pso_svm_class(t_train, p_train, pso_option);

%% Building model
cmd = [' -c ', num2str(bestc), ' -g ', num2str(bestg)];
model = svmtrain(t_train, p_train, cmd);

%% Simulation testing
T_sim1 = svmpredict(t_train, p_train, model);
T_sim2 = svmpredict(t_test, p_test, model);

%% Data sorting
[T_train, index_1] = sort(T_train);
[T_test, index_2] = sort(T_test);

T_sim1 = T_sim1(index_1);
T_sim2 = T_sim2(index_2);

%% Performance evaluation
error1 = sum((T_sim1' == T_train)) / M * 100;
error2 = sum((T_sim2' == T_test)) / N * 100;

%% Plotting
figure
plot(1:M, T_train, 'r-*', 1:M, T_sim1, 'b-o', 'LineWidth', 1)
legend('Actual Value', 'Predicted Value')
xlabel('Predicted Sample')
ylabel('Prediction Result')
title(['Training Set Prediction Comparison'; ['Accuracy = ' num2str(error1) '%']])
grid

figure
plot(1:N, T_test, 'r-*', 1:N, T_sim2, 'b-o', 'LineWidth', 1)
legend('Actual Value', 'Predicted Value')
xlabel('Predicted Sample')
ylabel('Prediction Result')
title(['Testing Set Prediction Comparison'; ['Accuracy = ' num2str(error2) '%'])
grid

%% Confusion matrix
figure
cm = confusionchart(T_train, T_sim1);
cm.Title = 'Confusion Matrix for Train Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';

figure
cm = confusionchart(T_test, T_sim2);
cm.Title = 'Confusion Matrix for Test Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';