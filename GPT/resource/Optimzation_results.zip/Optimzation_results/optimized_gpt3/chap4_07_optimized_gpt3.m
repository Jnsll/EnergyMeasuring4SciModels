close all; % Close all figure windows, clear workspace variables, and clear all workspace variables
clear all;
clc;

RGB = imread('eight.tif'); % Read the 'eight.tif' image and assign it to RGB

% Denoise the image with M=3
M1 = 3;
[BW1, runningt1] = Denoise(RGB, M1);

% Denoise the image with M=9
M2 = 9;
[BW2, runningt2] = Denoise(RGB, M2);

% Modify default figure position settings
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]);

% Modify default figure color settings
set(0, 'defaultFigureColor', [1 1 1]);

% Display the results using subplots
subplot(121); imshow(BW1);
subplot(122); imshow(BW2);

% Display the running times for denoising with M=3 and M=9
disp('Running time for denoising with M=3:');
runningt1
disp('Running time for denoising with M=9:');
runningt2