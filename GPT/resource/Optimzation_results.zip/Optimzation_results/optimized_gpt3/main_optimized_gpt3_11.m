%% This function demonstrates a three-dimensional path planning algorithm based on ant colony optimization

%% Clear the environment
clc
clear

%% Data initialization

% Load data
load HeightData HeightData

% Grid division
LevelGrid = 10;
PortGrid = 21;

% Start and end grid points
starty = 10; starth = 4;
endy = 8; endh = 5;
m = 1;
% Algorithm parameters
PopNumber = 10;         % Population size
BestFitness = [];    % Best fitness

% Initial pheromone
pheromone = ones(21, 21, 21);

%% Initial search path
[path, pheromone] = searchpath(PopNumber, LevelGrid, PortGrid, pheromone, ...
    HeightData, starty, starth, endy, endh); 
fitness = CacuFit(path);                          % Calculate fitness
[bestfitness, bestindex] = min(fitness);           % Best fitness
bestpath = path(bestindex, :);                     % Best path
BestFitness = [BestFitness; bestfitness];          % Record fitness values
 
%% Update pheromones
rou = 0.2;
cfit = 100 / bestfitness;
for i = 2:PortGrid-1
    pheromone(i, bestpath(i*2-1), bestpath(i*2)) = ...
        (1 - rou) * pheromone(i, bestpath(i*2-1), bestpath(i*2)) + rou * cfit;
end
    
%% Find the optimal path in a loop
for kk = 1:100
     
    %% Path search
    [path, pheromone] = searchpath(PopNumber, LevelGrid, PortGrid, ...
        pheromone, HeightData, starty, starth, endy, endh); 
    
    %% Update fitness values
    fitness = CacuFit(path);                               
    [newbestfitness, newbestindex] = min(fitness);     
    if newbestfitness < bestfitness
        bestfitness = newbestfitness;
        bestpath = path(newbestindex, :);
    end 
    BestFitness = [BestFitness; bestfitness];
    
    %% Update pheromones
    cfit = 100 / bestfitness;
    for i = 2:PortGrid-1
        pheromone(i, bestpath(i*2-1), bestpath(i*2)) = (1 - rou) * ...
            pheromone(i, bestpath(i*2-1), bestpath(i*2)) + rou * cfit;
    end
 
end

%% Best path
for i = 1:21
    a(i, 1) = bestpath(i*2-1);
    a(i, 2) = bestpath(i*2);
end
figure(1)
x = 1:21;
y = 1:21;
[x1, y1] = meshgrid(x, y);
mesh(x1, y1, HeightData)
axis([1, 21, 1, 21, 0, 2000])
hold on
k = 1:21;
plot3(k(1)', a(1, 1)', a(1, 2)' * 200, '--o', 'LineWidth', 2, ...
                       'MarkerEdgeColor', 'k', ...
                       'MarkerFaceColor', 'g', ...
                       'MarkerSize', 10)
plot3(k(21)', a(21, 1)', a(21, 2)' * 200, '--o', 'LineWidth', 2, ...
                       'MarkerEdgeColor', 'k', ...
                       'MarkerFaceColor', 'g', ...
                       'MarkerSize', 10)
                   text(k(1)', a(1, 1)', a(1, 2)' * 200, 'S');
text(k(21)', a(21, 1)', a(21, 2)' * 200, 'T');
xlabel('km', 'fontsize', 12);
ylabel('km', 'fontsize', 12);
zlabel('m', 'fontsize', 12);
title('Three-Dimensional Path Planning Space', 'fontsize', 12)
set(gcf, 'Renderer', 'ZBuffer')
hold on
plot3(k', a(:, 1)', a(:, 2)' * 200, '--o')

%% Fitness change
figure(2)
plot(BestFitness)
title('Trend of Best Individual Fitness')
xlabel('Iterations')
ylabel('Fitness Value')