%% Clear environment variables
warning off             % Disable warnings
close all               % Close all figure windows
clear                   % Clear variables
clc                     % Clear command window

%% Import data
res = xlsread('���ݼ�.xlsx');

%% Split data into training and testing sets
temp = randperm(357);

P_train = res(temp(1:240), 1:12)';
T_train = res(temp(1:240), 13)';
M = size(P_train, 2);

P_test = res(temp(241:end), 1:12)';
T_test = res(temp(241:end), 13)';
N = size(P_test, 2);

%% Normalize data
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test  = mapminmax('apply', P_test, ps_input);
t_train = ind2vec(T_train);
t_test  = ind2vec(T_test);

%% Transpose data for model compatibility
p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';

%% Create model
k = 6;      % Number of principal components to retain
[Xloadings, Yloadings, Xscores, Yscores, betaPLS, PLSPctVar, MSE, stats] = plsregress(p_train, t_train, k);

%% Predict
t_sim1 = [ones(M, 1), p_train] * betaPLS;
t_sim2 = [ones(N, 1), p_test] * betaPLS;

%% Denormalize data
T_sim1 = vec2ind(t_sim1');
T_sim2 = vec2ind(t_sim2');

%% Sort data
[T_train, index_1] = sort(T_train);
[T_test, index_2] = sort(T_test);

T_sim1 = T_sim1(index_1);
T_sim2 = T_sim2(index_2);

%% Performance evaluation
error1 = sum((T_sim1 == T_train)) / M * 100;
error2 = sum((T_sim2 == T_test)) / N * 100;

%% Plotting
figure
plot(1:M, T_train, 'r-*', 1:M, T_sim1, 'b-o', 'LineWidth', 1)
legend('Actual Value', 'Predicted Value')
xlabel('Predicted Sample')
ylabel('Prediction Result')
title(['Training Set Prediction Comparison'; ['Accuracy=' num2str(error1) '%']])
grid

figure
plot(1:N, T_test, 'r-*', 1:N, T_sim2, 'b-o', 'LineWidth', 1)
legend('Actual Value', 'Predicted Value')
xlabel('Predicted Sample')
ylabel('Prediction Result')
title(['Testing Set Prediction Comparison'; ['Accuracy=' num2str(error2) '%'])
grid

%% Confusion matrix
figure
cm = confusionchart(T_train, T_sim1);
cm.Title = 'Confusion Matrix for Train Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';

figure
cm = confusionchart(T_test, T_sim2);
cm.Title = 'Confusion Matrix for Test Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';