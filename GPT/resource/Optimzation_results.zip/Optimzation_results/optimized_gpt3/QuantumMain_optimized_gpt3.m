% Energy-efficient optimized Matlab code
% Refactored code

% Parameters setting
MAXGEN = 200; % Maximum genetic generations
sizepop = 40; % Population size
lenchrom = [20 20]; % Binary length for each variable
trace = zeros(1, MAXGEN);

% Initialize the best individual
best = struct('fitness', 0, 'X', [], 'binary', [], 'chrom', []);

% Initialize population
chrom = InitPop(sizepop * 2, sum(lenchrom));

for gen = 1:MAXGEN
    % Collapse population to binary
    binary = collapse(chrom);

    % Calculate fitness and corresponding decimal values
    [fitness, X] = FitnessFunction(binary, lenchrom);

    % Update best individual
    [maxFitness, maxIndex] = max(fitness);
    if maxFitness > best.fitness
        best.fitness = maxFitness;
        best.binary = binary(maxIndex, :);
        best.chrom = chrom([2 * maxIndex - 1:2 * maxIndex], :);
        best.X = X(maxIndex, :);
    end

    trace(gen) = best.fitness;

    % Quantum gate operation
    chrom = Qgate(chrom, fitness, best, binary);
end

% Plot evolution curve
plot(1:MAXGEN, trace);
title('Evolution Process');
xlabel('Generation');
ylabel('Best Fitness per Generation');

% Display optimization results
disp(['Optimal solution X: ', num2str(best.X)]);
disp(['Maximum value Y: ', num2str(best.fitness)]);