clear

% Load the first image separately to get the dimensions
a1 = imread('000.bmp');
[m, n] = size(a1);

% Preallocate memory for the image stack
a = zeros(m, n, 11*19);

% Load images into the stack
for i = 0:11*19-1
    if i < 10
        imageName = sprintf('00%d.bmp', i);
    elseif i < 100
        imageName = sprintf('0%d.bmp', i);
    else
        imageName = sprintf('%d.bmp', i);
    end
    a(:, :, i+1) = imread(imageName);
end

d = zeros(11*19, 11*19);
e = size(d);

% Calculate differences between images
for i = 1:e(1)
    for j = 1:11*19
        if i ~= j
            s = abs(a(:, n, i) - a(:, 1, j));
            d(i, j) = d(i, j) + sum(s, 'all');
        end
    end
end

tou1 = zeros(11*19, 1);

% Check for white lines in each image
for i = 1:11*19
    s = all(a(:, :, i) == 255, 'all');
    tou1(i, 1) = tou1(i, 1) + sum(s, 'all');
end

s = tou1 < 72;
total = sum(s, 'all');
ind2 = find(s == 1);