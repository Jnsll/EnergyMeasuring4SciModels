%% Fuzzy Clustering Analysis Example
clc;
clear;

% Load data and initialize variables
load data.txt;
A = data;
[m, n] = size(A);

% Calculate mean and standard deviation
mu = mean(A);
sigma = std(A); 

% Calculate fuzzy similarity matrix
r = zeros(n);
for i = 1:n
    for j = 1:n
        r(i,j) = exp(-(mu(j)-mu(i))^2 / (sigma(i)+sigma(j))^2);   
    end
end

% Calculate the transitive closure of the fuzzy matrix
r4 = fuzzy_matrix_compound(r, 4);  

% Generate classification results
b_hat = zeros(n);
lambda = 0.998;
b_hat(r4 > lambda) = 1;          

% Save data
save data1 r A;