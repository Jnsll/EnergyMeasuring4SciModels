% Optimized and refactored Matlab code for energy efficiency

% Clearing the workspace and closing all figures
close all;
clc;
clear;

% Reading and converting images to binary
I = imread('girl.bmp');
J = imread('lenna.bmp');
I_binary = im2bw(I);
J_binary = im2bw(J);

% Performing logical operations
H = ~(I_binary | J_binary);
G = ~(I_binary & J_binary);

% Setting default figure properties
set(0, 'DefaultFigurePosition', [100, 100, 1000, 500]);
set(0, 'DefaultFigureColor', [1 1 1]);

% Displaying original and binary images
figure;
subplot(121);
imshow(I_binary);
axis on;
title('Image I Binary');

subplot(122);
imshow(J_binary);
axis on;
title('Image J Binary');

% Displaying processed images
figure;
subplot(121);
imshow(H);
axis on;
title('Logical OR Operation');

subplot(122);
imshow(G);
axis on;
title('Logical AND Operation');