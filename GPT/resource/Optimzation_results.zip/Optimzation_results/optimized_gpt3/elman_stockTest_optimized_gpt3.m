% elman_stockTest.m
%% Clean up
close all
clear, clc

%% Load data
load stock_net
load stock2
stock1 = stock2';
% load stock1

% Normalize data
mi = min(stock1);
ma = max(stock1);
testdata = stock1(141:280);
testdata = (testdata - mi) / (ma - mi);

%% Test with the last 140 periods of data
% Input
Pt = zeros(5, 135);
for i = 1:135
    Pt(:, i) = testdata(i:i+4);
end
% Test
Yt = sim(net, Pt);

% Rescale predicted data back to stock prices
YYt = Yt * (ma - mi) + mi;

% Plot real vs predicted data
figure
plot(146:280, stock1(146:280), 'r', 146:280, YYt, 'b');
legend('Real Values', 'Test Results');
title('Stock Price Prediction Test');

%% Compute Hit Rate
% count = 0;
% for i = 100:275
%     if (Store(i) - Store(i-1)) * (YYt(i) - YYt(i-1)) > 0
%         count = count + 1;
%     end
% end
% hit_rate = count / 175;
% 
% xlabel('Dates from 2008.06.16 to 2008.08.19 (about the last 180 days)');
% ylabel('Price');
% title('Simulation Data Analysis - One day prediction');
% grid on