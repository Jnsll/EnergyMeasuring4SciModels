%% Clearing environment variables
warning off             % Disable warnings
close all               % Close all figure windows
clear                   % Clear workspace variables
clc                     % Clear command window

%% Importing data
res = xlsread('���ݼ�.xlsx');

%% Splitting data into training and testing sets
temp = randperm(357);

P_train = res(temp(1:240), 1:12)';
T_train = res(temp(1:240), 13)';
M = size(P_train, 2);

P_test = res(temp(241:end), 1:12)';
T_test = res(temp(241:end), 13)';
N = size(P_test, 2);

%% Normalizing data
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);
t_train = T_train;
t_test = T_test;

%% Transposing data to fit the model
p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';

%% Training the model
trees = 50;                                       % Number of decision trees
leaf = 1;                                         % Minimum number of leaves
OOBPrediction = 'on';                             % Enable OOB prediction
OOBPredictorImportance = 'on';                    % Calculate feature importance
Method = 'classification';                        % Classification or regression
net = TreeBagger(trees, p_train, t_train, 'OOBPredictorImportance', OOBPredictorImportance, ...
      'Method', Method, 'OOBPrediction', OOBPrediction, 'minleaf', leaf);
importance = net.OOBPermutedPredictorDeltaError;  % Feature importance

%% Simulation testing
t_sim1 = predict(net, p_train);
t_sim2 = predict(net, p_test);

%% Converting formats
T_sim1 = str2double(t_sim1);
T_sim2 = str2double(t_sim2);

%% Performance evaluation
error1 = sum((T_sim1' == T_train)) / M * 100;
error2 = sum((T_sim2' == T_test)) / N * 100;

%% Plotting error curve
figure
plot(1:trees, oobError(net), 'b-', 'LineWidth', 1)
legend('Error curve')
xlabel('Number of decision trees')
ylabel('Error')
xlim([1, trees])
grid

%% Plotting feature importance
figure
bar(importance)
legend('Importance')
xlabel('Feature')
ylabel('Importance')

%% Sorting data
[T_train, index_1] = sort(T_train);
[T_test, index_2] = sort(T_test);

T_sim1 = T_sim1(index_1);
T_sim2 = T_sim2(index_2);

%% Plotting
figure
plot(1:M, T_train, 'r-*', 1:M, T_sim1, 'b-o', 'LineWidth', 1)
legend('Actual value', 'Predicted value')
xlabel('Predicted sample')
ylabel('Prediction result')
string = {'Comparison of training set predictions'; ['Accuracy=' num2str(error1) '%']};
title(string)
grid

figure
plot(1:N, T_test, 'r-*', 1:N, T_sim2, 'b-o', 'LineWidth', 1)
legend('Actual value', 'Predicted value')
xlabel('Predicted sample')
ylabel('Prediction result')
string = {'Comparison of test set predictions'; ['Accuracy=' num2str(error2) '%']};
title(string)
grid

%% Confusion matrix
figure
cm = confusionchart(T_train, T_sim1);
cm.Title = 'Confusion Matrix for Train Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';

figure
cm = confusionchart(T_test, T_sim2);
cm.Title = 'Confusion Matrix for Test Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';