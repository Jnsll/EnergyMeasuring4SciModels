% Optimize the Matlab code for energy efficiency

% Perform necessary calculations outside of loops to avoid redundant computations

% Calculate parameters outside of loops
B = 5;                  % Baseline length
theta_B = 0;            % Baseline angle
COL_min = 40;           % Left column index
COL_max = 470;          % Right column index
window_M = 2;           % Window size M
window_N = 2;           % Window size N

% Calculate R_1 for height calculation
R_1 = ones(Naz,1)*R0_RCMC(:,COL_min:COL_max);

% Preallocate arrays to store results for efficiency
PHY_s_after_avg_filtering = zeros(size(PHY_s_after_flat_earth));
PHY_s_after_median_filtering = zeros(size(PHY_s_after_flat_earth));

% Loop over rows and columns efficiently
for i = window_M+1:size(PHY_s_after_flat_earth,1)-window_M
    for j = window_N+1:size(PHY_s_after_flat_earth,2)-window_N
        % Average Filtering
        PHY_s_after_avg_filtering(i,j) = mean(mean(PHY_s_after_flat_earth(i-window_M:i+window_M,j-window_N:j+window_N)));

        % Median Filtering
        window_values = PHY_s_after_flat_earth(i-window_M:i+window_M,j-window_N:j+window_N);
        PHY_s_after_median_filtering(i,j) = median(window_values(:));
    end
end

% Calculate residue points outside of loops
[PHY_residue,residue_count] = calculata_residue(PHY_s_after_avg_filtering);

% Perform phase unwrapping based on residue count
if residue_count == 0
    PHY_after_unwrapping = Phase_unwrapping(PHY_s_after_avg_filtering);
else
    PHY_after_unwrapping = LS_unwrapping(PHY_s_after_avg_filtering);
    PHY_after_unwrapping = real(PHY_after_unwrapping);
end

% Perform calculations outside loops for efficiency
delta_r_PHY = PHY_after_unwrapping.*lamda/(4*pi);
theta_r = acos(((2*R_1+delta_r_PHY).*delta_r_PHY - B^2)./(2*B.*R_1)) - (pi/2 - theta_B);
H_area = H - R_1.*cos(theta_r);
X_area = sqrt(R_1.^2 - (H - H_area).^2);

% Display completion message
disp('All interferometric processing steps have been completed.');