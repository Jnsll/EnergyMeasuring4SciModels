%% Clear environment
clc
clear

%% Load and combine data
data1 = load('data1.mat');
data2 = load('data2.mat');
data3 = load('data3.mat');
data4 = load('data4.mat');

data = [data1.c1(1:500,:); data2.c2(1:500,:); data3.c3(1:500,:); data4.c4(1:500,:)];

% Shuffle data
rng(42); % For reproducibility
n = randperm(2000);

% Extract input and output data
input = data(:,2:25);
output1 = data(:,1);

% Convert output to 4-dimensional
output = zeros(2000, 4);
for i = 1:2000
    output(i, output1(i)) = 1;
end

% Split data into training and testing sets
input_train = input(n(1:1500),:)';
output_train = output(n(1:1500),:)';
input_test = input(n(1501:2000),:)';
output_test = output(n(1501:2000),:)';

% Normalize input data
[inputn, inputps] = mapminmax(input_train);

%% Initialize network structure
innum = 24;
midnum = 25;
outnum = 4;

% Initialize weights and biases
w1 = rand(midnum, innum);
b1 = rand(midnum, 1);
w2 = rand(midnum, outnum);
b2 = rand(outnum, 1);

w2_1 = w2;
w1_1 = w1;
b1_1 = b1;
b2_1 = b2;

% Learning rates
xite = 0.1;
alfa = 0.01;

%% Train the network
for ii = 1:10
    E(ii) = 0;
    for i = 1:1500
        % Predict network output
        x = inputn(:,i);
        I = w1 * x + b1;
        Iout = 1 ./ (1 + exp(-I));
        yn = w2' * Iout + b2;

        % Calculate error
        e = output_train(:,i) - yn;
        E(ii) = E(ii) + sum(abs(e));

        % Update weights
        dw2 = e * Iout';
        db2 = e';

        FI = Iout .* (1 - Iout);
        dw1 = FI .* x * e' * w2;
        db1 = FI .* e' * w2';

        w1 = w1 + xite * dw1';
        b1 = b1 + xite * db1';
        w2 = w2 + xite * dw2';
        b2 = b2 + xite * db2';
    end
end

%% Classify speech feature signals
inputn_test = mapminmax('apply', input_test, inputps);

for ii = 1:1
    for i = 1:500
        I = inputn_test(:,i)' * w1 + b1;
        Iout = 1 ./ (1 + exp(-I));
        fore(:,i) = w2' * Iout + b2;
    end
end

%% Result analysis
output_fore = zeros(1, 500);
for i = 1:500
    [~, output_fore(i)] = max(fore(:,i));
end

error = output_fore - output1(n(1501:2000))';

% Plot classification results
figure(1)
plot(output_fore, 'r')
hold on
plot(output1(n(1501:2000))', 'b')
legend('Predicted Class', 'Actual Class')

% Plot error
figure(2)
plot(error)
title('BP Network Classification Error', 'fontsize', 12)
xlabel('Speech Signal', 'fontsize', 12)
ylabel('Classification Error', 'fontsize', 12)

k = zeros(1, 4);
for i = 1:500
    if error(i) ~= 0
        [~, c] = max(output_test(:,i));
        k(c) = k(c) + 1;
    end
end

kk = sum(output_test);

% Accuracy
right_ratio = (kk - k) ./ kk;