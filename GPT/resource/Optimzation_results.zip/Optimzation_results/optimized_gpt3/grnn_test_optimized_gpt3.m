% optimized_grnn_test.m
% This code optimizes the given Matlab code for energy efficiency

% Clean up
close all;
clearvars;
clc;

% Training data
x = -9:8;
y = [129, -32, -118, -138, -125, -97, -55, -23, -4, 2, 1, -31, -72, -121, -142, -174, -155, -77];
P = x;
T = y;

% Design network and testing
xx = -9:0.2:8;
yy = grnn_net(P, T, xx);

% Display
figure;
plot(x, y, 'o');
hold on;
plot(xx, yy);
hold off;