disp('running TEST_Euler2RotMat.m');

% Preallocate memory for the rotation matrices
R = zeros(3,3,size(eul,1));

for i = 1:size(eul,1)
    R(:,:,i) = Euler2RotMat(eul(i,:));
end

disp('TEST_Euler2RotMat.m ran without error');