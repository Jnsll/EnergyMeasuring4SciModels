% optimized_plot_2ray_exp_model.m
clear, clf

% Constants
scale = 1e-9;          % ns
Ts = 10 * scale;       % Sampling time
t_rms = 30 * scale;    % RMS delay spread
num_ch = 10000;        % Number of channels

% 2-ray model
pow_2 = [0.5, 0.5];
delay_2 = [0, t_rms * 2] / scale;
H_2 = Ray_model(num_ch).' * sqrt(pow_2);
avg_pow_h_2 = mean(abs(H_2).^2);

% Plotting 2-ray model
subplot(211);
stem(delay_2, pow_2, 'b', 'DisplayName', 'Ideal');
hold on;
stem(delay_2, avg_pow_h_2, 'r.', 'DisplayName', 'Simulation');
xlabel('Delay [ns]');
ylabel('Channel Power [linear]');
title('Ideal PDP and simulated PDP of 2-ray model');
legend('show');
axis([0, 140, 0, 0.7]);

% Exponential model
pow_e = exp_PDP(t_rms, Ts);
delay_e = (0:length(pow_e)-1) * Ts / scale;
H_e = Ray_model(num_ch).' * sqrt(pow_e);
avg_pow_h_e = mean(abs(H_e).^2);

% Plotting exponential model
subplot(212);
stem(delay_e, pow_e, 'b', 'DisplayName', 'Ideal');
hold on;
stem(delay_e, avg_pow_h_e, 'r.', 'DisplayName', 'Simulation');
xlabel('Delay [ns]');
ylabel('Channel Power [linear]');
title('Ideal PDP and simulated PDP of exponential model');
legend('show');
axis([0, 140, 0, 0.7]);