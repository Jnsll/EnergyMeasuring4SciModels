%% After fuzzy clustering, provide the solution
load data1

% Results of fuzzy clustering analysis from fuzzy_cluster_analysis.m
ind1 = [1,5];
ind2 = [2:3,6,8:11];
ind3 = [4,7];

solution = [];
% Loop through all possible combinations of one element from each group and calculate the sum of squared errors for each combination
for i = 1:length(ind1)
    for j = 1:length(ind3)
        for k = 1:length(ind2)
            current_combination = [ind1(i), ind3(j), ind2(k)];
            error_sum = calculate_SSE(A, current_combination);
            solution = [solution; [current_combination, error_sum]];
        end
    end
end

solution
min_error_index = find(solution(:,4) == min(solution(:,4)));

final_result = solution(min_error_index,1:3)