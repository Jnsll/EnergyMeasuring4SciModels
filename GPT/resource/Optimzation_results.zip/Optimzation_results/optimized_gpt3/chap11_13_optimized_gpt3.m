% Optimized Matlab code for energy efficiency

% Read the image
I = imread('leaf1.bmp');

% Convert image to binary
c = imbinarize(I, graythresh(I));

% Set default figure properties
set(groot,'defaultFigurePosition',[100,100,1000,500]);
set(groot,'defaultFigureColor',[1 1 1]);

% Display original image
figure;
subplot(131);
imshow(I);

% Flip the binary image vertically
c = flipud(c);

% Extract edges using Canny edge detection
b = edge(c,'Canny');

% Find edge coordinates
[u,v] = find(b);

% Calculate centroid of edges
x0 = mean(v);
y0 = mean(u);

% Center the edge coordinates
xp = v - x0;
yp = u - y0;

% Convert Cartesian coordinates to polar coordinates
[cita,r] = cart2pol(xp,yp);

% Sort the polar coordinates
[~,idx] = sort(cita);
cita = cita(idx);
r = r(idx);

% Plot polar coordinates
subplot(132);
polarplot(cita,r);

% Convert polar coordinates back to Cartesian
[x,y] = pol2cart(cita,r);
x = x + x0;
y = y + y0;

% Plot Cartesian coordinates
subplot(133);
plot(x,y);