% Optimized and refactored Matlab code for energy efficiency

% Clearing workspace, closing figures, and clearing command window
clear; 
close all; 
clc;

% Reading images
B = imread('girl2.bmp'); 
C = imread('boy1.bmp');

% Refining face detection for both images
BW1 = refine_face_detection(B); 
BW2 = refine_face_detection(C);

% Modifying default figure settings
set(0,'defaultFigurePosition',[100,100,1200,450]); 
set(0,'defaultFigureColor',[1 1 1]); 

% Displaying images
figure;
subplot(121);
imshow(BW1);
title('Face Detection - Girl');
subplot(122);
imshow(BW2);
title('Face Detection - Boy');