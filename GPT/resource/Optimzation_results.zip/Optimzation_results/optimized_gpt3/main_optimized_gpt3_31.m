%% Clearing environment variables
warning off             % Disable warnings
close all               % Close all figure windows
clear                   % Clear workspace variables
clc                     % Clear command window

%% Importing data
res = xlsread('���ݼ�.xlsx');

%% Splitting data into training and testing sets
temp = randperm(103);

P_train = res(temp(1:80), 1:7)';
T_train = res(temp(1:80), 8)';
M = size(P_train, 2);

P_test = res(temp(81:end), 1:7)';
T_test = res(temp(81:end), 8)';
N = size(P_test, 2);

%% Data normalization
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%% Transposing data for model compatibility
p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';

%% Setting parameters
pso_option.c1 = 1.5;            % Local search capability parameter for PSO
pso_option.c2 = 1.7;            % Global search capability parameter for PSO
pso_option.maxgen = 100;        % Maximum evolution count set to 100
pso_option.sizepop = 10;        % Maximum population size set to 10
pso_option.k = 0.6;             % Initial value for k (belongs to [0.1,1.0]), velocity and position relationship (V = kX)
pso_option.wV = 1;              % Initial value for wV (best belongs to [0.8,1.2]), elasticity coefficient in velocity update formula
pso_option.wP = 1;              % Initial value for wP, elasticity coefficient in population update formula
pso_option.v = 5;               % Initial value for v, SVM Cross Validation parameter

pso_option.popcmax = 100;       % Maximum value for SVM parameter c change
pso_option.popcmin = 0.1;       % Minimum value for SVM parameter c change
pso_option.popgmax = 100;       % Maximum value for SVM parameter g change
pso_option.popgmin = 0.1;       % Minimum value for SVM parameter g change

%% Extracting best parameters
[bestacc, bestc, bestg] = psoSVMcgForRegress(t_train, p_train, pso_option);

%% Building the model
cmd = [' -t 2 ',' -c ',num2str(bestc),' -g ',num2str(bestg),' -s 3 -p 0.01 '];
model = svmtrain(t_train, p_train, cmd);

%% Simulating predictions
[t_sim1, error_1] = svmpredict(t_train, p_train, model);
[t_sim2, error_2] = svmpredict(t_test, p_test, model);

%% Data denormalization
T_sim1 = mapminmax('reverse', t_sim1, ps_output);
T_sim2 = mapminmax('reverse', t_sim2, ps_output);

%% Root Mean Square Error calculation
error1 = sqrt(sum((T_sim1' - T_train).^2) ./ M);
error2 = sqrt(sum((T_sim2' - T_test).^2) ./ N);

%% Plotting results
figure
plot(1:M, T_train, 'r-*', 1:M, T_sim1, 'b-o', 'LineWidth', 1)
legend('Actual Values', 'Predicted Values')
xlabel('Predicted Samples')
ylabel('Prediction Results')
title(['Training Set Prediction Comparison, RMSE=', num2str(error1)])
xlim([1, M])
grid

figure
plot(1:N, T_test, 'r-*', 1:N, T_sim2, 'b-o', 'LineWidth', 1)
legend('Actual Values', 'Predicted Values')
xlabel('Predicted Samples')
ylabel('Prediction Results')
title(['Testing Set Prediction Comparison, RMSE=', num2str(error2)])
xlim([1, N])
grid

%% Calculating performance metrics
% R2
R1 = 1 - norm(T_train - T_sim1')^2 / norm(T_train - mean(T_train))^2;
R2 = 1 - norm(T_test - T_sim2')^2 / norm(T_test - mean(T_test))^2;

disp(['R2 for training data: ', num2str(R1)])
disp(['R2 for testing data: ', num2str(R2)])

% MAE
mae1 = sum(abs(T_sim1' - T_train)) / M;
mae2 = sum(abs(T_sim2' - T_test)) / N;

disp(['MAE for training data: ', num2str(mae1)])
disp(['MAE for testing data: ', num2str(mae2)])

% MBE
mbe1 = sum(T_sim1' - T_train) / M;
mbe2 = sum(T_sim2' - T_test) / N;

disp(['MBE for training data: ', num2str(mbe1)])
disp(['MBE for testing data: ', num2str(mbe2)])

%% Scatter plots
sz = 25;
c = 'b';

figure
scatter(T_train, T_sim1, sz, c)
hold on
plot(xlim, ylim, '--k')
xlabel('Training Set Real Values');
ylabel('Training Set Predicted Values');
xlim([min(T_train) max(T_train)])
ylim([min(T_sim1) max(T_sim1)])
title('Training Set Predicted Values vs. Training Set Real Values')

figure
scatter(T_test, T_sim2, sz, c)
hold on
plot(xlim, ylim, '--k')
xlabel('Testing Set Real Values');
ylabel('Testing Set Predicted Values');
xlim([min(T_test) max(T_test)])
ylim([min(T_sim2) max(T_sim2)])
title('Testing Set Predicted Values vs. Testing Set Real Values')