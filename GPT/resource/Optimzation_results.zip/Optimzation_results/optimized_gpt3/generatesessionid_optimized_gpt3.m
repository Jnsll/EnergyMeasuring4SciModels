function id = generate_session_id()

% GENERATE_SESSION_ID
%
% This function generates a unique session ID based on username, hostname, and process ID.

if nargin ~= 0
    error('Incorrect number of input arguments');
end

id = sprintf('%s_%s_p%d', get_username(), get_hostname(), get_pid());

function username = get_username()
    [~, username] = system('whoami');
    username = strtrim(username);
end

function hostname = get_hostname()
    [~, hostname] = system('hostname');
    hostname = strtrim(hostname);
end

function pid = get_pid()
    pid = feature('getpid');
end