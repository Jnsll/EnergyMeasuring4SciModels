% Optimize Matlab code for energy efficiency

% Read the image
I = imread('flower.tif');

% Convert the image to binary using Otsu's thresholding method
BW = imbinarize(I);

% Find boundaries of objects in the binary image
[B,~] = bwboundaries(BW,'noholes');

% Display the original image and the binary image with boundaries
figure('Position',[100,100,1000,500],'Color',[1 1 1]);
subplot(1,2,1);
imshow(I);
title('Original Image');
subplot(1,2,2);
imshow(BW);
hold on

% Plot boundaries on the binary image
for k = 1:length(B)
    boundary = B{k};
    plot(boundary(:,2), boundary(:,1), 'r', 'LineWidth', 2)
end
title('Binary Image with Boundaries');
hold off