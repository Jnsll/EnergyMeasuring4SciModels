% Optimized and refactored Matlab code for energy efficiency

% Clearing workspace, closing figures, and clearing command window
clear all;
close all;
clc;

% Reading image
I = imread('girl1.bmp');

% Face detection refinement
I1 = refine_face_detection(I);

% Getting size of the refined image
[m, n] = size(I1);

% Setting parameters
theta1 = 0;     % Direction
theta2 = pi/2;
f = 0.88;       % Center frequency
sigma = 2.6;    % Variance
Sx = 5;
Sy = 5;         % Window width and length

% Generating Gabor transform window functions
Gabor1 = Gabor_hy(Sx, Sy, f, theta1, sigma);
Gabor2 = Gabor_hy(Sx, Sy, f, theta2, sigma);

% Performing convolution with Gabor filters
Regabout1 = conv2(I1, double(real(Gabor1)), 'same');
Regabout2 = conv2(I1, double(real(Gabor2)), 'same');

% Modifying default figure settings
set(0, 'defaultFigurePosition', [100, 100, 1200, 450]); % Changing default figure position
set(0, 'defaultFigureColor', [1 1 1]);                  % Changing default figure background color

% Displaying images
figure,
subplot(131), imshow(I);
subplot(132), imshow(Regabout1);
subplot(133), imshow(Regabout2);