% Parameters
global w h a W r x lamda n;
w = 2.5;
h = 70 - 3;
a = 1;
W = 80;
lamda = 5;
r = sqrt(40 * 40 + 2.5 * 2.5);

% Optimization
x = (2.5:2.5:40)';
ts0 = [pi/4, h/2];
lb = [0, 0];
ub = [pi/2, h];
options = optimoptions('fmincon', 'Display', 'off');
ts = fmincon(@objfun, ts0, [], [], [], [], lb, ub, @confun, options);

theta = ts(1);
s = ts(2);
l = w + h / sin(theta);
d = l - s;
n = 80 / 2.5 + 1;

% Boundary coordinates
xc = -40:2.5:40;
yc = sqrt(r^2 - xc.^2);
zc = zeros(1, n);

% Shaft coordinates
xg = -40:2.5:40;
yg = d * cos(theta) * ones(1, n) + w;
zg = d * sin(theta) * ones(1, n);

% Distance from boundary to shaft
dis = vecnorm([xc; yc; zc] - [xg; yg; zg]);

% Clearance between boundary and shaft
margin = l - yc - dis;

% Interpolated coordinates
k = (margin + dis) ./ dis;
xd = xc + k .* (xg - xc);
yd = yc + k .* (yg - yc);
zd = zc + k .* (zg - zc);

% Plotting
figure(1); hold on;
plot3(xc, yc, zc, '*');
plot3(xg, yg, zg, 'r');
for i = 1:n
    line([xc(i), xg(i)], [yc(i), yg(i)], [zc(i), zg(i)], 'LineWidth', 2);
    line([xd(i), xg(i)], [yd(i), yg(i)], [zd(i), zg(i)], 'LineWidth', 2);
end

figure(2); hold on;
plot3(xc, -yc, zc, '*');
plot3(xg, -yg, zg, 'r');
for i = 1:n
    line([xc(i), xg(i)], [-yc(i), -yg(i)], [zc(i), zg(i)], 'LineWidth', 1, 'Color', [.2, .2, .2]);
    line([xd(i), xg(i)], [-yd(i), -yg(i)], [zd(i), zg(i)], 'LineWidth', 1, 'Color', [.2, .2, .2]);
end

plot3(xc, yc, zc);
plot3(xc, -yc, zc);
line([xc(1), xc(1)], [yc(1), -yc(1)], [zc(1), zc(1)], 'LineWidth', 2);
line([xc(n), xc(n)], [yc(n), -yc(n)], [zc(n), zc(n)], 'LineWidth', 2);
view(3);

[X, Y, Z] = sphere(30);
X = l * X / 2;
Y = l * Y / 2;
Z = zeros(31);
surf(X, Y, Z);
colormap(spring);
alpha(.5);
shading interp;
axis equal;
axis off;