clear
clc
tic

% Parameters
pop_size = 65;
chromosome_size = 22;
clone_size = 60;
xmin = 0;
xmax = 8;
epochs = 100;
pMutate = 0.1;
cfactor = 0.3;

% Initialize population
pop = InitializeFun(pop_size, chromosome_size);

% Define fitness function
F = @(X) X + 10 * sin(X .* 5) + 9 * cos(X .* 4);

% Initialize arrays to store best and average fitness values
E_best = zeros(1, epochs);
E_ave = zeros(1, epochs);

% Main loop
for epoch = 1:epochs
    X = DecodeFun(pop, xmin, xmax);
    Fit = F(X);
    
    if epoch == 1
        figure(1);
        fplot(F, [xmin, xmax]);
        grid on;
        hold on;
        plot(X, Fit, 'k*');
        title('Initial Antibody Distribution');
        xlabel('x');
        ylabel('y');
    end
    
    if epoch <= epochs
        figure(2);
        fplot(F, [xmin, xmax], 'b');
        grid on;
        hold on;
        plot(X, Fit, 'r*');
        hold off;
        title('Final Antibody Distribution');
        xlabel('x');
        ylabel('y');
        pause(0.01);
    end
    
    % Clone and hypermutate
    [Clone, AAS] = ReproduceFun(clone_size, cfactor, pop_size, Fit, pop, []);
    Clone = Hypermutation(Clone, chromosome_size, pMutate);
    
    % Select top clones
    [~, Affinity] = sort(Fit, 'descend');
    pop(Affinity(1:clone_size), :) = Clone;
    
    % Update best and average fitness values
    E_best(epoch) = max(Fit);
    E_ave(epoch) = mean(Fit);
end

% Display results
[~, best_idx] = max(Fit);
fprintf('\nThe optimal point is: ');
fprintf('\nx: %2.4f, f(x): %2.4f\n', X(best_idx), Fit(best_idx));

% Plot fitness trends
figure(3)
grid on 
plot(E_best)
hold on
plot(E_ave,'r')
title('Fitness Trends')
xlabel('Iterations')
ylabel('Fitness')
hold off
grid on

toc