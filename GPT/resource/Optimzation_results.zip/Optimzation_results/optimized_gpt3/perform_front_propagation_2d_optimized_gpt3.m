function [D, S] = perform_front_propagation_2d(W, start_points, end_points, nb_iter_max, H)
    % Initialize distance and state arrays
    D = inf(size(W));
    S = ones(size(W));
    
    % Set state of start points to 0
    for i = 1:size(start_points, 2)
        S(start_points(1, i), start_points(2, i)) = 0;
        D(start_points(1, i), start_points(2, i)) = 0;
    end
    
    % Set state of end points to -1
    for i = 1:size(end_points, 2)
        S(end_points(1, i), end_points(2, i)) = -1;
    end
    
    % Perform front propagation
    for iter = 1:nb_iter_max
        % Find indices of open points
        [open_i, open_j] = find(S == 0);
        
        % Break if no open points left
        if isempty(open_i)
            break;
        end
        
        % Update distances of open points
        for k = 1:length(open_i)
            i = open_i(k);
            j = open_j(k);
            
            % Compute distances to neighbors
            neighbors = [i-1, i+1, j-1, j+1];
            for n = 1:4
                ni = neighbors(n);
                nj = neighbors(n + 1);
                
                % Check boundaries
                if ni >= 1 && ni <= size(W, 1) && nj >= 1 && nj <= size(W, 2)
                    if S(ni, nj) == 1
                        d = D(i, j) + W(ni, nj);
                        if d < D(ni, nj)
                            D(ni, nj) = d;
                            S(ni, nj) = 0;
                        end
                    end
                end
            end
            S(i, j) = -1;
        end
    end
end