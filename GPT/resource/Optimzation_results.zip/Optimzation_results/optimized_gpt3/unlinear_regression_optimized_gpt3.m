%% Nonlinear Regression Optimization
clc; 
clear;

% Define the data points
x0 = [1  8.55  470  300  10;
    2  3.79  285  80  10;
    3  4.82  470  300  120;
    4  0.02  470  300  120;
    5  2.75  470  80  10;
    6 14.39  100  190  10;
    7 2.54 100 80 65;
    8 4.35 470 190 65;
    9 13 100 300 54;
    10 8.5 100 300 120;
    11 0.05 100 80 120;
    12 11.32 285 300 10;
    13 3.13 285 190 120];

x = x0(:, 3:5);
y = x0(:, 2);

% Initial parameter estimate
beta = [0.1, 0.05, 0.02, 1, 2]';

% Perform nonlinear regression
[betahat, ~, j] = nlinfit(x, y, @func, beta);
betaci = nlparci(betahat, [], 'jacobian', j);

% Regression coefficients and confidence intervals
betaa = [betahat, betaci];

% Predicted values of y and confidence interval radius
[yhat, delta] = nlpredci(@func, x, betahat, [], 'jacobian', j);

% Plot interactive graph
nlintool(x, y, 'func', beta);