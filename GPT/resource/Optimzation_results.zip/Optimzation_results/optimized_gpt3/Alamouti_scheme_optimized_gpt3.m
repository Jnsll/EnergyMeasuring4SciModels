% Alamouti_scheme_optimized.m
clear; 
clc;

L_frame = 130; 
N_Packets = 4000; % Number of frames/packet and Number of packets 
NT = 2;
NR = 2; 
b = 2; 
SNRdBs = 0:2:20; 
sq_NT = sqrt(NT); 
sq2 = sqrt(2);

BER = zeros(1, length(SNRdBs));

for i_SNR = 1:length(SNRdBs)
    SNRdB = SNRdBs(i_SNR); 
    sigma = sqrt(0.5 / (10^(SNRdB/10)));
    
    noeb_p = zeros(1, N_Packets);
    
    for i_packet = 1:N_Packets
        msg_symbol = randi([0, 1], L_frame * b, NT);
        tx_bits = msg_symbol.';  
        
        X = zeros(NT, L_frame);
        Habs = zeros(L_frame, NT);
        
        for i = 1:NT
            [tmp1, sym_tab, P] = modulator(tx_bits(i, :), b); 
            X(i, :) = tmp1;
            
            Hr = (randn(L_frame, NT) + 1j * randn(L_frame, NT)) / sq2;
            H = reshape(Hr, L_frame, NT); 
            Habs(:, i) = sum(abs(H).^2, 2);
        end
        
        X1 = X(1, :); 
        X2 = [-conj(X(2, :)); conj(X(1, :))];
        
        R1 = sum(H .* X1, 1) / sq_NT + sigma * (randn(1, L_frame) + 1j * randn(1, L_frame));
        R2 = sum(H .* X2, 1) / sq_NT + sigma * (randn(1, L_frame) + 1j * randn(1, L_frame));
        
        Z1 = R1 .* conj(H(:, 1)) + conj(R2) .* H(:, 2);
        Z2 = R1 .* conj(H(:, 2)) - conj(R2) .* H(:, 1);
        
        for m = 1:P
            tmp = (-1 + sum(Habs, 2)) * abs(sym_tab(m))^2;
            d1 = abs(sum(Z1, 1) - sym_tab(m)).^2 + tmp;
            d2 = abs(sum(Z2, 1) - sym_tab(m)).^2 + tmp;
            
            [y1, i1] = min(d1);   
            S1d = sym_tab(i1);    
            
            [y2, i2] = min(d2);
            S2d = sym_tab(i2);    
            
            Xd = [S1d; S2d];  
            
            tmp1 = X > 0;  
            tmp2 = Xd > 0;
            noeb_p(i_packet) = sum(sum(tmp1 ~= tmp2));
        end
    end
    
    BER(i_SNR) = sum(noeb_p) / (N_Packets * L_frame * b);
end

semilogy(SNRdBs, BER);
axis([SNRdBs([1 end]) 1e-6 1e0]); 
grid on;  
xlabel('SNR[dB]'); 
ylabel('BER');