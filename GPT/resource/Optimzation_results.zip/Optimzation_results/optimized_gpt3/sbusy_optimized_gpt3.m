% Load data from Excel files
x1 = xlsread('ÿʱ��θ�վ��Ľ賵Ƶ��.xls', 'Sheet1', 'B3:BI182'); % Borrow frequency per station per time slot
x2 = xlsread('ÿʱ��θ�վ��Ļ���Ƶ��.xls', 'Sheet1', 'B3:BI182'); % Return frequency per station per time slot

% Normalize and find peak values for borrowing frequency
y1 = normalize_data(x1);
gaofeng1 = find_peak_values(y1);

% Normalize and find peak values for return frequency
y2 = normalize_data(x2);
gaofeng2 = find_peak_values(y2);

% Export peak values to Excel files
xlswrite('day_20_gaofeng_jie', gaofeng1);
xlswrite('day_20_gaofeng_huan', gaofeng2);

function normalized_data = normalize_data(data)
    % Normalize the data
    normalized_data = duiqi(data);
end

function peak_values = find_peak_values(data)
    % Find peak values
    peak_values = gaofengqi(data);
end