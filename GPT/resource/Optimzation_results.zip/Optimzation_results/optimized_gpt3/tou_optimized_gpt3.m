% Optimized Matlab code for energy efficiency

% Load the first image separately to avoid unnecessary concatenation
a1 = imread('000.bmp');
[m, n] = size(a1);

% Preallocate memory for the image stack
a = zeros(m, n, 11*19);

for i = 0:11*19-1
    if i < 10
        imageName = sprintf('00%d.bmp', i);
    elseif i < 100
        imageName = sprintf('0%d.bmp', i);
    else
        imageName = sprintf('%d.bmp', i);
    end
    a(:, :, i+1) = imread(imageName);
end

d = zeros(11*19, 11*19);
e = size(d);

% Calculate energy difference between images
for i = 1:e
    for j = 1:e
        if i ~= j
            s = abs(a(:, n, i) - a(:, 1, j));
            d(i, j) = d(i, j) + sum(s(:));
        end
    end
end

tou1 = zeros(11*19, 1);

% Calculate the number of pixels with a certain condition
for i = 1:e
    s = all(a(:, n, i) == 255 & a(:, n-1, i) == 255 & a(:, n-2, i) == 255 & ...
            a(:, n-3, i) == 255 & a(:, n-4, i) == 255 & a(:, n-5, i) == 255 & ...
            a(:, n-6, i) == 255 & a(:, n-7, i) == 255 & a(:, n-8, i) == 255 & ...
            a(:, n-9, i) == 255 & a(:, n-10, i) == 255 & a(:, n-11, i) == 255 & ...
            a(:, n-12, i) == 255);
    tou1(i, 1) = tou1(i, 1) + sum(s);
end

% Find indices where the condition is met
ind = find(tou1 == 180);
num_indices = sum(tou1 == 180);