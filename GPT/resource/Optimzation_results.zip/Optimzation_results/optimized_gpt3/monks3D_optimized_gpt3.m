% Load data
monks_A3 = load('monks_A3.ascii');
monks_T = load('monks_T.ascii');

[N, m] = size(monks_T);

class = 1;

app = monks_A3;
test = monks_T;

Napp = size(app, 2);
Ntest = size(test, 2);

unique_app = unique(app(class, :));
unique_test = unique(test(class, :));

ns = max(monks_T);
clear monks_A3 monks_T;

% Display information
disp(['Number of instances: ', num2str(N)]);
disp(['Number of attributes: ', num2str(m)]);
disp(['Class: ', num2str(class)]);
disp(['Size of app: ', num2str(size(app))]);
disp(['Size of test: ', num2str(size(test))]);
disp(['Number of instances in app: ', num2str(Napp)]);
disp(['Number of instances in test: ', num2str(Ntest)]);
disp(['Unique values in app: ', num2str(unique_app)]);
disp(['Unique values in test: ', num2str(unique_test)]);
disp(['Maximum value in test: ', num2str(ns)]);