%% Optimized Matlab code for energy efficiency in BP neural network for speech recognition

clc
clear

%% Data extraction and normalization

% Load data
load data1 c1
load data2 c2
load data3 c3
load data4 c4

% Combine data matrices
data = [c1(1:500,:); c2(1:500,:); c3(1:500,:); c4(1:500,:)];

% Randomly shuffle data
data = data(randperm(2000), :);

% Input and output data
input = data(:,2:25);
output1 = data(:,1);

% Convert output to 4-dimensional
output = zeros(2000, 4);
for i = 1:2000
    output(i, output1(i)) = 1;
end

% Split data into training and testing sets
input_train = input(1:1500, :)';
output_train = output(1:1500, :)';
input_test = input(1501:2000, :)';
output_test = output(1501:2000, :)';

% Normalize input data
[inputn, inputps] = mapminmax(input_train);

%% Network initialization
innum = 24;
midnum = 25;
outnum = 4;

% Weight initialization
w1 = rand(midnum, innum);
b1 = rand(midnum, 1);
w2 = rand(midnum, outnum);
b2 = rand(outnum, 1);

% Learning rate
xite = 0.1;
alfa = 0.01;

%% Network training
for ii = 1:10
    E = 0;
    for i = 1:1500
        % Forward pass
        x = inputn(:, i);
        I = w1 * x + b1;
        Iout = 1./(1 + exp(-I));
        yn = w2' * Iout + b2;
        
        % Error calculation
        e = output_train(:, i) - yn;
        E = E + sum(abs(e));
        
        % Weight update
        dw2 = e * Iout';
        db2 = e';
        
        FI = Iout .* (1 - Iout);
        
        dw1 = FI .* (w2 * e) * x';
        db1 = FI .* (w2 * e)';
        
        w1 = w1 + xite * dw1 + alfa * (w1_1 - w1_2);
        b1 = b1 + xite * db1 + alfa * (b1_1 - b1_2);
        w2 = w2 + xite * dw2 + alfa * (w2_1 - w2_2);
        b2 = b2 + xite * db2 + alfa * (b2_1 - b2_2);
        
        w1_2 = w1_1; w1_1 = w1;
        w2_2 = w2_1; w2_1 = w2;
        b1_2 = b1_1; b1_1 = b1;
        b2_2 = b2_1; b2_1 = b2;
    end
end

%% Speech signal classification
inputn_test = mapminmax('apply', input_test, inputps);

for ii = 1
    for i = 1:500
        I = w1 * inputn_test(:, i) + b1;
        Iout = 1./(1 + exp(-I));
        
        fore(:, i) = w2' * Iout + b2;
    end
end

%% Result analysis
output_fore = zeros(1, 500);
for i = 1:500
    [~, output_fore(i)] = max(fore(:, i));
end

error = output_fore - output1(1501:2000)';

% Plot predicted and actual speech categories
figure
plot(output_fore, 'r')
hold on
plot(output1(1501:2000)', 'b')
legend('Predicted', 'Actual')
title('Speech Signal Classification')

% Plot error
figure
plot(error)
title('BP Neural Network Classification Error')
xlabel('Speech Signal')
ylabel('Classification Error')

% Calculate accuracy
k = zeros(1, 4);
for i = 1:500
    if error(i) ~= 0
        [~, c] = max(output_test(:, i));
        k(c) = k(c) + 1;
    end
end

kk = sum(output_test);
accuracy = (kk - k) ./ kk