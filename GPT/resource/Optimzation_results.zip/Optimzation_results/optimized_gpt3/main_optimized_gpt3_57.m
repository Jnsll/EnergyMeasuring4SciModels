clear
clc

% Parameters for optimization
params = [50, 100, 500];
c1 = 1.5;
c2 = 1.5;
w = 0.5;
max_iters = 100;
swarm_size = 30;

% Optimize with different parameters
for i = 1:length(params)
    [xm{i}, fv{i}] = PSO(@fitness, params(i), c1, c2, w, max_iters, swarm_size);
end