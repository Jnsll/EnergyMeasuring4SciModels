%% Hopfield Neural Network for Associative Memory - Digit Recognition

% Clearing environment variables
clear all
clc

% Importing memory patterns
load data1.mat
T = array_one;

% Calculating weight coefficient matrix using outer product method
[m, n] = size(T);
w = zeros(m);
for i = 1:n
    w = w + T(:,i) * T(:,i)' - eye(m);
end

% Importing noisy memory patterns
noisy_array = T;
for i = 1:100
    a = rand;
    if a < 0
       noisy_array(i) = -T(i);
    end
end

% Iterative calculation
v0 = noisy_array;
v = zeros(m, n);
for k = 1:5
    for i = 1:m
        v(i, :) = sign(w(i, :) * v0);
    end
    v0 = v;
end

% Plotting
subplot(3, 1, 1)
t = imresize(T, 20);
imshow(t)
title('Standard')
subplot(3, 1, 2)
Noisy_array = imresize(noisy_array, 20);
imshow(Noisy_array)
title('Noisy')
subplot(3, 1, 3)
V = imresize(v, 20);
imshow(V)
title('Recognition')