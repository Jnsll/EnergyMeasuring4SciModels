disp('Running: TEST_plotPropLoc.m') 

% Define the tests in a more concise manner
tests = {
    % Test 1 - zero position, along z axis
    struct('d_prop', 0.1, 'location', [0 0 0]', 'ax', [0 0 1]'),

    % Test 2 - zero position, along new axis
    struct('d_prop', 0.1, 'location', [0 0 0]', 'ax', [0 1 0]'),

    % Test 3 - non-zero position, along z axis
    struct('d_prop', 0.5, 'location', [0.5 0.5 0]', 'ax', [0 0 1]'),

    % Test 4 - non-zero position, along new axis
    struct('d_prop', 0.5, 'location', [0.5 0.5 1]', 'ax', [0 1 1]')
};

% Loop through the tests and call plotPropLoc function
for i = 1:length(tests)
    test = tests{i};
    plotPropLoc(test.d_prop, test.location, test.ax);
end

disp('TEST_plotPropLoc.m ran without error');