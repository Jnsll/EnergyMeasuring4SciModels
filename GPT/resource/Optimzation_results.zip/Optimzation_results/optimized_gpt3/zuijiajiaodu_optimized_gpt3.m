clear; clc;

% Load data
fushe = xlsread('cumcm.xls', 'sheet', 'E4:K8763');
dc = xlsread('cumcm.xls', 'sheet1', 'B1:J24');

% Calculate intermediate variables
sp_zs = fushe(:, 1) - fushe(:, 2);
n_zs = fushe(:, 5) - 0.5 * fushe(:, 2);
d_zs = fushe(:, 4) - 0.5 * fushe(:, 2);
x_zs = fushe(:, 6) - 0.5 * fushe(:, 2);

% Initialize output variable
S = zeros(12, 181);

for j = 1:181
    i = 91;
    a = (i - 1) * pi / 180;
    b = (j - 91) * pi / 180;
    sa = sin(a);
    ca = cos(a);
    sb = sin(b);
    cb = cos(b);

    if sb < 0
        fushe_ry = -d_zs * sa * sb + n_zs * sa * cb + sp_zs * ca + fushe(:, 2) * (pi - a) / pi;
    else
        fushe_ry = x_zs * sa * sb + n_zs * sa * cb + sp_zs * ca + fushe(:, 2) * (pi - a) / pi;
    end

    % Calculate monthly electricity generation
    for k = 1:12
        start_idx = (k - 1) * 720 + 1;
        end_idx = k * 720;
        S(k, j) = sum(fushe_ry(start_idx:end_idx));
    end
end

x = 1:181;
plot(x, S);

% [x, y] = find(S == max(max(S)));