```matlab
% MAIN.m  --  Five Link Biped trajectory optimization --
%
% This script sets up and then solves the optimal trajectory for the five
% link biped, assuming that the walking gait is composed of single-stance
% phases of motion connected by impulsive heel-strike (no double-stance or
% flight phases).
%
% Optimize for minimum cost of transport. This code is far more complicated
% to understand than the torque-squared problem, and some aspects of the
% indexing are not as well documented. For example, to get
% torque-rate-squared regularization, the torque is actually included
% inside of the state vector. Additionally, the abs(power) cost function is
% computed using slack variables to prevent a discontinuity
% in the objective function.
%
% The equations of motion and gradients are all derived by:
%   --> Derive_Equations.m
%

%%%% NOTE %%%%
%
% This example - at least for the cost of transport optimization - should
% be considered experimental. This code does not pass strict convergence
% tests - The optimization completes successfully with loose tolerances,
% but fails to converge to a unique solution with tighter tolerances.
%
% 

clc; clear;
addpath ../../../

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                       Set up parameters and options                     %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
param = getPhysicalParameters();

param.stepLength = 0.5;
param.stepTime = 0.7;
param.stepHeight = 0.001;  %Foot must clear this height at mid-stance

param.gammaNeg = 1;   %Cost for negative work
param.gammaPos = 1;  %Cost for positive work
param.alpha = 0;   %Torque-squared smoothing parameter;
param.beta = 1e-3;   %TorqueRate-squared smoothing parameter;

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                       Set up function handles                           %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem.func.dynamics =  @(t,x,u)( dynamics(t,x,u,param) );

problem.func.pathObj = @(t,x,u)( obj_costOfTransport(x,u,param) );

problem.func.bndCst = @(t0,x0,tF,xF)( stepConstraint(x0,xF,param) );

problem.func.pathCst = @(t,x,u)( pathConstraint(x,u,param) );


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%               Set up bounds on time, state, and control                 %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
problem.bounds.initialTime.low = 0;
problem.bounds.initialTime.upp = 0;
problem.bounds.finalTime.low = param.stepTime;
problem.bounds.finalTime.upp = param.stepTime;

% State: (absolute reference frames)
%   1 = stance leg tibia angle
%   2 = stance leg femur angle
%   3 = torso angle
%   4 = swing leg femur angle
%   5 = swing leg tibia angle

qBounds = pi/2;
dqBounds = 10;
uMax = 100;  %Nm

problem.bounds.state.low = [-qBounds*ones(5,1); -dqBounds*ones(5,1); -uMax*ones(5,1)];
problem.bounds.state.upp = [qBounds*ones(5,1); dqBounds*ones(5,1); uMax*ones(5,1)];
problem.bounds.initialState.low = problem.bounds.state.low;
problem.bounds.initialState.upp = problem.bounds.state.upp;
problem.bounds.finalState.low = problem.bounds.state.low;
problem.bounds.finalState.upp = problem.bounds.state.upp;

problem.bounds.control.low = [-inf(5,1); zeros(10,1)];   % [torque rate; slack]
problem.bounds.control.upp = [inf(5,1); inf(10,1)];

% Disable the stance ankle motor:
problem.bounds.state.low(15) = 0;
problem.bounds.state.upp(15) = 0;
problem.bounds.initialState.low(15) = 0;
problem.bounds.initialState.upp(15) = 0;
problem.bounds.finalState.low(15) = 0;
problem.bounds.finalState.upp(15) = 0;

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%              Create an initial guess for the trajectory                 %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

% For now, just assume a linear trajectory between boundary values

problem.guess.time = [0, param.stepTime];

q0 = [-0.3; 0.7; 0.0; -0.5; -0.6];
qF = flip(q0);

dq0 = (qF-q0)/param.stepTime;
dqF = dq0;

u0 = zeros(5,1); uF = zeros(5,1); %Start with passive trajectory

problem.guess.state = [q0, qF; dq0, dqF; u0, uF];
problem.guess.control = zeros(5+10,2);  

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                           Options:                                      %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

method = 'trapezoid';

switch method
    case 'trapezoid'
        problem.options(1).method = 'trapezoid'; % Select the transcription method
        problem.options(1).trapezoid.n