%% Clearing environment variables
warning off             % Disable warnings
close all               % Close all figure windows
clear                   % Clear workspace variables
clc                     % Clear command window

%% Importing data (single column time series data)
result = xlsread('���ݼ�.xlsx');

%% Data analysis
num_samples = length(result);  % Number of samples
kim = 15;                      % Delay step size (using kim historical data as independent variables)
zim =  1;                      % Predicting across zim time points

%% Constructing dataset
res = zeros(num_samples - kim - zim + 1, kim + 1);
for i = 1: num_samples - kim - zim + 1
    res(i, :) = [result(i: i + kim - 1)', result(i + kim + zim)];
end

%% Splitting into training and testing sets
temp = 1:922;

P_train = res(temp(1:700), 1:15)';
T_train = res(temp(1:700), 16)';
M = size(P_train, 2);

P_test = res(temp(701:end), 1:15)';
T_test = res(temp(701:end), 16)';
N = size(P_test, 2);

%% Data normalization
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%% Transposing for model compatibility
p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';

%% Creating model
k = 12;     % Number of principal components to retain
[Xloadings, Yloadings, Xscores, Yscores, betaPLS, PLSPctVar, MSE, stats] = plsregress(p_train, t_train, k);

%% Predicting
t_sim1 = [ones(M, 1), p_train] * betaPLS;
t_sim2 = [ones(N, 1), p_test ] * betaPLS;

%% Data denormalization
T_sim1 = mapminmax('reverse', t_sim1, ps_output);
T_sim2 = mapminmax('reverse', t_sim2, ps_output);

%% Root mean square error
error1 = sqrt(sum((T_sim1 - T_train).^2) / M);
error2 = sqrt(sum((T_sim2 - T_test).^2) / N);

%% Plotting
figure
plot(1:M, T_train, 'r-', 1:M, T_sim1, 'b-', 'LineWidth', 1)
legend('True Values', 'Predicted Values')
xlabel('Predicted Samples')
ylabel('Prediction Results')
string = {'Training Set Prediction Comparison'; ['RMSE=' num2str(error1)]};
title(string)
xlim([1, M])
grid

figure
plot(1:N, T_test, 'r-', 1:N, T_sim2, 'b-', 'LineWidth', 1)
legend('True Values', 'Predicted Values')
xlabel('Predicted Samples')
ylabel('Prediction Results')
string = {'Testing Set Prediction Comparison'; ['RMSE=' num2str(error2)]};
title(string)
xlim([1, N])
grid

%% Calculating performance metrics
% R2
R1 = 1 - norm(T_train - T_sim1)^2 / norm(T_train - mean(T_train))^2;
R2 = 1 - norm(T_test - T_sim2)^2 / norm(T_test - mean(T_test))^2;

disp(['R2 for training set data: ', num2str(R1)])
disp(['R2 for testing set data: ', num2str(R2)])

% MAE
mae1 = sum(abs(T_sim1 - T_train)) / M ;
mae2 = sum(abs(T_sim2 - T_test)) / N ;

disp(['MAE for training set data: ', num2str(mae1)])
disp(['MAE for testing set data: ', num2str(mae2)])

% MBE
mbe1 = sum(T_sim1 - T_train) / M ;
mbe2 = sum(T_sim2 - T_test) / N ;

disp(['MBE for training set data: ', num2str(mbe1)])
disp(['MBE for testing set data: ', num2str(mbe2)])

%% Scatter plots
sz = 25;
c = 'b';

figure
scatter(T_train, T_sim1, sz, c)
hold on
plot(xlim, ylim, '--k')
xlabel('Training Set True Values');
ylabel('Training Set Predicted Values');
xlim([min(T_train) max(T_train)])
ylim([min(T_sim1) max(T_sim1)])
title('Training Set Predicted Values vs. Training Set True Values')

figure
scatter(T_test, T_sim2, sz, c)
hold on
plot(xlim, ylim, '--k')
xlabel('Testing Set True Values');
ylabel('Testing Set Predicted Values');
xlim([min(T_test) max(T_test)])
ylim([min(T_sim2) max(T_sim2)])
title('Testing Set Predicted Values vs. Testing Set True Values')