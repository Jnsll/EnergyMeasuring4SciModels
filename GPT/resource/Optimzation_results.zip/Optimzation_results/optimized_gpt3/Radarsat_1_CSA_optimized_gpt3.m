clear;
clc;
close all;

% Load parameters
load CD_run_params;

% Load data based on selection
if b == 1
    load data_1;
    s_echo = data_1;
    clear data_1;
elseif b == 2
    load data_2;
    s_echo = data_2;
    clear data_2;
elseif b == 3
    load data_1;
    s_echo1 = data_1;
    load data_2;
    s_echo2 = data_2;
    s_echo = [s_echo1; s_echo2];
    clear data_1 data_2 s_echo1 s_echo2;
end

% Zero-padding the original data
if b == 1 || b == 2
    data = zeros(1 * 2048, 3000);
else
    data = zeros(2 * 2048, 3000);
end
data(1:Naz, 1:Nrg) = s_echo;
s_echo = data;
clear data;
[Naz, Nrg] = size(s_echo);

% Define parameters
Kr = -Kr;
BW_range = 30.111e+06;
Vr = 7062;
Ka = 1733;
fnc = -6900;
Fa = PRF;
lamda = c / f0;
T_start = 6.5959e-03;
Nr = round(Tr * Fr);
Nrg = Nrg_cells;
if b == 1 || b == 2
    Naz = Nrg_lines_blk;
else
    Naz = Nrg_lines;
end
NFFT_r = Nrg;
NFFT_a = Naz;
R_ref = R0;
fn_ref = fnc;

% Zero-padding the original data
s_echo = padarray(s_echo, [0, 2048 - Nrg], 0, 'post');
s_echo = padarray(s_echo, [2048 - Naz, 0], 0, 'post');

% Perform imaging processes
% (remaining code for processing steps)

% Nonlinear transformation for brightness adjustment
sout = abs(s_image) / max(abs(s_image), [], 'all');
G = 20 * log10(sout + eps);
clim = [-55 0];

% Display the final image
tmp = round(2 * (R0 / D_fn_ref_Vr - R0) / c * Fr);
s_tmp(:, 1:Nrg - tmp + 1) = G(:, tmp:end);
s_tmp(:, Nrg - tmp + 2:Nrg) = G(:, 1:tmp - 1);

figure;
imagesc(((0:Nrg - 1) + first_rg_cell) / Fr * c / 2 + R0, ((0:Naz - 1) + first_rg_line) / Fa * Vr, fftshift(s_tmp, 1), clim);
axis xy;
title('RADARSAT-1 data, imaging result');
xlabel('Range (m)');
ylabel('Azimuth (m)');

if b == 3
    ss_tmp(1:Naz - 2900 + 1, :) = s_tmp(2900:Naz, :);
    ss_tmp(Naz - 2900 + 2:Naz, :) = s_tmp(1:2900 - 1, :);

    figure;
    imagesc(((0:Nrg - 1) + first_rg_cell) / Fr * c / 2 + R0, ((0:Naz - 1) + first_rg_line) / Fa * Vr, ss_tmp, clim);
    axis xy;
    title('RADARSAT-1 data, imaging result');
    xlabel('Range (m)');
    ylabel('Azimuth (m)');
end