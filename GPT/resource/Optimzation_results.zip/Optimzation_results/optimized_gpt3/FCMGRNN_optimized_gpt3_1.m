% Optimized Matlab code for energy efficiency

clear all;
clc;

% Load attack data
load netattack;
P1 = netattack;
T1 = P1(:,39)';
P1(:,39) = [];

% Data size
[R1, ~] = size(P1);
csum = 20;

% Fuzzy clustering
data = P1;
[center, U, ~] = fcm(data, 5);

% Analyze fuzzy clustering results
Confusion_Matrix_FCM = zeros(6,6);
Confusion_Matrix_FCM(1,:) = 0:5;
Confusion_Matrix_FCM(:,1) = 0:5;
for nf = 1:5
    for nc = 1:5
        Confusion_Matrix_FCM(nf+1, nc+1) = sum(a1(T1 == nf) == nc);
    end
end

% Extract network training samples
for i = 1:5
    cent{i} = P1(find(a1 == i), :);
    cent{i} = mean(cent{i});
end

% Extract samples with minimum norm for training
for n = 1:csum
    for i = 1:5
        ecent{i} = arrayfun(@(x) norm(P1(x, :) - cent{i}), 1:R1);
        [~, idx] = min(ecent{i});
        ecnt{n, i} = P1(idx, :);
        ecent{i}(idx) = [];
        tc{n, i} = i;
    end
end
P2 = cell2mat(ecnt);
T2 = cell2mat(tc);

% Iterative calculation
for nit = 1:10
    % Generalized neural network clustering
    net = newgrnn(P2', T2, 50);
    
    a2 = sim(net, P1');
    a2 = discretize(a2, [1, 1.5, 2.5, 3.5, 4.5, 5]);
    
    % Extract network training data again
    for i = 1:5
        cent{i} = P1(find(a2 == i), :);
        cent{i} = mean(cent{i});
    end
    
    % Select csum samples closest to each center
    for n = 1:csum
        for i = 1:5
            ecent{i} = arrayfun(@(x) norm(P1(x, :) - cent{i}), 1:R1);
            [~, idx] = min(ecent{i});
            ecnt{n, i} = P1(idx, :);
            ecent{i}(idx) = [];
            tc{n, i} = i;
        end
    end
    P2 = cell2mat(ecnt);
    T2 = cell2mat(tc);
    
    % Statistical analysis
    Confusion_Matrix_GRNN = zeros(6,6);
    Confusion_Matrix_GRNN(1,:) = 0:5;
    Confusion_Matrix_GRNN(:,1) = 0:5;
    for nf = 1:5
        for nc = 1:5
            Confusion_Matrix_GRNN(nf+1, nc+1) = sum(a2(T1 == nf) == nc);
        end
    end
    
    pre2 = sum(max(Confusion_Matrix_GRNN(2:6, :)))/R1 * 100;
end

% Display results
Confusion_Matrix_FCM
Confusion_Matrix_GRNN