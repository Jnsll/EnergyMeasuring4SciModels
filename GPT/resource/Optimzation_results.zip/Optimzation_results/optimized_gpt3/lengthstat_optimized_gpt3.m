function lengthstat_optimized()
[count, mat] = lengthplot(850, 1370, 1500);
total_temp = zeros(1, 850);
num_iterations = 1000;

for i = 1:num_iterations
    [~, temp] = lengthplot(850, 1370, 1500);
    total_temp = total_temp + temp;
end

mat = total_temp / num_iterations;
i = 1:850;
plot(i, mat)
end