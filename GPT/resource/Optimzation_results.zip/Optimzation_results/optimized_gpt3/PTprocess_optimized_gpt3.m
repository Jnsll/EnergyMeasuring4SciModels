%% PTprocess - script that extracts subset of total data based on highlighted epoch in main fig 

% ----------------------------------------------------------------------------------
% "THE BEER-WARE LICENSE" (Revision 42):
% <brian.white@queensu.ca> wrote this file. As long as you retain this notice you
% can do whatever you want with this stuff. If we meet some day, and you think
% this stuff is worth it, you can buy me a beer in return. -Brian White
% ----------------------------------------------------------------------------------

try
    if ~isempty(filenameA) || ~isempty(filenameB)
        
        downsampleMultiplier = 5; % 5th of the resolution for faster plotting, display only
        
        set(PTfig, 'pointer', 'watch')
        if ~isempty(filenameA)
            [epoch1_A, epoch2_A] = checkEpoch(epoch1_A, epoch2_A, tta, us2sec, PTfig, fontsz, posInfo, guiHandles, DATmainA, A_lograte, downsampleMultiplier);
        end
        
        if ~isempty(filenameB)
            [epoch1_B, epoch2_B] = checkEpoch(epoch1_B, epoch2_B, ttb, us2sec, PTfig, fontsz, posInfo, guiHandles, DATmainB, B_lograte, downsampleMultiplier);
        end
        
        set(PTfig, 'pointer', 'arrow')
    end
    
catch ME
    errmsg.PTprocess = PTerrorMessages('PTprocess', ME);
end

function [epoch1, epoch2] = checkEpoch(epoch1, epoch2, tt, us2sec, PTfig, fontsz, posInfo, guiHandles, DATmain, lograte, downsampleMultiplier)
    if isempty(epoch1) || isempty(epoch2)
        epoch1 = round(tt(1) / us2sec) + 2;
        epoch2 = round(tt(end) / us2sec) - 2;
        guiHandles.Epoch1_Input = uicontrol(PTfig, 'style', 'edit', 'string', int2str(epoch1), 'fontsize', fontsz, 'units', 'normalized', 'outerposition', posInfo.Epoch1_Input, ...
            'callback', '@textinput_call; epoch1 = str2num(guiHandles.Epoch1_Input.String); PTprocess; PTplotLogViewer;');
        guiHandles.Epoch2_Input = uicontrol(PTfig, 'style', 'edit', 'string', int2str(epoch2), 'fontsize', fontsz, 'units', 'normalized', 'outerposition', posInfo.Epoch2_Input, ...
            'callback', '@textinput_call; epoch2 = str2num(guiHandles.Epoch2_Input.String); PTprocess; PTplotLogViewer;');
    end
    
    if epoch2 > round(tt(end) / us2sec)
        epoch2 = round(tt(end) / us2sec);
        guiHandles.Epoch2_Input = uicontrol(PTfig, 'style', 'edit', 'string', int2str(epoch2), 'fontsize', fontsz, 'units', 'normalized', 'outerposition', posInfo.Epoch2_Input, ...
            'callback', '@textinput_call; epoch2 = str2num(guiHandles.Epoch2_Input.String); PTprocess; PTplotLogViewer;');
    end
    
    x = [epoch1 * us2sec, epoch2 * us2sec];
    x2 = tt > tt(find(tt > x(1), 1)) & tt < tt(find(tt > x(2), 1));
    Time = tt(x2, 1) / us2sec;
    Time = Time - Time(1);
    
    fields = fieldnames(DATmain);
    for i = 1:length(fields)
        field = fields{i};
        DATtmp.(field) = DATmain.(field)(:, x2);
    end
    
    dnsampleFactor = lograte * downsampleMultiplier;
    DATdnsmpl.t = downsample(((tt - tt(1)) / us2sec), dnsampleFactor)';
    for i = 1:length(fields)
        field = fields{i};
        DATdnsmpl.(field) = downsample(DATmain.(field)', dnsampleFactor)';
    end
    
    epoch1 = epoch1;
    epoch2 = epoch2;
end