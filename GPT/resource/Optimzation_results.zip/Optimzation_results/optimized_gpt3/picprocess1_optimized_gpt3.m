%% Load the digital elevation map of the first area
clc; clear; close all; tic;
z = imread('����3 ��2400m�������ָ߳�ͼ.tif');

%% Divide the area into 9 regions
temp = z(101:2200, 101:2200); % Convert to a 2100x2100 matrix for division
G = cell(1, 9);
for i = 1:9
    switch i
        case {1, 2, 3}
            G{i} = temp(1:700, 1 + (i - 1) * 700:i * 700);
        case {4, 5, 6}
            G{i} = temp(701:1400, 1 + (i - 4) * 700:(i - 3) * 700);
        case {7, 8, 9}
            G{i} = temp(1401:end, 1 + (i - 7) * 700:(i - 6) * 700);
    end
end

%% Calculate statistical measures for each of the 9 regions
MEAN = zeros(1, 9); % Elevation mean
JICHA = zeros(1, 9); % Elevation range
STD = zeros(1, 9); % Elevation standard deviation
XD = zeros(1, 9); % Relative elevation of the region mean to the overall mean
ZT = mean(temp(:)); % Overall mean elevation
for i = 1:9
    TEMP = double(G{i}(:));
    MEAN(i) = mean(TEMP);
    MAX = max(TEMP);
    MIN = min(TEMP);
    JICHA(i) = MAX - MIN;
    STD(i) = std(TEMP);
    XD(i) = abs(MEAN(i) - ZT) / ZT;
end
result = [MEAN; JICHA; STD; XD]; % Unnormalized results

%% Normalize STD and XD
STD2 = (STD - min(STD)) / (max(STD) - min(STD));
XD2 = (XD - min(XD)) / (max(XD) - min(XD));
RESULT = [MEAN; JICHA; STD2; XD2; STD2 + XD2]; % Normalized results

%% Plot contour maps
figure;
subplot(121);
[C, h] = contour(z);
axis([0 2300 0 2300]);
title('Contour Map at 2400m from the Moon Surface', 'FontSize', 14);
colormap(gray);

subplot(122);
contour(double(G{5}));
colormap(gray);
colorbar;
title('Contour Map of Region 5', 'FontSize', 14);

toc;