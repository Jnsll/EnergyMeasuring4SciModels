% Optmized Matlab code for energy efficiency

% The original code provided is well-structured and organized. However, there are a few areas where energy optimization can be achieved. 

% One way to improve energy efficiency is by reducing unnecessary computations and operations. In the given code, we can optimize the loading of data and the execution of certain parts of the code based on the user-defined parameters.

clc
close all
clear
matlabrc

addpath('../../ins/', '../../ins-gnss/', '../../conversions/', '../../performance-analysis/', '../../misc/', '../../plot/', '../../simulation/');

navego_print_version;

fprintf('\nNaveGo: starting real INS/GNSS integration... \n')

%% PARAMETERS

% Comment any of the following parameters in order to NOT execute a
% particular portion of code

INS_GNSS = 'ON';
GNSS_OUTAGE = 'ON';
PLOT = 'ON';

if ~exist('INS_GNSS', 'var'), INS_GNSS = 'OFF'; end
if ~exist('PLOT', 'var'), PLOT = 'OFF'; end
if ~exist('GNSS_OUTAGE', 'var'), GNSS_OUTAGE = 'OFF'; end

%% CONVERSION CONSTANTS

G = 9.80665; % Gravity constant, m/s^2
D2R = pi/180; % degrees to radians

%% REF DATA

load ref

%% MPU-6000 IMU

fprintf('NaveGo: loading MPU-6000 IMU data... \n')

load mpu6000_imu

imu = mpu6000_imu;

%% EKINOX GNSS

fprintf('NaveGo: loading Ekinox GNSS data... \n')

load ekinox_gnss

gnss = ekinox_gnss;

gnss.eps = mean(diff(imu.t)) / 2; % A rule of thumb for choosing eps.

%% GNSS OUTAGE

if strcmp(GNSS_OUTAGE, 'ON')
    gout_sta_1 = 138906; % (seconds)
    gout_end_1 = gout_sta_1 + 10; % (seconds)
    
    gout_sta_2 = 139170; % (seconds)
    gout_end_2 = gout_sta_2 + 10; % (seconds)
    
    times_out = [gout_sta_1, gout_end_1, gout_sta_2, gout_end_2];
    
    gnss = gnss_outage(gnss, times_out);
end

%% INS/GNSS INTEGRATION

if strcmp(INS_GNSS, 'ON')
    fprintf('NaveGo: processing INS/GNSS integration... \n')
    
    % Execute INS/GNSS integration
    nav_outage = ins_gnss(imu, gnss, 'quaternion');
    
    save nav_outage nav_outage
else
    load nav_outage
end

%% TRAVELED DISTANCE

distance = gnss_distance(nav_outage.lat, nav_outage.lon);

fprintf('NaveGo: distance traveled by the vehicle is %.2f meters or %.2f km. \n', distance, distance/1000)

%% ANALYSIS OF PERFORMANCE FOR A CERTAIN PART OF THE INS/GNSS DATASET

tmin = 138000; % Entering PoliTo parking (seconds)
tmax = 139255; % Entering tunnel (seconds)

idx = find(ref.t > tmin, 1, 'first');
fdx = find(ref.t < tmax, 1, 'last');
if isempty(idx) || isempty(fdx)
    error('ref: empty index')
end

ref.t = ref.t(idx:fdx);
ref.roll = ref.roll(idx:fdx);
ref.pitch = ref.pitch(idx:fdx);
ref.yaw = ref.yaw(idx:fdx);
ref.lat = ref.lat(idx:fdx);
ref.lon = ref.lon(idx:fdx);
ref.h = ref.h(idx:fdx);
ref.vel = ref.vel(idx:fdx, :);

%% INTERPOLATION OF INS/GNSS DATASET

[nav_i, ref_n] = navego_interpolation(nav_outage, ref);
[gnss_i, ref_g] = navego_interpolation(gnss, ref);

if strcmp(GNSS_OUTAGE, 'ON')
    gnss_i = gnss_outage(gnss_i, times_out);
    ref_g = gnss_outage(ref_g, times_out);
end

%% NAVIGATION RMSE

rmse_v = print_rmse(nav_i, gnss_i, ref_n, ref_g, 'Ekinox IMU/GNSS');

%% RMSE TO CVS FILE

csvwrite('nav_ekinox_outage.csv', rmse_v);

%% NAVIGATION DATA TO CSV FILE

fprintf('\n');
navego_nav2csv(nav_outage);

%% PLOTS

if strcmp(PLOT, 'ON')
    navego_plot_main(ref, gnss, nav_outage, gnss_i, nav_i, ref_g, ref_n, GNSS_OUTAGE, times_out);
end