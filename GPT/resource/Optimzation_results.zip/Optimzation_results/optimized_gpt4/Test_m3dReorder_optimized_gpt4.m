% Define the filename identifiers
Identifiers = {'AAzst1avir.N02.*.HEAD', 'AAzst1avir.N05.*.HEAD'}; % Modify here
[err, ErrMessage, List] = zglobb(Identifiers);

% Loop across all Bricks found
Nel = length(List);
Opt = struct('Verbose', 1, 'Detrend', 2, 'Dup', 'Col', 'NoCheck', 0); % Predefine options struct

for i = 1:Nel
    Input = List(i).name;
    fprintf(1, '\nNow processing: %s ...', Input);
    [~, I_Prefix, ~] = PrefixStatus(Input);
    
    % Set the new prefix
    Prefix = sprintf('%s_reord', I_Prefix); % Modify here
    
    % Set up for the function m3dReorder
    Mapfile = 'map.1D'; % Modify here
    
    % Call the m3dReorder function
    err = m3dReorder(Input, Prefix, Mapfile, Opt);
end