close all; % Close all figure windows
clear; % Clear workspace variables
clc; % Clear command window

A = imread('ipexroundness_04.png'); % Read original images
B = imread('ipexroundness_01.png');

C = immultiply(A, B); % Compute element-wise multiplication of A and B

A1 = im2double(A); % Convert A and B to double precision
B1 = im2double(B);
C1 = A1 .* B1; % Compute element-wise multiplication of A1 and B1

% Set default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(0, 'defaultFigureColor', [1, 1, 1]);

% Display original images A and B
figure;
subplot(1, 2, 1);
imshow(A);
axis on;
title('Image A');

subplot(1, 2, 2);
imshow(B);
axis on;
title('Image B');

% Display uint8 and double image data format products C and C1
figure;
subplot(1, 2, 1);
imshow(C);
axis on;
title('Product C (uint8)');

subplot(1, 2, 2);
imshow(C1);
axis on;
title('Product C1 (double)');