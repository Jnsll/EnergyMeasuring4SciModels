clc;
clear;

% Read the initial image
a1 = imread('000a.bmp');

% Define the range of images to read
b = 0:208;
[m, n] = size(a1);
N = numel(b);  % Number of images

% Preallocate the array for storing images
a = zeros(m, n, N * 2);

% Helper function to generate image names
generateImageName = @(num, suffix) strcat(sprintf('%03d', num), suffix, '.bmp');

% Read 'a' images
for i = 1:N
    imageName = generateImageName(b(i), 'a');
    a(:, :, i) = imread(imageName);
end

% Read 'b' images
for i = 1:N
    imageName = generateImageName(b(i), 'b');
    a(:, :, i + N) = imread(imageName);
end

% Initialize the result array
tou1 = zeros(11 * 19 * 2, 1);

% Vectorized comparison for energy efficiency
for i = 1:11 * 19 * 2
    s = all(a(1:49, :, i) == 255, 1);
    tou1(i) = sum(s);
end

% Find indices where the condition is met
s = tou1 == 72;
result = find(s);

% Display the result
disp('Indices:');
disp(result);