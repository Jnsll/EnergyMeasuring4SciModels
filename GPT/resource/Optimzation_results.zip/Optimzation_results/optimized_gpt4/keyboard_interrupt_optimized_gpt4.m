function interrupt = keyboard_interrupt()

interrupt = 0;

if exist('testkeypress', 'file') == 3
    if testkeypress(' ')
        interrupt = 1;
    end
elseif exist('Keytest', 'class') == 8
    if Keytest.test(' ')
        interrupt = 1;
    end
end