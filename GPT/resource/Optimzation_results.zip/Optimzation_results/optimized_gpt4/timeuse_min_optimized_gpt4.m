clc; clear;
data = xlsread('day_20.xls'); % ��һ���ǽ賵վ�ţ��ڶ����ǻ���վ�ţ����������ó�ʱ��

% Initialize min_time matrix with Inf values
num_stations = 181;
min_time = inf(num_stations);

% Populate min_time matrix with data
for i = 1:size(data, 1)
    if min_time(data(i, 1), data(i, 2)) == inf
        min_time(data(i, 1), data(i, 2)) = data(i, 3);
    end
end

% Ensure symmetry in the min_time matrix
for i = 1:num_stations
    for j = i:num_stations
        min_time(i, j) = min(min_time(i, j), min_time(j, i));
        min_time(j, i) = min(min_time(i, j), min_time(j, i));
    end
end

% Compute shortest paths using Floyd-Warshall algorithm
P = floyd(min_time);

% Write the result to an Excel file
xlswrite('day_20_P.xls', P);