% Close all figure windows, clear workspace variables, and clear command window
close all;
clear;
clc;

% Read and convert image to grayscale
X = imread('flower.tif');
X = rgb2gray(X);

% Perform 2-level wavelet decomposition
[c, s] = wavedec2(X, 2, 'db4');

% Extract wavelet coefficients from 2nd level decomposition
siz = s(end, :);
ca2 = appcoef2(c, s, 'db4', 2);
chd2 = detcoef2('h', c, s, 2);
cvd2 = detcoef2('v', c, s, 2);
cdd2 = detcoef2('d', c, s, 2);

% Reconstruct images from 2nd level coefficients
a2 = wrcoef2('a', c, s, 'db4', 2);
hd2 = wrcoef2('h', c, s, 'db4', 2);
vd2 = wrcoef2('v', c, s, 'db4', 2);
dd2 = wrcoef2('d', c, s, 'db4', 2);

% Combine reconstructed images
A1 = a2 + hd2 + vd2 + dd2;

% Perform 1-level wavelet decomposition
[ca1, ch1, cv1, cd1] = dwt2(X, 'db4');

% Reconstruct images from 1st level coefficients
a1 = wrcoef2('a', c, s, 'db4', 1);
hd1 = wrcoef2('h', c, s, 'db4', 1);
vd1 = wrcoef2('v', c, s, 'db4', 1);
dd1 = wrcoef2('d', c, s, 'db4', 1);

% Combine reconstructed images
A0 = a1 + hd1 + vd1 + dd1;

% Set default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(0, 'defaultFigureColor', [1 1 1]);

% Display the results
figure;
subplot(141); imshow(uint8(a2));
subplot(142); imshow(hd2);
subplot(143); imshow(vd2);
subplot(144); imshow(dd2);

figure;
subplot(141); imshow(uint8(a1));
subplot(142); imshow(hd1);
subplot(143); imshow(vd1);
subplot(144); imshow(dd1);

figure;
subplot(131); imshow(X);
subplot(132); imshow(uint8(A1));
subplot(133); imshow(uint8(A0));