clear
clc

% Define common parameters
fitnessFunction = @fitness;
w = 1.5; % Inertia weight
c1 = 1.5; % Cognitive parameter
c2 = 1.5; % Social parameter
vmax = 0.5; % Maximum velocity
iter = 100; % Number of iterations
dim = 30; % Dimensionality

% Particle Swarm Optimization runs with different number of particles
particles = [50, 100, 500];
results = cell(length(particles), 2);

for i = 1:length(particles)
    [results{i, 1}, results{i, 2}] = PSO(fitnessFunction, particles(i), w, c1, c2, vmax, iter, dim);
end

xm1 = results{1, 1};
fv1 = results{1, 2};
xm2 = results{2, 1};
fv2 = results{2, 2};
xm3 = results{3, 1};
fv3 = results{3, 2};