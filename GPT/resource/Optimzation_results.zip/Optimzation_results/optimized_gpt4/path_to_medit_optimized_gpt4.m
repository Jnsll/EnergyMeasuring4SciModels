function [s] = path_to_medit()
  % PATH_TO_MEDIT Return path to medit executable
  %
  % s = path_to_medit()
  %
  % Outputs:
  %   s path to medit executable
  %
  % See also: medit
  %

  if ispc
    s = 'c:/prg/lib/medit/Release/medit.exe';
  elseif isunix || ismac
    % I guess this means linux
    s = get_medit_path();
  end
end

function s = get_medit_path()
  [status, s] = system('which medit');
  s = strtrim(s);
  if status ~= 0
    guesses = { ...
      '/usr/local/bin/medit', ...
      '/opt/local/bin/medit'};
    s = find_first_path(guesses);
  end
end

function s = find_first_path(paths)
  s = '';
  for i = 1:length(paths)
    if exist(paths{i}, 'file') == 2
      s = paths{i};
      return;
    end
  end
end