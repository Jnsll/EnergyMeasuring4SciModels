function varargout = cheblogo()
%CHEBLOGO   Plot the Chebfun logo.
%   CHEBLOGO plots the Chebfun logo.
%
%   F = CHEBLOGO returns a CHEBFUN of the Chebfun logo.

% Copyright 2017 by The University of Oxford and The Chebfun Developers. 
% See http://www.chebfun.org/ for Chebfun information.

% Make a CHEBFUN of the logo:
f = chebpoly(10);
dom = [-1, .957];
f = restrict(f, dom);
x = chebfun('x', dom);

if ( nargout > 0 )
    % Export the logo:
    varargout{1} = f;
    return
end

figure
% Plot the shadow:
plot(x+.015, f-.075, 'color', .7*[1 1 1], 'LineWidth', 5);
hold on
% Plot the curve:
plot(f, 'b', 'LineWidth', 5)

% Plot the text:
t = - cos(pi*(2:8)'/10) *0.99;            % cheb extrema (tweaked)
y = 0*t; 
h = text( t, y, num2cell(transpose('chebfun')), ...
  'FontSize', 28, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle') ;

% Choose a nice font:
flist = listfonts;
preferredFonts = {'Rockwell', 'Luxi Serif', 'Times'};
fontFound = false;
for i = 1:length(preferredFonts)
    k = find(strcmp(preferredFonts{i}, flist), 1);
    if ~isempty(k)
        set(h, 'FontName', flist{k});
        fontFound = true;
        break;
    end
end

% Adjust the window size, etc.:
axis([-1.05 1 -1.8 1.8]), axis off
set(gca, 'Position', [0 0 1 1])
un = get(0, 'Units'); 
set(0, 'Units', 'centimeters')
ssize = get(0, 'ScreenSize');  
set(0, 'Units', un)
set(gcf, 'PaperType', 'A4', 'PaperUnits', 'centimeters', 'PaperPosition', [4.49 12.83 12 4])
pos = [ (ssize(3)-12)/2 (ssize(4)-4)/2 12 4];
set(gcf, 'Units', 'centimeters', 'Position', pos, 'MenuBar', 'none', ...
    'Name', 'Chebfun logo', 'NumberTitle', 'off', 'Color', 'w')

end