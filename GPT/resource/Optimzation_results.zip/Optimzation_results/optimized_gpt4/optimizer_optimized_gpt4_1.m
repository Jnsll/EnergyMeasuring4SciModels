% Johann Diep (johann.diep@esa.int) - November 2021
%
% This script must be adapted each time an optimization needs to be run.
%
% It is noted that this contains rewriting the imu_structure.m script such
% that it accepts parameter input. This functionality was removed after the
% optimal parameters were found.

clear; clc;

%% Optimization

% Pre-allocate arrays for efficiency
ErrorValue = zeros(1, 1);
ParameterValue = zeros(1, 1, 2);

% Loop through parameters
Index_p1 = 1;
for p_1 = 1
    Index_p2 = 1;
    for p_2 = 1
        try
            imu_structure(p_1, p_2);

            % Load all required data files at once to reduce I/O operations
            load('gnss_planetary.mat', 'gnss_planetary');
            load('imu_planetary.mat', 'imu_planetary');
            load('gnss_planetary_r.mat', 'gnss_planetary_r');
            load('visual_planetary.mat', 'visual_planetary');

            % Use a switch-case to handle different fusion cases
            switch FusionCase
                case 'inertial_gnss'
                    nav_e = ins_gnss(imu_planetary, gnss_planetary, 'dcm');
                case 'inertial_visual'
                    nav_e = ins_visual(imu_planetary, gnss_planetary_r, visual_planetary, 'dcm');
                case 'inertial_visual_gnss'
                    nav_e = ins_visual_gnss(imu_planetary, gnss_planetary, visual_planetary, 'dcm');
            end

            % Perform interpolation
            [nav_i, gnss_planetary_r] = navego_interpolation(nav_e, gnss_planetary_r);

            %% Optimization

            % Calculate position errors
            [RN, RE] = radius(nav_i.lat);
            LAT2M = RN + nav_i.h;
            LON2M = (RE + nav_i.h) .* cos(nav_i.lat);

            % Compute error value and store parameter values
            ErrorValue(Index_p1, Index_p2) = sqrt(rms(LAT2M .* (nav_i.lat - gnss_planetary_r.lat))^2 + rms(LON2M .* (nav_i.lon - gnss_planetary_r.lon))^2);
            ParameterValue(Index_p1, Index_p2, :) = [p_1, p_2];
        catch ME
            fprintf('An error occurred in the estimation: %s\n', ME.message);
        end
        Index_p2 = Index_p2 + 1;
    end
    Index_p1 = Index_p1 + 1;
end