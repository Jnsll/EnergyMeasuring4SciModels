function vl_setupnn()
%VL_SETUPNN Setup the MatConvNet toolbox.
%   VL_SETUPNN() function adds the MatConvNet toolbox to MATLAB path.

% Copyright (C) 2014-15 Andrea Vedaldi.
% All rights reserved.
%
% This file is part of the VLFeat library and is made available under
% the terms of the BSD license (see the COPYING file).

root = vl_rootnn();

% Use a loop to reduce repetitive code and improve maintainability
folders = {'matlab', 'matlab/mex', 'matlab/simplenn', 'matlab/xtest', 'examples'};

for i = 1:length(folders)
    addpath(fullfile(root, folders{i}));
end

% Check for Parallel Toolbox and add compatibility functions if needed
if ~exist('gather', 'builtin')
    warning('The MATLAB Parallel Toolbox does not seem to be installed. Activating compatibility functions.');
    addpath(fullfile(root, 'matlab', 'compatibility', 'parallel'));
end