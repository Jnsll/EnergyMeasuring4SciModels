%b=[32 45 83 110 113 116 128 144 147 148 179]';%�ҵ����Ҷ�
%b=[20 21 71 82 133 87 160 172 192 202 209]';%�ҵ������
%b33=[4  6 14 24 36 79 84 89 91 106 166 173 187 200 219 264 299 309 324 346 353 356]';
b33=[55 90 100 115 137 144 147 213 215 223 233 245 288 293 298 300 315 375 382 396 409 10];
a1 = imread('000a.bmp');
b = 0:208;
[m, n] = size(a1);
N = length(b);

% Preallocate array for efficiency
a = zeros(m, n, N * 2);

% Function to generate image name
generateImageName = @(num, suffix) strcat(sprintf('%03d', num), suffix);

% Read 'a' images
for i = 1:N
    imageName = generateImageName(b(i), 'a.bmp');
    a(:, :, i) = imread(imageName);
end

% Read 'b' images
for i = 1:N
    imageName = generateImageName(b(i), 'b.bmp');
    a(:, :, i + N) = imread(imageName);
end

% Initialize binary matrix t
t = zeros(180, 2 * 11 * 29);

% Populate binary matrix t
for i = 1:2*11*19
    for j = 1:m
        ss = sum(a(j, :, i) == 255);
        t(j, i) = ss / n > 0.95;
    end
end

% Compute matching scores
s3 = zeros(2*11*19, 2*11);

for k = 1:2*11
    for i = 1:2*11*19
        s3(i, k) = sum(t(:, b33(k)) == t(:, i));
    end
end

% Sort scores
[r1, u1] = sort(s3);