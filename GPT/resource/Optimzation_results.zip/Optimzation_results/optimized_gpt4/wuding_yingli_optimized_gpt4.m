clear; clc;

% Load data from Excel files
a = xlsread('cumcm.xls', 'sheet1', 'B1:H24'); % ��ص���Ϣ
b = xlsread('cumcm.xls', 'sheet2', 'A1:M18'); % ���������Ϣ
c = xlsread('cumcm.xls', 'sheet3', 'B1:G24'); % ������
d = xlsread('cumcm.xls', 'sheet3', 'A27:D37304'); % ������Ϣ

% Initialize variables
Q = [];
f = 6; % �����ݶ�Ϊ2
N = 100; % ��������

% Preallocate memory for Q and r to improve performance
Q = zeros(size(d, 1), size(d, 2) + 3);
r = false(size(d, 1), 1);

% Vectorized computation for q and q_
area = d(:, 3) .* d(:, 4);
q = area .* c(d(:, 2), f) .* b(d(:, 1), 10) * 0.5 * 31.5 - b(d(:, 1), 13) - area .* a(d(:, 2), 6);
q_ = q ./ (area .* a(d(:, 2), 7));

% Populate Q matrix
Q(:, 1:size(d, 2)) = d;
Q(:, size(d, 2) + 1) = q;
Q(:, size(d, 2) + 2) = q_;
Q(:, size(d, 2) + 3) = area .* a(d(:, 2), 7);

% Identify rows to remove
r = Q(:, end) > N;

% Remove rows where condition is met
Q(r, :) = [];