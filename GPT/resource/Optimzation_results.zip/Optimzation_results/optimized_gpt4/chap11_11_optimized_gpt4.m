% Optimized Matlab Code

I = [1 1 1 1; 1 1 0 1; 0 1 0 1; 0 1 1 1];  % Image data assigned to I, I is a 4x4 matrix

% Track the boundary of the target, the return value is a cell array of size p x 1, where p is the number of targets.
% Each cell element is a Q x 2 matrix, i.e., the x, y coordinates of Q points.

% Use preallocation for better performance
[g, numObjects] = boundaries(I, 4);  % Track 4-connected target boundaries

% Initialize variables to store results
c = cell(numObjects, 1);

% Use a loop to process each boundary
for i = 1:numObjects
    c{i} = fchcode(g{i}, 4);  % Compute 4-direction Freeman chain code
end

% Display results for each object
for i = 1:numObjects
    disp(['Object ', num2str(i)]);
    disp('Start coordinate:');
    disp(c{i}.x0y0);  % Display the starting coordinate (e.g., [1, 2])
    disp('Freeman chain code:');
    disp(c{i}.fcc);  % Freeman chain code (1 x n), boundary point set size n x 2
    disp('First-order difference of chain code:');
    disp(c{i}.diff);  % First-order difference of c.fcc (1 x n)
    disp('Minimum amplitude integer:');
    disp(c{i}.mm);  % Minimum amplitude integer (1 x n)
    disp('First-order difference of minimum amplitude integer:');
    disp(c{i}.diffmm);  % First-order difference of c.mm (1 x n)
end