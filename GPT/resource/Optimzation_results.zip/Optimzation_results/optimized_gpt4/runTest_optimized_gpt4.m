% Script to run the unit tests that test Bayes Factor Toolbox functionality.
import matlab.unittest.TestCase
import matlab.unittest.TestSuite

% Create test suite from the bfUnitTest class
suiteClass = TestSuite.fromClass(?bfUnitTest);

% Run the test suite and collect results
result = run(suiteClass);

% Display results in a table format
disp(table(result))