function biosigpathfirst()
% Add BIOSIG at the beginning of the path 

% Get the paths of 'str2double' and 'sopen' functions
str2doublepath = fileparts(which('str2double'));
sopenpath = fileparts(which('sopen'));

% Add 'sopen' path at the beginning if it's different from 'str2double' path
if ~strcmp(str2doublepath, sopenpath)
    addpath(sopenpath, '-begin');
end