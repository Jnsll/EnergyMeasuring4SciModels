function [param, mosek_exists] = default_mosek_param()
    % Display warning once to avoid repeated warnings
    persistent warned;
    if isempty(warned)
        warning('deprecated. please call default_quadprog_param()');
        warned = true;
    end
    
    % Directly call the default_quadprog_param function
    [param, mosek_exists] = default_quadprog_param();
end