function [param, mosek_exists] = default_quadprog_param()
    % DEFAULT_QUADPROG_PARAM
    % 
    % [param, mosek_exists] = default_quadprog_param()
    %
    % Outputs:
    %   param struct containing some nice default mosek params
    %   mosek_exists  whether mosek exists
    %
    persistent num_threads
    
    % Check if Mosek exists
    mosek_exists = exist('mosekopt', 'file') == 2;
    
    if mosek_exists
        if isempty(num_threads)
            % Determine number of threads to use
            num_threads = max(feature('numCores') - 1, 1);
            if isunix
                % Get the real number of cores on Unix systems
                [r, c] = system('sysctl -n hw.ncpu');
                if r == 0
                    c = str2double(c);
                    if ~isnan(c)
                        num_threads = max(c - 1, 1);
                    end
                end
            end
        end
        
        % Initialize parameter structure
        param = struct();
        
        % Set parameters based on Mosek version
        mosek_path = which('mosekopt');
        if contains(mosek_path, 'mosek/6')
            param.MSK_IPAR_NUM_THREADS = num_threads;
        elseif contains(mosek_path, 'mosek/8') || contains(mosek_path, 'mosek/9')
            param.MSK_IPAR_NUM_THREADS = num_threads;
            param.MSK_DPAR_INTPNT_TOL_REL_GAP = 1e-14;
            param.MSK_DPAR_INTPNT_CO_TOL_REL_GAP = 1e-14;
            param.MSK_DPAR_INTPNT_CO_TOL_DFEAS = 1e-14;
            param.MSK_DPAR_INTPNT_CO_TOL_INFEAS = 1e-14;
            param.MSK_DPAR_INTPNT_CO_TOL_PFEAS = 1e-14;
            param.MSK_DPAR_INTPNT_QO_TOL_DFEAS = 1e-14;
            param.MSK_DPAR_INTPNT_QO_TOL_INFEAS = 1e-14;
            param.MSK_DPAR_INTPNT_QO_TOL_MU_RED = 1e-14;
            param.MSK_DPAR_INTPNT_QO_TOL_PFEAS = 1e-14;
            param.MSK_DPAR_INTPNT_QO_TOL_REL_GAP = 1e-14;
        else
            param.MSK_IPAR_NUM_THREADS = num_threads;
            param.Diagnostics = 'on';
            param.Display = 'iter';
            param.MSK_DPAR_INTPNT_TOL_REL_GAP = 1e-14;
            param.MSK_DPAR_INTPNT_CO_TOL_REL_GAP = 1e-14;
        end

        param.MSK_IPAR_CHECK_CONVEXITY = 'MSK_CHECK_CONVEXITY_NONE';
        
    else
        if verLessThan('matlab', '7.12')
            % Warn user about old MATLAB version
            warning([ ...
                'You are using an old version of MATLAB that does not support ' ...
                'solving large, sparse quadratic programming problems. The ' ...
                'optimization will be VERY SLOW and the results will be ' ...
                'INACCURATE. Please install Mosek or upgrade to MATLAB version >= ' ...
                '2011a.']);
        else
            % Set default parameters for MATLAB's quadprog
            param = optimset( ...
                'TolFun', 1e-16, ...
                'Algorithm', 'interior-point-convex', ...
                'MaxIter', 1000, ...
                'Display', 'off');
        end
    end
end