%% Clear Environment Variables
warning off             % Disable warning messages
close all               % Close all figure windows
clear                   % Clear all variables
clc                     % Clear command window

%% Import Data
res = xlsread('���ݼ�.xlsx');

%% Split Training and Testing Data
temp = randperm(103);

P_train = res(temp(1:80), 1:7)';
T_train = res(temp(1:80), 8)';
P_test = res(temp(81:end), 1:7)';
T_test = res(temp(81:end), 8)';

%% Data Normalization
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%% Transpose for Model Compatibility
p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';

%% Create Model
k = 5;     % Number of principal components to retain
[Xloadings, Yloadings, Xscores, Yscores, betaPLS, PLSPctVar, MSE, stats] = plsregress(p_train, t_train, k);

%% Prediction
t_sim_train = [ones(size(p_train, 1), 1), p_train] * betaPLS;
t_sim_test = [ones(size(p_test, 1), 1), p_test] * betaPLS;

%% Data Denormalization
T_sim_train = mapminmax('reverse', t_sim_train, ps_output);
T_sim_test = mapminmax('reverse', t_sim_test, ps_output);

%% Root Mean Square Error
error_train = sqrt(mean((T_sim_train - T_train').^2));
error_test = sqrt(mean((T_sim_test - T_test').^2));

%% Plotting
figure
plot(1:length(T_train), T_train, 'r-*', 1:length(T_train), T_sim_train, 'b-o', 'LineWidth', 1)
legend('Actual', 'Predicted')
xlabel('Sample Index')
ylabel('Value')
title(['Training Set Prediction Comparison, RMSE=' num2str(error_train)])
grid on

figure
plot(1:length(T_test), T_test, 'r-*', 1:length(T_test), T_sim_test, 'b-o', 'LineWidth', 1)
legend('Actual', 'Predicted')
xlabel('Sample Index')
ylabel('Value')
title(['Testing Set Prediction Comparison, RMSE=' num2str(error_test)])
grid on

%% Performance Metrics
% R2
R_train = 1 - norm(T_train' - T_sim_train)^2 / norm(T_train' - mean(T_train))^2;
R_test = 1 - norm(T_test' - T_sim_test)^2 / norm(T_test' - mean(T_test))^2;

disp(['R2 for Training Set: ', num2str(R_train)])
disp(['R2 for Testing Set: ', num2str(R_test)])

% MAE
mae_train = mean(abs(T_sim_train - T_train'));
mae_test = mean(abs(T_sim_test - T_test'));

disp(['MAE for Training Set: ', num2str(mae_train)])
disp(['MAE for Testing Set: ', num2str(mae_test)])

% MBE
mbe_train = mean(T_sim_train - T_train');
mbe_test = mean(T_sim_test - T_test');

disp(['MBE for Training Set: ', num2str(mbe_train)])
disp(['MBE for Testing Set: ', num2str(mbe_test)])

%% Scatter Plots
sz = 25;
c = 'b';

figure
scatter(T_train, T_sim_train, sz, c)
hold on
plot(xlim, ylim, '--k')
xlabel('Actual Training Values');
ylabel('Predicted Training Values');
title('Training Set: Predicted vs Actual')
grid on

figure
scatter(T_test, T_sim_test, sz, c)
hold on
plot(xlim, ylim, '--k')
xlabel('Actual Testing Values');
ylabel('Predicted Testing Values');
title('Testing Set: Predicted vs Actual')
grid on