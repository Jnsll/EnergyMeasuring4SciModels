clear; clc

% Read data from Excel file
a = xlsread('cumcm.xls', 'sheet1', 'B1:H24'); % Battery information
b = xlsread('cumcm.xls', 'sheet2', 'A1:M18'); % Inverter information
c = xlsread('cumcm.xls', 'sheet3', 'B1:F24'); % Power generation
d = xlsread('cumcm.xls', 'sheet3', 'A27:D37304'); % Arrangement information

f = 5; % Direction, east is 2
N = 40; % Area of each side

% Preallocate memory for Q and r
Q = zeros(37278, size(d, 2) + 3);
r = false(37278, 1);

for i = 1:37278
    area = d(i, 3) * d(i, 4);
    power_gen = c(d(i, 2), f);
    inverter_eff = b(d(i, 1), 10);
    battery_cost = a(d(i, 2), 6);
    battery_capacity = a(d(i, 2), 7);
    q = area * power_gen * inverter_eff * 0.5 * 31.5 - b(d(i, 1), 13) - area * battery_cost;
    q_ = q / (area * battery_capacity);
    Q(i, :) = [d(i, :), q, q_, area * battery_capacity];

    if area * battery_capacity > N
        r(i) = true;
    end
end

Q(r, :) = [];