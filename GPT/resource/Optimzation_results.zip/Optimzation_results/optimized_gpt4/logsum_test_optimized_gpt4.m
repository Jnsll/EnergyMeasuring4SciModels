p1 = log(1e-5);
p2 = log(5*1e-6);

% Precompute the exponentials of p1 and p2 to avoid redundant calculations
exp_p1 = exp(p1);
exp_p2 = exp(p2);

% Use the precomputed values for the sum of exponentials
p3 = log(exp_p1 + exp_p2);

% Utilize the logsumexp function for p4
p4 = logsumexp([p1 p2], 2);

% Remove redundant calculations by reusing the result of p3
p5 = p3;
p6 = p3;