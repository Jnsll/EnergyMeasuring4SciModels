function [D, S] = perform_front_propagation_2d(W, start_points, end_points, nb_iter_max, H)
    % Initialize the size of the grid
    [n, m] = size(W);
    
    % Initialize distance and state matrices
    D = inf(n, m);
    S = ones(n, m); % 1: far, 0: open, -1: dead
    
    % Initialize the priority queue with start points
    pq = [];
    for k = 1:size(start_points, 2)
        i = start_points(1, k);
        j = start_points(2, k);
        D(i, j) = 0;
        S(i, j) = 0;
        pq = [pq; 0, i, j];
    end
    
    % Define the 4 possible movements (right, left, down, up)
    movements = [0, 1; 0, -1; 1, 0; -1, 0];
    
    % Main loop
    iter = 0;
    while ~isempty(pq) && iter < nb_iter_max
        % Pop the element with the smallest distance
        [~, idx] = min(pq(:, 1));
        current = pq(idx, :);
        pq(idx, :) = [];
        
        d = current(1);
        i = current(2);
        j = current(3);
        
        if S(i, j) == -1
            continue;
        end
        
        % Mark the current point as dead
        S(i, j) = -1;
        
        % Update the distances of the neighboring points
        for k = 1:4
            ni = i + movements(k, 1);
            nj = j + movements(k, 2);
            
            if ni > 0 && ni <= n && nj > 0 && nj <= m && S(ni, nj) ~= -1
                new_dist = D(i, j) + W(ni, nj);
                if new_dist < D(ni, nj)
                    D(ni, nj) = new_dist;
                    S(ni, nj) = 0; % Mark as open
                    pq = [pq; new_dist + H(ni, nj), ni, nj];
                end
            end
        end
        
        iter = iter + 1;
    end
end