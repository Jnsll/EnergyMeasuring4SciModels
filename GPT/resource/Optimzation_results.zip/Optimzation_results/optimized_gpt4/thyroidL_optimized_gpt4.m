load thyroid_app
load thyroid_test
thyroid_test = thyroid_test';

[N, Napp] = size(thyroid_app);
[~, Ntest] = size(thyroid_test);

class = 1;

% Unnecessary variable and commented code removal
% rand('state',0); randn('state',0);
% abalone = abalone(:,randperm(m));

app = thyroid_app;
test = thyroid_test;

unique(app(class, :));
unique(test(class, :));

ns = max(thyroid_app, [], 2); % Use max along the second dimension to get the maximum of each row
clear thyroid_app thyroid_test;