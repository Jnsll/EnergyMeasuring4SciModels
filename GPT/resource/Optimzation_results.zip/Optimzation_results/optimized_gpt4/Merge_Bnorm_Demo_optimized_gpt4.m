% Load the data from the .mat file
data = load('sigma=25_Bnorm.mat');

% Extract the 'net' variable from the loaded data
net = data.net;

% Merge batch normalization layers in the network
net = vl_simplenn_mergebnorm(net);

% Save the modified network to a .mat file
save('sigma=25_net.mat', 'net');