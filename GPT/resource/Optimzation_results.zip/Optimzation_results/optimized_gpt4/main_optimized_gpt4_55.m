clear
clc
tic

% Initialize parameters
pop_size = 65;
chromosome_size = 22;
clone_size = 60;
xmin = 0;
xmax = 8;
epochs = 100;
pMutate = 0.1;
cfactor = 0.3;

% Initialize population
pop = InitializeFun(pop_size, chromosome_size);

% Define fitness function
F = @(X) X + 10 * sin(X .* 5) + 9 * cos(X .* 4);

% Initialize tracking variables
E_best = [];
E_ave = [];

% Decode initial population
X = DecodeFun(pop, xmin, xmax);

% Evaluate initial fitness
Fit = F(X);

% Plot initial antibody distribution
figure(1);
fplot(F, [xmin, xmax]);
grid on;
hold on;
plot(X, Fit, 'k*');
title('����ĳ�ʼ��λ�÷ֲ�ͼ');
xlabel('x');
ylabel('y');

% Main loop
for epoch = 1:epochs
    % Decode population
    X = DecodeFun(pop, xmin, xmax);
    
    % Evaluate fitness
    Fit = F(X);
    
    % Plot current antibody distribution
    figure(2);
    fplot(F, [xmin, xmax], 'b');
    grid on;
    hold on;
    plot(X, Fit, 'r*');
    hold off;
    title('���������λ�÷ֲ�ͼ');
    xlabel('x');
    ylabel('y');
    pause(0.01);
    
    % Sort fitness and select top clones
    [FS, Affinity] = sort(Fit, 'ascend');
    XT = X(Affinity(end - clone_size + 1: end));
    FT = FS(end - clone_size + 1: end);

    % Track best fitness
    E_best = [E_best, FT(end)];
    
    % Reproduce and mutate clones
    [Clone, AAS] = ReproduceFun(clone_size, cfactor, pop_size, Affinity, pop, []);
    Clone = Hypermutation(Clone, chromosome_size, pMutate);

    % Update population with best clones
    AF = fliplr(Affinity(end - clone_size + 1: end));
    Clone(AAS, :) = pop(AF, :);
    X = DecodeFun(Clone, xmin, xmax);
    Fit = F(X);
    
    % Track average fitness
    E_ave = [E_ave, mean(Fit)];
    
    % Select best clones
    for i = 1:clone_size
        [OUT(i), BBS(i)] = max(Fit(AAS(i) + 1 : AAS(i + 1)));
        BBS(i) = BBS(i) + AAS(i);
    end
    
    % Update population with best clones
    AF2 = fliplr(Affinity(end - clone_size + 1 : end));
    pop(AF2, :) = Clone(BBS, :);
end

% Display optimal point
fprintf('\n The optimal point is: ');
fprintf('\n x: %2.4f. f(x): %2.4f', XT(end), E_best(end));

% Plot fitness trend
figure(3)
grid on 
plot(E_best)
title('��Ӧֵ�仯����')
xlabel('������')
ylabel('��Ӧֵ')
hold on
plot(E_ave, 'r')
hold off
toc