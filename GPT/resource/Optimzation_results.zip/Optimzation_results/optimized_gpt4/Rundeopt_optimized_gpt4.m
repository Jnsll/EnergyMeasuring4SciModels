%********************************************************************
% Differential Evolution Algorithm
%********************************************************************
%% Optimization Termination Condition
F_VTR = 0;  % Target function optimal value threshold

% Number of parameters for the objective function
I_D = 3; 

% Parameter bounds
FVr_minbound = -6 * ones(1, I_D); 
FVr_maxbound = 6 * ones(1, I_D); 
I_bnd_constr = 0;  % Use bounds: 1 for yes, 0 for no

%% Population size: 5 to 20 times the number of parameters
I_NP = 40; 

%% Maximum number of generations
I_itermax = 50; 

%% Mutation parameter DE-stepsize F_weight [0, 2]
F_weight = 0.3; 

%% Crossover probability constant [0, 1]
F_CR = 0.5; 

%% Algorithm selection
% I_strategy:
% 1 --> DE/rand/1:          Classic DE algorithm, random base vector
% 2 --> DE/local-to-best/1: Robust and fast convergence
% 3 --> DE/best/1 with jitter: Fast convergence for small populations and low dimensions
% 4 --> DE/rand/1 with per-vector-dither
% 5 --> DE/rand/1 with per-generation-dither
% 6 --> DE/rand/1 either-or-algorithm

I_strategy = 5;

%% Auxiliary information parameters
I_refresh = 10; % Output intermediate individuals every I_refresh generations
I_plotting = 0; % Plotting option: 1 to plot, 0 to not plot

% %% Plotting parameters for 2D visualization
if I_plotting == 1      
    FVc_xx = -6:0.2:6;
    FVc_yy = -6:0.2:6;

    [FVr_x, FM_y] = meshgrid(FVc_xx, FVc_yy);
    FM_meshd = 20 + (FVr_x.^2 - 10 * cos(2 * pi * FVr_x)) + ...
                     (FM_y.^2 - 10 * cos(2 * pi * FM_y));
      
    S_struct.FVc_xx = FVc_xx;
    S_struct.FVc_yy = FVc_yy;
    S_struct.FM_meshd = FM_meshd;
end

S_struct = struct(...
    'I_NP', I_NP, ...               % Population size
    'F_weight', F_weight, ...       % Mutation parameter
    'F_CR', F_CR, ...               % Crossover parameter
    'I_D', I_D, ...                 % Number of parameters
    'FVr_minbound', FVr_minbound, ... % Lower bounds
    'FVr_maxbound', FVr_maxbound, ... % Upper bounds
    'I_bnd_constr', I_bnd_constr, ... % Use bounds constraint
    'I_itermax', I_itermax, ...     % Maximum number of generations
    'F_VTR', F_VTR, ...             % Optimal function value threshold
    'I_strategy', I_strategy, ...   % Algorithm selection
    'I_refresh', I_refresh, ...     % Output option
    'I_plotting', I_plotting ...    % Plotting option
);

%********************************************************************
% Start of optimization
%********************************************************************

[FVr_x, S_y, I_nf] = deopt('objfun', S_struct);