% Alamouti_scheme.m
clear;
clc;
clf;
L_frame = 130;
N_Packets = 4000; % Number of frames/packet and Number of packets
NT = 2;
NR = 2;
b = 2;
SNRdBs = 0:2:20;
sq_NT = sqrt(NT);
sq2 = sqrt(2);

% Preallocate memory for variables
noeb_p = zeros(N_Packets, 1);
BER = zeros(length(SNRdBs), 1);

for i_SNR = 1:length(SNRdBs)
    SNRdB = SNRdBs(i_SNR);
    sigma = sqrt(0.5 / (10^(SNRdB / 10)));
    
    for i_packet = 1:N_Packets
        msg_symbol = randi([0, 1], L_frame * b, NT);
        tx_bits = msg_symbol.';
        tmp = zeros(b * L_frame, NT);
        sym_tab = [];
        P = 0;

        for i = 1:NT
            [tmp(:, i), sym_tab, P] = modulator(tx_bits(i, :), b);
        end

        X = tmp.';
        X1 = X;
        X2 = [-conj(X(:, 2)), conj(X(:, 1))];

        Hr = (randn(L_frame, NT, NT) + 1j * randn(L_frame, NT, NT)) / sq2;
        H = reshape(Hr(1, :, :), L_frame, NT);
        Habs = sum(abs(H).^2, 2);

        noise = sigma * (randn(L_frame, 1) + 1j * randn(L_frame, 1));
        R1 = sum(H .* X1, 2) / sq_NT + noise;
        R2 = sum(H .* X2, 2) / sq_NT + noise;

        Z1 = R1 .* conj(H(:, 1)) + conj(R2) .* H(:, 2);
        Z2 = R1 .* conj(H(:, 2)) - conj(R2) .* H(:, 1);

        d1 = zeros(L_frame, P);
        d2 = zeros(L_frame, P);

        for m = 1:P
            tmp = (-1 + sum(Habs, 2)) * abs(sym_tab(m))^2;
            d1(:, m) = abs(sum(Z1, 2) - sym_tab(m)).^2 + tmp;
            d2(:, m) = abs(sum(Z2, 2) - sym_tab(m)).^2 + tmp;
        end

        [~, i1] = min(d1, [], 2);
        S1d = sym_tab(i1).';
        [~, i2] = min(d2, [], 2);
        S2d = sym_tab(i2).';

        Xd = [S1d, S2d];
        noeb_p(i_packet) = sum(sum(X > 0) ~= sum(Xd > 0));
    end % End of FOR loop for i_packet

    BER(i_SNR) = sum(noeb_p) / (N_Packets * L_frame * b);
end % End of FOR loop for i_SNR

semilogy(SNRdBs, BER);
axis([SNRdBs([1 end]) 1e-6 1e0]);
grid on;
xlabel('SNR[dB]');
ylabel('BER');