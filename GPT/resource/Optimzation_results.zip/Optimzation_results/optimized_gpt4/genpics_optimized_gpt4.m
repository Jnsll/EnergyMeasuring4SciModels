% Clear environment and load data once to avoid redundancy
clear;
cd('./');

% Load and analyze data for 2400m and 100m
data_files = {'2400m����������.mat', '100m����������.mat'};
output_prefixes = {'2400m��', '100m��'};

for k = 1:length(data_files)
    load(data_files{k});
    
    % �������
    figure;
    surface(data4, 'EdgeColor', 'none');
    colorbar;
    saveas(gcf, [output_prefixes{k}, '�������.png']);
    
    % ��������
    cla;
    surf(score, 'EdgeColor', 'none');
    colorbar;
    saveas(gcf, [output_prefixes{k}, '�������.png']);
end

% Perform calculations and plot results for different stages
calc_files = {'calc_proc2', 'calc_proc'};
output_files = {'��һ�׶ν���', '����һ����'};
history_limits = [0.45, 0.8];

for k = 1:length(calc_files)
    clear;
    cla;
    feval(calc_files{k});
    
    % y-x �켣
    saveas(gcf, [output_files{k}, 'y-x�켣.png']);
    
    % Vx, Vy-t �켣
    cla;
    hold on;
    plot(history(:,1), history(:,3), 'b', 'LineWidth', 2);
    plot(history(:,1), history(:,4), 'red', 'LineWidth', 2);
    legend('\fontsize {17}Vx', '\fontsize {17}Vy');
    xlabel 't/s';
    ylabel 'V/(m/s)';
    saveas(gcf, [output_files{k}, 'Vx��Vy-t�켣.png']);
    
    % ��-t �켣
    cla;
    hold on;
    plot(history(:,1), history(:,5), 'black', 'LineWidth', 2);
    axis([0, 450, 0, history_limits(k)]);
    xlabel 't/s';
    ylabel '��/rad';
    saveas(gcf, [output_files{k}, 'sita-t�켣.png']);
end

% Load data for miscellaneous analysis
clear;
load('2400m����������.mat');

% Preallocate plotdata
plotdata = zeros(255, 2);
for i = 1:255
    plotdata(i, :) = [i, sum(sum(A == i))];
end

% Find maximum values for different categories
max_values = zeros(1, 4);
for i = 1:460
    for j = 1:460
        if data4(i, j) == 0 && data(i, j) > max_values(1)
            max_values(1) = data(i, j);
        elseif data4(i, j) == 1 && data(i, j) > max_values(2)
            max_values(2) = data(i, j);
        elseif data4(i, j) == 2 && data(i, j) > max_values(3)
            max_values(3) = data(i, j);
        elseif data4(i, j) == 3 && data(i, j) > max_values(4)
            max_values(4) = data(i, j);
        end
    end
end

% Plot results
hold on;
plot(plotdata(:, 1), plotdata(:, 2), 'black', 'LineWidth', 1.5);
for i = 1:4
    plot([max_values(i) + 0.5, max_values(i) + 0.5], [0, 3.5e5], 'red', 'LineWidth', 2, 'linestyle', ':');
end
axis([0, 255, 0, 400000]);
saveas(gcf, '�ҽ׷ֲ�.png');