function DrawRastrigin()
    x = -4: 0.05: 4;
    y = x;
    [X, Y] = meshgrid(x, y);
    Z = arrayfun(@(x, y) Rastrigin([x, y]), X, Y);
    surf(X, Y, Z);
    shading interp
end