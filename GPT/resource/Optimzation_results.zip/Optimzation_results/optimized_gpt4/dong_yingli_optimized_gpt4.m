% Clear workspace and command window
clear; clc;

% Read data from Excel files
a = xlsread('cumcm.xls', 'sheet1', 'B1:H24'); % ��ص���Ϣ
b = xlsread('cumcm.xls', 'sheet2', 'A1:M18'); % ���������Ϣ
c = xlsread('cumcm.xls', 'sheet3', 'B1:F24'); % ������
d = xlsread('cumcm.xls', 'sheet3', 'A27:D37304'); % ������Ϣ

% Initialize variables
Q = [];
f = 2; % ���򣬶���Ϊ2
N = 24; % ��������
r = false(size(d, 1), 1); % Preallocate logical array for indices to remove

% Precompute constants
half_31_5 = 0.5 * 31.5;

% Vectorized computation of q and q_
q = d(:, 3) .* d(:, 4) .* c(d(:, 2), f) .* b(d(:, 1), 10) * half_31_5 - b(d(:, 1), 13) - d(:, 3) .* d(:, 4) .* a(d(:, 2), 6);
q_ = q ./ (d(:, 3) .* d(:, 4) .* a(d(:, 2), 7));

% Create Q matrix
Q = [d, q, q_, d(:, 3) .* d(:, 4) .* a(d(:, 2), 7)];

% Identify rows where condition is met
r = (d(:, 3) .* d(:, 4) .* a(d(:, 2), 7)) > N;

% Remove rows from Q
Q(r, :) = [];