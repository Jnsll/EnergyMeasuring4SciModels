clear
clc

% Define the fitness function handle
fitnessfcn = @GA_demo;

% Number of variables
nvars = 2;

% Set genetic algorithm options
options = gaoptimset('PopulationSize', 100, ...
                     'EliteCount', 10, ...
                     'CrossoverFraction', 0.75, ...
                     'Generations', 500, ...
                     'StallGenLimit', 500, ...
                     'TolFun', 1e-6, ... % Adjusted for practical convergence
                     'PlotFcns', {@gaplotbestf, @gaplotbestindiv});

% Call the genetic algorithm function
[x_best, fval] = ga(fitnessfcn, nvars, [], [], [], [], [], [], [], options);