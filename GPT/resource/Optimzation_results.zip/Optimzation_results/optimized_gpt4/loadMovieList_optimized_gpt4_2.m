function movieList = loadMovieList()
%LOADMOVIELIST reads the fixed movie list in movie.txt and returns a
%cell array of the words
%   movieList = LOADMOVIELIST() reads the fixed movie list in movie.txt 
%   and returns a cell array of the words in movieList.

% Read the fixed movie list
fid = fopen('movie_ids.txt');

if fid == -1
    error('File movie_ids.txt cannot be opened.');
end

% Store all movies in cell array movieList
movieList = textscan(fid, '%*d %[^\n]', 'Delimiter', '\n');
movieList = movieList{1};

fclose(fid);

end