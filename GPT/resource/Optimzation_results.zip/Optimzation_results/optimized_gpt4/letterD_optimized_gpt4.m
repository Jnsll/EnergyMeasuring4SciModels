% Load data
load('letter_A', '-ascii');
load('letter_T', '-ascii');

% Determine sizes
[N, m] = size(letter_A);

% Assign class variable
class = N;

% Assign and determine sizes of app and test
app  = letter_A;
test = letter_T;

Napp = size(app, 2);
Ntest = size(test, 2);

% Get unique elements in class row of app and test
unique_app = unique(app(class, :));
unique_test = unique(test(class, :));

% Calculate max values and overall max
ns1 = max(letter_A, [], 2);
ns2 = max(letter_T, [], 2);
ns = max([ns1; ns2]);

% Clear unnecessary variables
clear letter_A letter_T ns1 ns2;

% Display results
disp(['N: ', num2str(N)]);
disp(['ns(class): ', num2str(ns(class))]);
disp(['Napp: ', num2str(Napp)]);
disp(['Ntest: ', num2str(Ntest)]);
disp(['mean(ns): ', num2str(mean(ns))]);