% Optimized Matlab Code

% Clear workspace and close all figures
close all;
clear;
clc;

% Read the image and extract RGB components
I = imread('huangguahua.jpg');
R = I(:,:,1);
G = I(:,:,2);
B = I(:,:,3);

% Set default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(0, 'defaultFigureColor', [1 1 1]);

% Display the original image and its RGB components
figure;
subplot(221); imshow(I); title('Original Image');
subplot(222); imshow(R); title('R Component');
subplot(223); imshow(G); title('G Component');
subplot(224); imshow(B); title('B Component');

% Display histograms for RGB components
figure;
subplot(131); imhist(R); title('Histogram of R Component');
subplot(132); imhist(G); title('Histogram of G Component');
subplot(133); imhist(B); title('Histogram of B Component');