function class_info = gen_class_info_ade()

% Load class information
data = load('class_info_ADE.mat');
class_info_ADE = data.class_info_ADE;

% Ensure class names are in the correct format
class_names = class_info_ADE.Name;
assert(size(class_names, 2) == 1);
class_names = [{'void'}; class_names];

% Define class label values
class_label_values = uint8([0 1:150]);

% Initialize class information structure
class_info = struct(...
    'class_names', class_names, ...
    'class_label_values', class_label_values, ...
    'background_label_value', uint8(1), ...
    'void_label_values', uint8(0), ...
    'mask_cmap', VOClabelcolormap(256) ...
);

% Process class information
class_info = process_class_info(class_info);

end