```matlab
clc
clear all

names = {'DenseFuse', 'RFN-Nest', 'FusionGAN', 'SeAFusion', 'PIAFusion', 'IFCNN', 'PMGI', 'SDNet', 'U2Fusion'};
rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'];
easy = 1; % easy=1 for testing: EN, SF, SD, PSNR, MSE, MI, VIF, AG, CC, SCD, Qabf metrics; easy=0 for testing: Nabf, SSIM, MS_SSIM, FMI_pixel, FMI_dct, FMI_w metrics
dataset = 'TNO';
row_name1 = 'row1';
row_data1 = 'row2';

fileFolder = fullfile('../Image/Source-Image', dataset, 'ir');
dirOutput = dir(fullfile(fileFolder, '*.*'));
fileNames = {dirOutput.name};
numFiles = numel(fileNames);

ir_dir = fullfile('../Image/Source-Image', dataset, 'ir');
vi_dir = fullfile('../Image/Source-Image', dataset, 'vi');
save_dir = '../Metric'; % Directory to save Excel results
if ~exist(save_dir, 'dir')
    mkdir(save_dir);
end

for i = 1:length(names)
    method_name = names{i};
    row = rows(i);
    row_name = strrep(row_name1, 'row', row);
    row_data = strrep(row_data1, 'row', row);
    Fused_dir = fullfile('../Image/Algorithm', strcat(method_name, '_', dataset));

    EN_set = []; SF_set = []; SD_set = []; PSNR_set = [];
    MSE_set = []; MI_set = []; VIF_set = []; AG_set = [];
    CC_set = []; SCD_set = []; Qabf_set = [];
    SSIM_set = []; MS_SSIM_set = [];
    Nabf_set = []; FMI_pixel_set = [];
    FMI_dct_set = []; FMI_w_set = [];

    for j = 1:numFiles
        if strcmp(fileNames{j}, '.') || strcmp(fileNames{j}, '..')
            continue;
        end

        fileName_source_ir = fullfile(ir_dir, fileNames{j});
        fileName_source_vi = fullfile(vi_dir, fileNames{j});
        fileName_Fusion = fullfile(Fused_dir, fileNames{j});

        ir_image = imread(fileName_source_ir);
        vi_image = imread(fileName_source_vi);
        fused_image = imread(fileName_Fusion);

        if size(ir_image, 3) > 2
            ir_image = rgb2gray(ir_image);
        end

        if size(vi_image, 3) > 2
            vi_image = rgb2gray(vi_image);
        end

        if size(fused_image, 3) > 2
            fused_image = rgb2gray(fused_image);
        end

        if ndims(ir_image) < 3 && ndims(vi_image) < 3
            [EN, SF, SD, PSNR, MSE, MI, VIF, AG, CC, SCD, Qabf, Nabf, SSIM, MS_SSIM, FMI_pixel, FMI_dct, FMI_w] = analysis_Reference(fused_image, ir_image, vi_image, easy);
            EN_set = [EN_set, EN]; SF_set = [SF_set, SF]; SD_set = [SD_set, SD]; PSNR_set = [PSNR_set, PSNR];
            MSE_set = [MSE_set, MSE]; MI_set = [MI_set, MI]; VIF_set = [VIF_set, VIF];
            AG_set = [AG_set, AG]; CC_set = [CC_set, CC]; SCD_set = [SCD_set, SCD];
            Qabf_set = [Qabf_set, Qabf]; Nabf_set = [Nabf_set, Nabf];
            SSIM_set = [SSIM_set, SSIM]; MS_SSIM_set = [MS_SSIM_set, MS_SSIM];
            FMI_pixel_set = [FMI_pixel_set, FMI_pixel]; FMI_dct_set = [FMI_dct_set, FMI_dct];
            FMI_w_set = [FMI_w_set, FMI_w];
        else
            disp('unsuccessful!');
            disp(fileName_Fusion);
        end

        fprintf('Fusion Method: %s, Image Name: %s\n', method_name, fileNames{j});
    end

    file_name = fullfile(save_dir, strcat('Metric_', dataset, '.xlsx'));

    if easy == 1
        metrics = {'SD', 'PSNR', 'MSE', 'MI', 'VIF', 'AG', 'CC', 'SCD', 'EN', 'Qabf', 'SF'};
        sets = {SD_set, PSNR_set, MSE_set, MI_set, VIF_set, AG_set, CC_set, SCD_set, EN_set, Qabf_set, SF_set};

        for k = 1:length(metrics)
            writetable(table(sets{k}'), file_name, 'Sheet', metrics{k}, 'Range', row_data);
            writetable(table({method_name}), file_name, 'Sheet', metrics{k}, 'Range', row_name);
        end
    else
        metrics = {'Nabf', 'SSIM', 'MS_SSIM', 'FMI