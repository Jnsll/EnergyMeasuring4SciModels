% Parameters
global w h a W r x lamda n;
w = 2.5;
h = 70 - 3;
a = 1;
W = 80;
lamda = 5;
r = sqrt(40*40 + 2.5*2.5);

% Optimization solution
x = (2.5:2.5:40)';
ts0 = [pi/4, h/2];
lb = [0, 0];
ub = [pi/2, h];
ts = fmincon(@objfun, ts0, [], [], [], [], lb, ub, @confun);

theta = ts(1);       % Optimization result
s = ts(2);           % Optimization result
l = w + h / sin(theta);
d = l - s;
n = 80 / 2.5 + 1;

% Coordinates of side points
xc = -40:2.5:40;
yc = sqrt(r^2 - xc.^2);
zc = zeros(1, n);

% Coordinates of steel points
xg = xc;
yg = d * cos(theta) * ones(1, n) + w;
zg = d * sin(theta) * ones(1, n);

% Distance from side to steel points
dis = sqrt((xc - xg).^2 + (yc - yg).^2 + (zc - zg).^2);

% Distance from opening to midpoint
margin = l - yc - dis;

% Coordinates of template top points
k = (margin + dis) ./ dis;
xd = xc + k .* (xg - xc);
yd = yc + k .* (yg - yc);
zd = zc + k .* (zg - zc);

% Plotting
figure(1); hold on;
plot3(xc, yc, zc, '*');
plot3(xg, yg, zg, 'r');
for i = 1:n
    line([xc(i), xg(i)], [yc(i), yg(i)], [zc(i), zg(i)], 'LineWidth', 2);
    line([xd(i), xg(i)], [yd(i), yg(i)], [zd(i), zg(i)], 'LineWidth', 2);
end

figure(1); hold on;
plot3(xc, -yc, zc, '*');
plot3(xg, -yg, zg, 'r');
for i = 1:n
    line([xc(i), xg(i)], [-yc(i), -yg(i)], [zc(i), zg(i)], 'LineWidth', 1, 'Color', [.2 .2 .2]);
    line([xd(i), xg(i)], [-yd(i), -yg(i)], [zd(i), zg(i)], 'LineWidth', 1, 'Color', [.2 .2 .2]);
end

plot3(xc, yc, zc); plot3(xc, -yc, zc);
line([xc(1), xc(1)], [yc(1), -yc(1)], [zc(1), zc(1)], 'LineWidth', 2);
line([xc(end), xc(end)], [yc(end), -yc(end)], [zc(end), zc(end)], 'LineWidth', 2);
view(3);

[X, Y, Z] = sphere(30);
X = l * X / 2; Y = l * Y / 2; Z = zeros(31);
surf(X, Y, Z);
colormap(spring);
alpha(.5);
shading interp; axis equal; axis off;