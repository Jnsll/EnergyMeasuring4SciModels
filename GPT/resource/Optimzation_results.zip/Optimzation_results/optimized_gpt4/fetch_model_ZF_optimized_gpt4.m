cur_dir = pwd;
cd(fileparts(mfilename('fullpath')));

try
    fprintf('Downloading model_ZF...\n');
    outfilename = websave('model_ZF.zip', 'https://onedrive.live.com/download?resid=36FEC490FBC32F1A!113&authkey=!AIzdm0sD_SmhUQ4&ithint=file%2czip');

    fprintf('Unzipping...\n');
    unzip(outfilename, '..');

    fprintf('Done.\n');
    delete(outfilename);
catch ME
    fprintf('Error in downloading, please try links in README.md https://github.com/ShaoqingRen/faster_rcnn\n'); 
    disp(ME.message);
end

cd(cur_dir);