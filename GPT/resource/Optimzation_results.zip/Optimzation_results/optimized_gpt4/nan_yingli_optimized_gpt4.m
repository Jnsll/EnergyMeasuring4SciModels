clear; clc

% Load data from Excel sheets
a = xlsread('cumcm.xls', 'sheet1', 'B1:H24'); % Battery information
b = xlsread('cumcm.xls', 'sheet2', 'A1:M18'); % Inverter information
c = xlsread('cumcm.xls', 'sheet3', 'B1:F24'); % Power generation
d = xlsread('cumcm.xls', 'sheet3', 'A27:D37304'); % Arrangement information

% Preallocate arrays for efficiency
Q = zeros(37278, size(d, 2) + 3); % Preallocate for Q with additional columns for q, q_, and the area product
r = false(37278, 1); % Logical array to mark rows to be removed

% Constants
f = 3; % Direction, eastward is 2
N = 80; % Area threshold

% Loop through the data
for i = 1:37278
    area_product = d(i, 3) * d(i, 4);
    q = area_product * c(d(i, 2), f) * b(d(i, 1), 10) * 0.5 * 31.5 - b(d(i, 1), 13) - area_product * a(d(i, 2), 6);
    q_ = q / (area_product * a(d(i, 2), 7));
    
    Q(i, :) = [d(i, :), q, q_, area_product * a(d(i, 2), 7)];
    
    if (area_product * a(d(i, 2), 7)) > N
        r(i) = true;
    end
end

% Remove marked rows
Q(r, :) = [];