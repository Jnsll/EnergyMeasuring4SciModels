% Initialize weights
w1 = rand(1, 400);
w2 = rand(1, 400);

% Normalize weights
w1 = w1 / sum(w1);
w2 = w2 / sum(w2);

% Calculate pairwise distance
C = pdist2(w1', w2');

% Compute Earth Mover's Distance
[e, Flow] = emd_mex(w1, w2, C);