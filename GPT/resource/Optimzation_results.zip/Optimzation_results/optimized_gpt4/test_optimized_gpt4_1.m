%% LVQ Neural Network Prediction - Face Recognition
%
% <html>
% <table border="0" width="600px" id="table1">
% <tr><td><b><font size="2">Author's Declaration:</font></b></td></tr>
% <tr><td><span class="comment"><font size="2">1: I am stationed in this <a target="_blank" href="http://www.ilovematlab.cn/forum-158-1.html"><font color="#0000FF">section</font></a> for a long time. Questions about this case will be answered. The official website of this book is: <a href="http://video.ourmatlab.com">video.ourmatlab.com</a></font></span></td></tr>
% <tr><td><font size="2">2: Click here <a href="http://union.dangdang.com/transfer/transfer.aspx?from=P-284318&backurl=http://www.dangdang.com/">to pre-order the book from Dangdang</a>: <a href="http://union.dangdang.com/transfer/transfer.aspx?from=P-284318&backurl=http://www.dangdang.com/">"30 Cases of Matlab Neural Networks"</a>.</td></tr>
% <tr><td><p class="comment"></font><font size="2">3</font><font size="2">: This case has supporting teaching videos, download method: <a href="http://video.ourmatlab.com/vbuy.html">video.ourmatlab.com/vbuy.html</a></font><font size="2">.</font></p></td></tr>
% <tr><td><span class="comment"><font size="2">4: This case is original. Please indicate the source when reprinting ("30 Cases of Matlab Neural Networks").</font></span></td></tr>
% <tr><td><span class="comment"><font size="2">5: If this case happens to be related to your research, we welcome your comments and suggestions. We may consider adding them to the case.</font></span></td></tr>
% </table>
% </html>

%% Clear environment variables
clearvars
clc

%% Face Feature Vector Extraction
% Number of people
M = 10;
% Number of face orientation categories
N = 5; 
% Feature vector extraction
pixel_value = feature_extraction(M, N);

%% Generate Training/Test Set
% Generate random sequence of image numbers
rand_label = randperm(M * N);  
% Face orientation labels
direction_label = repelem(1:N, M);
% Training set
train_label = rand_label(1:30);
P_train = pixel_value(train_label, :)';
Tc_train = direction_label(train_label);
% Test set
test_label = rand_label(31:end);
P_test = pixel_value(test_label, :)';
Tc_test = direction_label(test_label);

%% Calculate PC
rate = arrayfun(@(i) sum(Tc_train == i) / 30, 1:N, 'UniformOutput', false);

%% LVQ1 Algorithm
[w1, w2] = lvq1_train(P_train, Tc_train, 20, cell2mat(rate), 0.01, 5);
result_1 = lvq_predict(P_test, Tc_test, 20, w1, w2);

%% LVQ2 Algorithm
[w1, w2] = lvq2_train(P_train, Tc_train, 20, 0.01, 5, w1, w2);
result_2 = lvq_predict(P_test, Tc_test, 20, w1, w2);

web('http://www.matlabsky.com/thread-11193-1-1.html', '-browser')

%%
% <html>
% <table width="656" align="left">
% <tr><td align="center"><p><font size="2"><a href="http://video.ourmatlab.com/">30 Cases of Matlab Neural Networks</a></font></p>
% <p align="left"><font size="2">Related Forum:</font></p>
% <p align="left"><font size="2">Official website of "30 Cases of Matlab Neural Networks": <a href="http://video.ourmatlab.com">video.ourmatlab.com</a></font></p>
% <p align="left"><font size="2">Matlab Technology Forum: <a href="http://www.matlabsky.com">www.matlabsky.com</a></font></p>
% <p align="left"><font size="2">Matlab Function Encyclopedia: <a href="http://www.mfun.la">www.mfun.la</a></font></p>
% <p align="left"><font size="2">Matlab Chinese Forum: <a href="http://www.ilovematlab.com">www.ilovematlab.com</a></font></p></td></tr>
% </table>
% </html>