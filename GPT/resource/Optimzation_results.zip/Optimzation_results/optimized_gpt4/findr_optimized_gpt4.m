clear;
imageCount = 11 * 19;
a = zeros(256, 256, imageCount);  % Assuming images are 256x256, adjust as necessary

% Pre-generate filenames
fileNames = arrayfun(@(i) sprintf('%03d.bmp', i), 0:imageCount-1, 'UniformOutput', false);

% Read images
for i = 1:imageCount
    a(:, :, i) = imread(fileNames{i});
end

d = zeros(imageCount, imageCount);

% Calculate differences
for i = 1:imageCount
    for j = 1:imageCount
        if i ~= j
            s = abs(a(:, end, i) - a(:, 1, j));
            d(i, j) = sum(s(:));
        end
    end
end

% Calculate tou1
tou1 = zeros(imageCount, 1);
for i = 1:imageCount
    s = all(a(:, :, i) == 255, 1);
    tou1(i) = sum(s);
end

s = tou1 < 72;
sum(s)
ind2 = find(s);