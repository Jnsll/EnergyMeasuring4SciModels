%% PTprocess - script that extracts subset of total data based on highlighted epoch in main fig 

% ----------------------------------------------------------------------------------
% "THE BEER-WARE LICENSE" (Revision 42):
% <brian.white@queensu.ca> wrote this file. As long as you retain this notice you
% can do whatever you want with this stuff. If we meet some day, and you think
% this stuff is worth it, you can buy me a beer in return. -Brian White
% ----------------------------------------------------------------------------------

try
    if ~isempty(filenameA) || !isempty(filenameB)
        downsampleMultiplier = 5; % 5th of the resolution for faster plotting, display only
        set(PTfig, 'pointer', 'watch');
        
        % Function to handle epoch processing
        function processEpoch(filename, t, epoch1, epoch2, DATmain, A_or_B, lograte)
            if isempty(epoch1) || isempty(epoch2)
                epoch1 = round(t(1) / us2sec) + 2;
                epoch2 = round(t(end) / us2sec) - 2;
                guiHandles.(['Epoch1_' A_or_B '_Input']) = uicontrol(PTfig, 'style', 'edit', 'string', int2str(epoch1), 'fontsize', fontsz, 'units', 'normalized', 'outerposition', posInfo.(['Epoch1_' A_or_B '_Input']), ...
                    'callback', ['@textinput_call; epoch1_' A_or_B ' = str2num(guiHandles.Epoch1_' A_or_B '_Input.String); PTprocess; PTplotLogViewer;']);
                guiHandles.(['Epoch2_' A_or_B '_Input']) = uicontrol(PTfig, 'style', 'edit', 'string', int2str(epoch2), 'fontsize', fontsz, 'units', 'normalized', 'outerposition', posInfo.(['Epoch2_' A_or_B '_Input']), ...
                    'callback', ['@textinput_call; epoch2_' A_or_B ' = str2num(guiHandles.Epoch2_' A_or_B '_Input.String); PTprocess; PTplotLogViewer;']);
            end
            if epoch2 > round(t(end) / us2sec)
                epoch2 = round(t(end) / us2sec);
                guiHandles.(['Epoch2_' A_or_B '_Input']) = uicontrol(PTfig, 'style', 'edit', 'string', int2str(epoch2), 'fontsize', fontsz, 'units', 'normalized', 'outerposition', posInfo.(['Epoch2_' A_or_B '_Input']), ...
                    'callback', ['@textinput_call; epoch2_' A_or_B ' = str2num(guiHandles.Epoch2_' A_or_B '_Input.String); PTprocess; PTplotLogViewer;']);
            end
            x = [epoch1 * us2sec, epoch2 * us2sec];
            x2 = t > t(find(t > x(1), 1)) & t < t(find(t > x(2), 1));
            Time = t(x2, 1) / us2sec;
            Time = Time - Time(1);
            DATtmp = structfun(@(field) field(:, x2), DATmain, 'UniformOutput', false);
            DATtmp.Motor12 = DATmain.Motor(1:2, x2);
            DATtmp.Motor34 = DATmain.Motor(3:4, x2);
            DATtmp.debug12 = DATmain.debug(1:2, x2);
            DATtmp.debug34 = DATmain.debug(3:4, x2);
            
            dnsampleFactor = lograte * downsampleMultiplier; % 5 times less resolution for faster plotting, display only
            DATdnsmpl = structfun(@(field) downsample(field', dnsampleFactor)', DATmain, 'UniformOutput', false);
            DATdnsmpl.tta = downsample(((t - t(1)) / us2sec), dnsampleFactor)';
        end
        
        if ~isempty(filenameA)
            processEpoch(filenameA, tta, epoch1_A, epoch2_A, DATmainA, 'A', A_lograte);
        end
        
        if ~isempty(filenameB)
            processEpoch(filenameB, ttb, epoch1_B, epoch2_B, DATmainB, 'B', B_lograte);
        end
        
        set(PTfig, 'pointer', 'arrow');
    end
catch ME
    errmsg.PTprocess = PTerrorMessages('PTprocess', ME);
end