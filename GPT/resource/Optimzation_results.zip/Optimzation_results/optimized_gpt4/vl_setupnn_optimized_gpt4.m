function vl_setupnn()
%VL_SETUPNN Setup the MatConvNet toolbox.
%   VL_SETUPNN() function adds the MatConvNet toolbox to MATLAB path.

% Copyright (C) 2014-15 Andrea Vedaldi.
% All rights reserved.
%
% This file is part of the VLFeat library and is made available under
% the terms of the BSD license (see the COPYING file).

root = vl_rootnn();
matlab_paths = {'matlab', 'matlab/mex', 'matlab/simplenn', 'matlab/xtest', 'examples'};
cellfun(@(p) addpath(fullfile(root, p)), matlab_paths);

if ~exist('gather', 'file')
  warning('The MATLAB Parallel Toolbox does not seem to be installed. Activating compatibility functions.');
  addpath(fullfile(root, 'matlab', 'compatibility', 'parallel'));
end