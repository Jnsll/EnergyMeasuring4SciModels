%% TestScript.m

close all;                          % close all figures
clear;                              % clear all variables
clc;                                % clear the command terminal

%% Axis-angle to rotation matrix

axis = [1 2 3];
axis = axis / norm(axis);
angle = pi/2;

R = axisAngle2rotMat(axis, angle);
num = ' % 1.5f';
a = sprintf('\rAxis-angle to rotation matrix:');
disp([a, sprintf([repmat(['\r', num, '\t', num, '\t', num], 1, 3)], R')]);

%% Axis-angle to quaternion

q = axisAngle2quatern(axis, angle);
a = sprintf('\rAxis-angle to quaternion:');
disp([a, sprintf(['\r', num, '\t', num, '\t', num, '\t', num], q)]);

%% Quaternion to rotation matrix

R = quatern2rotMat(q);
a = sprintf('\rQuaternion to rotation matrix:');
disp([a, sprintf([repmat(['\r', num, '\t', num, '\t', num], 1, 3)], R')]);

%% Rotation matrix to quaternion

q = rotMat2quatern(R);
a = sprintf('\rRotation matrix to quaternion:');
disp([a, sprintf(['\r', num, '\t', num, '\t', num, '\t', num], q)]);

%% Rotation matrix to ZYX Euler angles

euler = rotMat2euler(R);
a = sprintf('\rRotation matrix to ZYX Euler angles:');
disp([a, sprintf(['\r', num, '\t', num, '\t', num], euler)]);

%% Quaternion to ZYX Euler angles

euler = quatern2euler(q);
a = sprintf('\rQuaternion to ZYX Euler angles:');
disp([a, sprintf(['\r', num, '\t', num, '\t', num], euler)]);

%% ZYX Euler angles to rotation matrix

R = euler2rotMat(euler(1), euler(2), euler(3));
a = sprintf('\rZYX Euler angles to rotation matrix:');
disp([a, sprintf([repmat(['\r', num, '\t', num, '\t', num], 1, 3)], R')]);

%% End of file