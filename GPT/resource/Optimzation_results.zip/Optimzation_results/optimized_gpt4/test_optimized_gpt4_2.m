%% LVQ Neural Network Prediction - Face Recognition
%
% <html>
% <table border="0" width="600px" id="table1">	
% <tr>		
% <td><b><font size="2">Author's Declaration:</font></b></td>	
% </tr>	
% <tr>		
% <td><span class="comment"><font size="2">1: I am stationed at this <a target="_blank" href="http://www.ilovematlab.cn/forum-158-1.html"><font color="#0000FF">section</font></a> for a long time, and I will answer questions about <a target="_blank" href="http://www.ilovematlab.cn/thread-49221-1-1.html"><font color="#0000FF">this case</font></a>.</font></span></td>
% </tr>
% <tr>
% <td><span class="comment"><font size="2">2: This case has supporting teaching videos and complete runnable Matlab programs.</font></span></td>	
% </tr>	
% <tr>		
% <td><span class="comment"><font size="2">3: The following content is part of this case (about 1/10 of the full content).</font></span></td>	
% </tr>		
% <tr>		
% <td><span class="comment"><font size="2">4: This case is an original case. Please indicate the source when reprinting (<a target="_blank" href="http://www.ilovematlab.cn/">Matlab Chinese Forum</a>, <a target="_blank" href="http://www.ilovematlab.cn/forum-158-1.html">"30 Case Studies of Matlab Neural Networks"</a>).</font></span></td>	
% </tr>		
% <tr>		
% <td><span class="comment"><font size="2">5: If this case happens to be related to your research, we welcome your comments and requests, which we can consider adding to the case.</font></span></td>	
% </tr>		
% <tr>		
% <td><span class="comment"><font size="2">6: The content you see below is a draft. The actual content of the book may have slight differences and is subject to the actual published content.</font></span></td>	
% </tr>
% <tr>		
% <td><span class="comment"><font size="2">7: For other common questions, ordering methods, etc., <a target="_blank" href="http://www.ilovematlab.cn/thread-47939-1-1.html">please click here</a>.</font></span></td>	
% </tr>
% </table>
% </html>
%
web browser http://www.ilovematlab.cn/thread-61927-1-1.html
%% Clear Environment Variables
clear;
clc;
%% Face Feature Vector Extraction 
% Number of people
M = 10;
% Number of face orientation categories
N = 5; 
% Feature vector extraction
pixel_value = feature_extraction(M, N);
%% Generate Training/Test Sets
% Generate random sequence of image indices
rand_label = randperm(M * N);  
% Face orientation labels
direction_label = repmat(1:N, 1, M);
% Training set
train_label = rand_label(1:30);
P_train = pixel_value(train_label, :)';
Tc_train = direction_label(train_label);
% Test set
test_label = rand_label(31:end);
P_test = pixel_value(test_label, :)';
Tc_test = direction_label(test_label);
%% Calculate PC
rate = arrayfun(@(i) sum(Tc_train == i) / 30, 1:5, 'UniformOutput', false);
%% LVQ1 Algorithm
[w1, w2] = lvq1_train(P_train, Tc_train, 20, cell2mat(rate), 0.01, 5);
result_1 = lvq_predict(P_test, Tc_test, 20, w1, w2);
%% LVQ2 Algorithm
[w1, w2] = lvq2_train(P_train, Tc_train, 20, 0.01, 5, w1, w2);
result_2 = lvq_predict(P_test, Tc_test, 20, w1, w2);

web browser http://www.ilovematlab.cn/thread-61927-1-1.html
%%
% 
% <html>
% <table align="center">
% <tr>
% <td align="center"><font size="2">All Rights Reserved:</font><a href="http://www.ilovematlab.cn/">Matlab Chinese Forum</a>&nbsp;&nbsp; <script src="http://s3.cnzz.com/stat.php?id=971931&web_id=971931&show=pic" language="JavaScript"></script>&nbsp;</td>
% </tr>
% </table>
% </html>