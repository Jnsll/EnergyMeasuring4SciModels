disp('Running: TEST_computePropOpPoint.m')

%% Define basic parameters
rho = 1.225; 
d_prop = 0.305; 
C_t = 0.0849; 
C_q = 0.0111; 

%% Define RPMs for tests
RPM_values = {0, 1000, [1000 2000 3000]};
test_descriptions = {'Test 1 - RPM = 0', 'Test 2 - RPM = 1000', 'Test 3 - RPM = [1000 2000 3000]'};

%% Loop through each test case
for i = 1:length(RPM_values)
    disp(test_descriptions{i});
    RPM = RPM_values{i};
    [thrust, torque] = computePropOpPoint(RPM, rho, d_prop, C_t, C_q);
end

disp('TEST_computePropOpPoint.m ran without error')