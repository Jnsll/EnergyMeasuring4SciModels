clear all; close all;
I = imread('cameraman.tif');
I = im2double(I);
[m, n] = size(I);
M = 2 * m; n = 2 * n;
u = -m/2 : m/2 - 1;
v = -n/2 : n/2 - 1;
[U, V] = meshgrid(u, v);
D = sqrt(U.^2 + V.^2);
D0 = 130;
H = exp(-(D.^2) / (2 * (D0^2)));

% Precompute noise matrix
N = 0.01 * ones(m, n);
N = imnoise(N, 'gaussian', 0, 0.001);

% Use fft2 and ifft2 instead of fftfilter function
I_fft = fft2(I);
H_fft = fft2(H, m, n);
J = ifft2(I_fft .* H_fft) + N;

figure;
subplot(121); imshow(I);
subplot(122); imshow(J, []);

% Precompute inverse filter masks
HC1 = zeros(m, n);
M1 = H > 0.1;
HC1(M1) = 1 ./ H(M1);
K = ifft2(fft2(J) .* fft2(HC1, m, n));

HC2 = zeros(m, n);
M2 = H > 0.01;
HC2(M2) = 1 ./ H(M2);
L = ifft2(fft2(J) .* fft2(HC2, m, n));

figure;
subplot(121); imshow(K, []);
subplot(122); imshow(L, []);