clear;  % Clear workspace
clc;    % Clear command window

% Read images
B = imread('girl2.bmp');					
C = imread('boy1.bmp');

% Perform face detection
BW1 = refine_face_detection(B);				
BW2 = refine_face_detection(C);

% Set default figure properties
set(groot, 'defaultFigurePosition', [100, 100, 1200, 450]); 
set(groot, 'defaultFigureColor', [1 1 1]);

% Display results
figure;
subplot(1, 2, 1), imshow(BW1);                       
subplot(1, 2, 2), imshow(BW2);