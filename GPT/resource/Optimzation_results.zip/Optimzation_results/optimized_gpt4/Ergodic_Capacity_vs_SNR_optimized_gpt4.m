% Optimized_Ergodic_Capacity_vs_SNR.m
clear all;
close all;
SNR_dB = 0:5:20; 
SNR_linear = 10.^(SNR_dB / 10);
N_iter = 1000;
nT_vals = [1, 1, 2, 4, 4];
nR_vals = [1, 2, 1, 2, 4];

C = zeros(5, length(SNR_dB));

for Icase = 1:5
    nT = nT_vals(Icase);
    nR = nR_vals(Icase);
    n = min(nT, nR);
    I = eye(n);
    
    for iter = 1:N_iter
        H = sqrt(0.5) * (randn(nR, nT) + 1i * randn(nR, nT));
        HH = H' * H if nR >= nT else H * H';
        
        for i = 1:length(SNR_dB)
            C(Icase, i) = C(Icase, i) + log2(real(det(I + SNR_linear(i) / nT * HH)));
        end
    end
end

C = C / N_iter;

figure
plot(SNR_dB, C(1, :), 'b-o', SNR_dB, C(2, :), 'b-<', SNR_dB, C(3, :), 'b-s', SNR_dB, C(4, :), 'b->', SNR_dB, C(5, :), 'b-^');
xlabel('SNR[dB]');
ylabel('bps/Hz');
set(gca, 'fontsize', 10);
grid on

s1 = '{\it N_T}=1,{\it N_R}=1';
s2 = '{\it N_T}=1,{\it N_R}=2';
s3 = '{\it N_T}=2,{\it N_R}=1';
s4 = '{\it N_T}=2,{\it N_R}=2';
s5 = '{\it N_T}=4,{\it N_R}=4';
legend(s1, s2, s3, s4, s5);
title('δ֪CSIʱ��MIMO�ŵ���������');