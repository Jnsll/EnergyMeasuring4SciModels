clear;
clc;

% Parameters
popsize = 100;
chromlength = 10;
pc = 0.6;
pm = 0.001;

% Initialize population
pop = initpop(popsize, chromlength);  % 100 * 10 population size

% Precompute the number of iterations
num_iterations = 100;
plot_interval = 25;

% Preallocate arrays for performance
bestindividual = zeros(1, chromlength);
bestfit = -Inf;
x2 = 0;

% Main loop
for i = 1:num_iterations
    % Calculate fitness values
    objvalue = cal_objvalue(pop);
    fitvalue = objvalue;

    % Selection
    newpop = selection(pop, fitvalue);

    % Crossover
    newpop = crossover(newpop, pc);

    % Mutation
    newpop = mutation(newpop, pm);

    % Update population
    pop = newpop;

    % Find the best individual
    [current_bestindividual, current_bestfit] = best(pop, fitvalue);
    if current_bestfit > bestfit
        bestfit = current_bestfit;
        bestindividual = current_bestindividual;
        x2 = binary2decimal(bestindividual);
    end

    % Plotting
    if mod(i, plot_interval) == 0
        subplot(2, 2, i / plot_interval);
        fplot(@(x) 10 * sin(5 * x) + 7 * abs(x - 5) + 10, [0 10]);
        hold on;
        x1 = binary2decimal(newpop);
        y1 = cal_objvalue(newpop);
        plot(x1, y1, '*');
        title(['Iteration n=' num2str(i)]);
    end
end

fprintf('The best X is --->>%5.2f\n', x2);
fprintf('The best Y is --->>%5.2f\n', bestfit);