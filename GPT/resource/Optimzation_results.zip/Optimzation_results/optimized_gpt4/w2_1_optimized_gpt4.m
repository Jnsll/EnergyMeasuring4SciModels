function optimized_code
    % Define constants
    w = 2.5;
    h = 67;
    a = 1;
    W = 80;
    lamda = 1.5;
    r = sqrt(40*40 + w*w);
    x = (2.5:2.5:40)';

    % Initial guess, bounds
    ts0 = [pi/4, h/2];
    lb = [0, 0];
    ub = [pi/2, h];

    % Optimize using fmincon
    options = optimoptions('fmincon', 'Display', 'off');
    ts = fmincon(@objfun, ts0, [], [], [], [], lb, ub, @confun, options);
end

function f = objfun(ts)
    % Objective function definition (dummy implementation)
    % Replace with the actual function logic
    f = sum(ts); % Example placeholder
end

function [c, ceq] = confun(ts)
    % Constraint function definition (dummy implementation)
    % Replace with the actual function logic
    c = []; % Example placeholder
    ceq = []; % Example placeholder
end