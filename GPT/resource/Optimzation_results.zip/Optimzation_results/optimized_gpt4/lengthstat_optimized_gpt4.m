function lengthstat()
    num_iterations = 1000;
    [count, mat] = lengthplot(850, 1370, 1500);
    for i = 1:num_iterations
        [count, temp] = lengthplot(850, 1370, 1500);
        mat = mat + temp;
    end
    mat = mat / num_iterations;
    plot(1:850, mat);
end