% Generate some test data. Assume that the X-axis represents months.
x = 1:12;
y = 10 * rand(1, length(x));

% Plot the data.
h = plot(x, y, '+');

% Add a title.
title('This is a title');

% Set the X-Tick locations so that every other month is labeled.
Xt = 1:2:12;  % Adjusted to include the last month
set(gca, 'XTick', Xt, 'XLim', [1 12]);

% Add the months as tick labels.
months = {'Jan', 'Mar', 'May', 'Jul', 'Sep', 'Nov'};  % Directly use cell array of strings

set(gca, 'XTickLabel', months, 'XTickLabelRotation', 90);  % Use gca for setting XTickLabel and rotation

% Removed the unnecessary conditional block