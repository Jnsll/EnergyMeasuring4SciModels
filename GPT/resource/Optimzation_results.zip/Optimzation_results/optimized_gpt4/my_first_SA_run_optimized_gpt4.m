clear
clc

ObjectiveFunction = @my_first_SA;   % Function handle to the objective function
X0 = [2.5 2.5];   % Starting point
lb = [-5 -5];     % Lower bound
ub = [5 5];       % Upper bound

% Optimized options for energy efficiency
options = saoptimset('MaxIter',300,'StallIterLim',200,'TolFun',1e-6,'AnnealingFcn',@annealingfast,'InitialTemperature',50,'TemperatureFcn',@temperatureexp,'ReannealInterval',100,'PlotFcns',{@saplotbestx, @saplotbestf});

[x,fval] = simulannealbnd(ObjectiveFunction,X0,lb,ub,options);