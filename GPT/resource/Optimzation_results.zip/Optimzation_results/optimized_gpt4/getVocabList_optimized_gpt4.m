function vocabList = getVocabList()
%GETVOCABLIST reads the fixed vocabulary list in vocab.txt and returns a
%cell array of the words
%   vocabList = GETVOCABLIST() reads the fixed vocabulary list in vocab.txt 
%   and returns a cell array of the words in vocabList.

%% Read the fixed vocabulary list
fid = fopen('vocab.txt');

% Store all dictionary words in cell array vocab{}
n = 1899;  % Total number of words in the dictionary

% Preallocate cell array for better performance
vocabList = cell(n, 1);

% Read the entire file content at once
fileContent = textscan(fid, '%d %s', 'Delimiter', '\n');
fclose(fid);

% Extract and store words in vocabList
vocabList = fileContent{2};

end