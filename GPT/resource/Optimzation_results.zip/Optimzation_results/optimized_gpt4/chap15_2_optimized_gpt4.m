close all; % Close all current figure windows
clear; % Clear workspace variables
clc; % Clear command window

proj1 = 90;
N1 = 128; % Input projection data size
degree1 = projdata(proj1, N1); % Call function projdata to generate projection data for head model

proj2 = 180;
N2 = 256; % Input projection data size
degree2 = projdata(proj2, N2); % Call function projdata to generate projection data for head model

set(0, 'defaultFigurePosition', [100, 100, 1200, 450]); % Modify default settings for figure position
set(0, 'defaultFigureColor', [1 1 1]); % Modify settings for figure background color

figure;
subplot(121);
pcolor(degree1); % Display 90x128 head model

subplot(122);
pcolor(degree2); % Display 180x256 head model