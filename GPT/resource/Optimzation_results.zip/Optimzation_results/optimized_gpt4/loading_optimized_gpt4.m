clearvars;
load('struct_data.mat');
load('county_data.mat');