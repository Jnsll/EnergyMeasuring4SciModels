%% Clear environment
warning off             % Disable warnings
close all               % Close all figure windows
clear                   % Clear workspace variables
clc                     % Clear command window

%% Import data
res = xlsread('���ݼ�.xlsx');

%% Split data into training and test sets
temp = randperm(357);

P_train = res(temp(1:240), 1:12)';
T_train = res(temp(1:240), 13)';
P_test = res(temp(241:end), 1:12)';
T_test = res(temp(241:end), 13)';

%% Normalize data
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);
t_train = T_train;
t_test = T_test;

%% Transpose data to fit model requirements
p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';

%% Create model
c = 10.0;      % Penalty factor
g = 0.01;      % RBF kernel parameter
cmd = ['-t 2 -c ', num2str(c), ' -g ', num2str(g)];
model = svmtrain(t_train, p_train, cmd);

%% Simulation tests
T_sim1 = svmpredict(t_train, p_train, model);
T_sim2 = svmpredict(t_test, p_test, model);

%% Performance evaluation
error1 = sum((T_sim1' == T_train)) / numel(T_train) * 100;
error2 = sum((T_sim2' == T_test)) / numel(T_test) * 100;

%% Sort data for plotting
[~, index_1] = sort(T_train);
[~, index_2] = sort(T_test);

T_train_sorted = T_train(index_1);
T_test_sorted = T_test(index_2);
T_sim1_sorted = T_sim1(index_1);
T_sim2_sorted = T_sim2(index_2);

%% Plotting
figure
plot(1:numel(T_train), T_train_sorted, 'r-*', 1:numel(T_train), T_sim1_sorted, 'b-o', 'LineWidth', 1)
legend('True Values', 'Predicted Values')
xlabel('Prediction Samples')
ylabel('Prediction Results')
title({'Comparison of Training Set Predictions'; ['Accuracy = ' num2str(error1) '%']})
grid on

figure
plot(1:numel(T_test), T_test_sorted, 'r-*', 1:numel(T_test), T_sim2_sorted, 'b-o', 'LineWidth', 1)
legend('True Values', 'Predicted Values')
xlabel('Prediction Samples')
ylabel('Prediction Results')
title({'Comparison of Test Set Predictions'; ['Accuracy = ' num2str(error2) '%']})
grid on

%% Confusion matrix
figure
cm = confusionchart(T_train_sorted, T_sim1_sorted);
cm.Title = 'Confusion Matrix for Train Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';

figure
cm = confusionchart(T_test_sorted, T_sim2_sorted);
cm.Title = 'Confusion Matrix for Test Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';