clear;
clc;

% Define ranges
x_range = [-40, 40];
y_range = [-40, 40];
range = [x_range; y_range];

% Calculate Max_V
Max_V = 0.2 * (range(:, 2) - range(:, 1));
n = 2;

% Create figure
figure('color', 'k');

% First subplot
subplot(121);
axis off;
axis([1, 10, 1, 10]);
text_positions = [0, 1; 0, 1.5; 0, 2; 0, 3];
text_strings = {'asdasd', 'asdddddd', 'asdddddd', 'asdddddd'};
text_colors = {'b', 'r', 'r', 'r'};

for i = 1:length(text_strings)
    text(text_positions(i, 1), text_positions(i, 2), text_strings{i}, 'Color', text_colors{i}, 'FontSize', 15);
end

% Second subplot
subplot(122);
axis off;
axis([1, 10, 1, 10]);
text(0, 0, 'asdasd', 'color', 'b');
text(0, 5, 'asdddddd', 'color', 'r');