clc
clear all

easy = 1; %% easy=1 用于测试：EN, SF,SD,PSNR,MSE, MI, VIF, AG, CC, SCD, Qabf等指标； easy=0 用于测试：Nabf, SSIM, MS_SSIM, FMI_pixel, FMI_dct, FMI_w等指标
dataset = 'TNO';
row_name1 = 'row1';
row_data1 = 'row2';
Method_name = 'SeAFusion';
row = 'A';
row_name = strrep(row_name1, 'row', row);
row_data = strrep(row_data1, 'row', row);
fileFolder = fullfile('../Image/Source-Image/TNO/ir'); % 源图像A所在文件夹 此处是'Evaluation\Image\Source-Image\TNO\ir'
dirOutput = dir(fullfile(fileFolder, '*.*'));
fileNames = {dirOutput.name};
ir_dir = fileFolder;
vi_dir = fullfile('../Image/Source-Image/TNO/vi'); % 源图像B所在文件夹 此处是'Evaluation\Image\Source-Image\TNO\vi'
Fused_dir = fullfile('../Image/Algorithm/SeAFusion_TNO'); % 融合结果所在文件夹 此处是 'Evaluation\Image\Algorithm\SeAFusion_TNO'

metrics = {'EN', 'SF', 'SD', 'PSNR', 'MSE', 'MI', 'VIF', 'AG', 'CC', 'SCD', 'Qabf', 'Nabf', 'SSIM', 'MS_SSIM', 'FMI_pixel', 'FMI_dct', 'FMI_w'};
metric_sets = cell(1, numel(metrics));
metric_tables = cell(1, numel(metrics));

for j = 1:numel(fileNames)
    if ismember(fileNames{j}, {'.', '..'})
        continue;
    end
    
    fileName_source_ir = fullfile(ir_dir, fileNames{j});
    fileName_source_vi = fullfile(vi_dir, fileNames{j});
    fileName_Fusion = fullfile(Fused_dir, fileNames{j});
    
    ir_image = imread(fileName_source_ir);
    vi_image = imread(fileName_source_vi);
    fused_image = imread(fileName_Fusion);
    
    if size(ir_image, 3) > 2
        ir_image = rgb2gray(ir_image);
    end
    
    if size(vi_image, 3) > 2
        vi_image = rgb2gray(vi_image);
    end
    
    if size(fused_image, 3) > 2
        fused_image = rgb2gray(fused_image);
    end
    
    if ismatrix(ir_image) && ismatrix(vi_image)
        [EN, SF, SD, PSNR, MSE, MI, VIF, AG, CC, SCD, Qabf, Nabf, SSIM, MS_SSIM, FMI_pixel, FMI_dct, FMI_w] = analysis_Reference(fused_image, ir_image, vi_image, easy);
        metric_values = {EN, SF, SD, PSNR, MSE, MI, VIF, AG, CC, SCD, Qabf, Nabf, SSIM, MS_SSIM, FMI_pixel, FMI_dct, FMI_w};
        
        for k = 1:numel(metrics)
            metric_sets{k} = [metric_sets{k}, metric_values{k}];
        end
    else
        disp('unsuccessful!');
        disp(fileName_Fusion);
    end
    
    fprintf('Fusion Method: %s, Image Name: %s\n', Method_name, fileNames{j});
end

save_dir = '../Metric'; %存放Excel结果的文件夹
if ~exist(save_dir, 'dir')
    mkdir(save_dir);
end

file_name = fullfile(save_dir, strcat('Metric_', Method_name, '.xlsx')); %存放Excel文件的文件名

if easy == 1
    easy_metrics = {'SD', 'PSNR', 'MSE', 'MI', 'VIF', 'AG', 'CC', 'SCD', 'EN', 'Qabf', 'SF'};
else
    easy_metrics = {'Nabf', 'SSIM', 'MS_SSIM', 'FMI_pixel', 'FMI_dct', 'FMI_w'};
end

method_name = cellstr(Method_name);
method_table = table(method_name);

for k = 1:numel(easy_metrics)
    metric = easy_metrics{k};
    metric_index = find(strcmp(metrics, metric));
    metric_table = table(metric_sets{metric_index}');
    metric_tables{metric_index} = metric_table;
    
    writetable(metric_table, file_name, 'Sheet', metric, 'Range', row_data);
    writetable(method_table, file_name, 'Sheet', metric, 'Range', row_name);
end