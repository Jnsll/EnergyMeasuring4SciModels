function s = path_to_eltopo()
  % PATH_TO_eltopo Returns absolute, system-dependent path to eltopo header and
  % includes
  %
  % Outputs:
  %   s  path to eltopo base directory as string
  %  
  % See also: eltopo

  if ispc
    s = 'c:/prg/lib/eltopo/';
  elseif ismac
    s = '/usr/local/eltopo';
  else
    s = ''; % Default empty string for other systems
  end

end