close all;                          % Close all current figure windows
clear;                              % Clear workspace variables
clc;                                % Clear command window

I = imread('flower.tif');           % Read the image
BW = imbinarize(I);                 % Convert image to binary using automatic thresholding
[B,L] = bwboundaries(BW,'noholes'); % Find boundaries of objects in the binary image

RGB = BW;                           % Copy binary image to RGB

set(0,'defaultFigurePosition',[100,100,1000,500]);  % Set default figure position
set(0,'defaultFigureColor',[1 1 1])                 % Set default figure background color

figure;
subplot(121); imshow(I);            % Display original image
subplot(122); imshow(RGB);          % Display binary image

hold on
for k = 1:length(B)
    boundary = B{k};
    plot(boundary(:,2), boundary(:,1), 'r', 'LineWidth', 2)  % Plot boundaries on the binary image
end