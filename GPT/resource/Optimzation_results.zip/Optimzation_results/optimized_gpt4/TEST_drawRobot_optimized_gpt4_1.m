% Optimized TEST_drawRobot.m
%
% This script is used to test the robot and understand the sign conventions
% for the angles of each link.
%

clc; clear;

% Loads the struct of physical parameters (masses, lengths, ...)
persistent p;
if isempty(p)
    p = getPhysicalParameters();
end

% Pick a test configuration
q = [-0.3, 0.7, 0.0, -0.5, -0.6];

% Draw the robot to check configuration:
figure(1); clf;
drawRobot(q, p);