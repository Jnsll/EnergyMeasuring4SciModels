%%%%%EM PLANNER初始化与配置文件，主要是加载全局路径，加载油门刹车标定表，设置一些规划和控制参数等等

%%%%加载油门刹车标定表
load('table_calibration.mat')
%%%%加载全局路径
load('global_path.mat')
vs_state = -1;
StopMode = -1;

%%%%%前轮转角与方向盘转角的映射关系
right_wheel_ground = linspace(-70, 70, 51);
rack_displacement = [-39.14, -37.2, -35.29, -33.43, -31.6, -29.81, -28.06, -26.34, -24.66, ...
    -23.01, -21.38, -19.79, -18.23, -16.69, -15.18, -13.7, -12.23, -10.8, -9.38, -7.98, ...
    -6.61, -5.25, -3.91, -2.59, -1.29, 0, 1.27, 2.54, 3.78, 5.02, 6.24, 7.46, 8.66, ...
    9.86, 11.05, 12.24, 13.41, 14.59, 15.76, 16.92, 18.09, 19.25, 20.42, 21.59, 22.76, ...
    23.93, 25.11, 26.3, 27.5, 28.71, 29.94];

% 转向系统C特性
c_factor = 43.75; %% 单位: mm/rev

%%%% 参数设置 %%%%%
DEG2RAD = pi/180;
RAD2DEG = 180/pi;

%%%% 整车参数 %%%%%
cf = -175016;
cr = -130634;
m = 2020;
Iz = 4095.0;
la = 1.265;
lb = 2.947 - 1.265;

%%%%%%% 横向LQR参数 %%%%%%%
LQR_Q = diag([25, 3, 10, 4]);
LQR_R = 15;

%%%% 纵向双PID参数 %%%%
KP_PID_distance = 0.5;
KI_PID_distance = 0.0;
KD_PID_distance = 0.0;
KP_PID_speed = 1.8;
KI_PID_speed = 0;
KD_PID_speed = 0;

%%%%% LQR_OFFLINE %%%%%
vx_break_point = 0.01 * (1:5000);
k = zeros(5000, 4);

for i = 1:5000
    vx = vx_break_point(i);
    A = [0, 1, 0, 0;
         0, (cf + cr) / (m * vx), -(cf + cr) / m, (la * cf - lb * cr) / (m * vx);
         0, 0, 0, 1;
         0, (la * cf - lb * cr) / (Iz * vx), -(la * cf - lb * cr) / Iz, (la^2 * cf + lb^2 * cr) / (Iz * vx)];
    B = [0;
         -cf / m;
         0;
         -la * cf / Iz];
    k(i, :) = lqr(A, B, LQR_Q, LQR_R);
end

LQR_K1 = k(:, 1)';
LQR_K2 = k(:, 2)';
LQR_K3 = k(:, 3)';
LQR_K4 = k(:, 4)';

%%%% 车辆初始位置 %%%%
host_x_init = 0; 
host_y_init = 0;