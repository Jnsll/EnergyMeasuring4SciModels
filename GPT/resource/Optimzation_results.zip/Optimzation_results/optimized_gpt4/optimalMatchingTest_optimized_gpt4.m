% Consider matching sources to detections

%  s1 d2  
%         s2 d3
%  d1

% sources(:,i) = [x y] coords
sources = [0.1 0.7; 0.6 0.4]';
detections = [0.2 0.2; 0.2 0.8; 0.7 0.1]';

% Compute squared distance matrix
dst = sqdist(sources, detections);

% Optimal matching for sources to detections
a1 = optimalMatching(dst);

% Optimal matching for detections to sources
a2 = optimalMatching(dst');

% Display results
disp(['Matching sources to detections: ', mat2str(a1)]);
disp(['Matching detections to sources: ', mat2str(a2)]);

% Function for computing squared distances
function d = sqdist(A, B)
    % Efficient computation of squared Euclidean distance
    d = bsxfun(@plus, dot(A, A, 1)', dot(B, B, 1)) - 2 * (A' * B);
end

% Function for optimal matching (assuming it exists)
function match = optimalMatching(costMatrix)
    % Placeholder for optimal matching algorithm
    % This function should implement the optimal assignment algorithm
    % such as the Hungarian algorithm for the given cost matrix.
    match = munkres(costMatrix); % Using munkres as an example
end