clear
a1 = imread('000.bmp');
[m, n] = size(a1);
num_images = 11 * 19;
a = zeros(m, n, num_images);

% Preallocate image names
imageNames = strings(num_images, 1);

for i = 0:num_images-1
    if i < 10
        imageNames(i+1) = strcat('0','0',int2str(i),'.bmp');
    elseif i < 100
        imageNames(i+1) = strcat('0',num2str(i),'.bmp');
    else
        imageNames(i+1) = strcat(num2str(i),'.bmp');
    end
end

% Read all images in one go
parfor i = 1:num_images
    a(:,:,i) = imread(imageNames(i));
end

d = zeros(num_images, num_images);

% Vectorize the distance calculation
for i = 1:num_images
    for j = 1:num_images
        if i ~= j
            s = abs(a(:,n,i) - a(:,1,j));
            d(i,j) = sum(s(:));
        end
    end
end

tou1 = zeros(num_images, 1);

% Vectorize the column check
for i = 1:num_images
    s = all(a(:,n-11:n,i) == 255, 2);
    tou1(i) = sum(s);
end

s = (tou1 == 180);
sum(s)
ind = find(s == 1)