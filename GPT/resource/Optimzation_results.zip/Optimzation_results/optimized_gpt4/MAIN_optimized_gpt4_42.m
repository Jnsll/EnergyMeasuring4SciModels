% MAIN - Pendulum
%
% Demonstrates simple swing-up for a single pendulum with a torque motor.
% This is an easy problem, used for demonstrating how to use analytic
% gradients with optimTraj.
%

clc; clear;
addpath ../../

% Physical parameters of the pendulum
p.k = 1;  % Normalized gravity constant
p.c = 0.1;  % Normalized damping constant

% User-defined dynamics and objective functions
problem.func.dynamics = @(t,x,u) dynamics(x,u,p);
problem.func.pathObj = @(t,x,u) pathObjective(u);

% Problem bounds
problem.bounds.initialTime.low = 0;
problem.bounds.initialTime.upp = 0;
problem.bounds.finalTime.low = 0.5;
problem.bounds.finalTime.upp = 2.5;

problem.bounds.state.low = [-2*pi; -inf];
problem.bounds.state.upp = [2*pi; inf];
problem.bounds.initialState.low = [0;0];
problem.bounds.initialState.upp = [0;0];
problem.bounds.finalState.low = [pi;0];
problem.bounds.finalState.upp = [pi;0];

problem.bounds.control.low = -5; %-inf;
problem.bounds.control.upp = 5; %inf;

% Guess at the initial trajectory
problem.guess.time = [0,1];
problem.guess.state = [0, pi; pi, pi];
problem.guess.control = [0, 0];

% Switch between a variety of methods
method = 'trapGrad';  

% Method-independent options:
nlpOpt1 = optimset('Display','iter', 'TolFun',1e-3, 'MaxFunEvals',1e4);
nlpOpt2 = optimset('Display','iter', 'TolFun',1e-6, 'MaxFunEvals',5e4);

switch method
    case 'trapezoid'
        problem.options = struct('method', 'trapezoid', 'trapezoid', struct('nGrid', 10), 'nlpOpt', nlpOpt1);
        problem.options(2) = struct('method', 'trapezoid', 'trapezoid', struct('nGrid', 25), 'nlpOpt', nlpOpt2);
        
    case 'trapGrad'
        nlpOpt1.GradConstr = 'on';
        nlpOpt1.GradObj = 'on';
        nlpOpt1.DerivativeCheck = 'off';
        nlpOpt2.GradConstr = 'on';
        nlpOpt2.GradObj = 'on';
        
        problem.options = struct('method', 'trapezoid', 'trapezoid', struct('nGrid', 10), 'nlpOpt', nlpOpt1);
        problem.options(2) = struct('method', 'trapezoid', 'trapezoid', struct('nGrid', 45), 'nlpOpt', nlpOpt2);
        
    case 'hermiteSimpson'
        problem.options = struct('method', 'hermiteSimpson', 'hermiteSimpson', struct('nSegment', 6), 'nlpOpt', nlpOpt1);
        problem.options(2) = struct('method', 'hermiteSimpson', 'hermiteSimpson', struct('nSegment', 15), 'nlpOpt', nlpOpt2);
        
    case 'hermiteSimpsonGrad'
        nlpOpt1.GradConstr = 'on';
        nlpOpt1.GradObj = 'on';
        nlpOpt1.DerivativeCheck = 'off';
        nlpOpt2.GradConstr = 'on';
        nlpOpt2.GradObj = 'on';
        
        problem.options = struct('method', 'hermiteSimpson', 'hermiteSimpson', struct('nSegment', 6), 'nlpOpt', nlpOpt1);
        problem.options(2) = struct('method', 'hermiteSimpson', 'hermiteSimpson', struct('nSegment', 15), 'nlpOpt', nlpOpt2);
        
    case 'chebyshev'
        problem.options = struct('method', 'chebyshev', 'chebyshev', struct('nColPts', 9), 'nlpOpt', nlpOpt1);
        problem.options(2) = struct('method', 'chebyshev', 'chebyshev', struct('nColPts', 15), 'nlpOpt', nlpOpt2);
        
    case 'multiCheb'
        problem.options = struct('method', 'multiCheb', 'multiCheb', struct('nColPts', 6, 'nSegment', 4), 'nlpOpt', nlpOpt1);
        problem.options(2) = struct('method', 'multiCheb', 'multiCheb', struct('nColPts', 9, 'nSegment', 4), 'nlpOpt', nlpOpt2);
        
    case 'rungeKutta'
        problem.options = struct('method', 'rungeKutta', 'defaultAccuracy', 'low', 'nlpOpt', nlpOpt1);
        problem.options(2) = struct('method', 'rungeKutta', 'defaultAccuracy', 'medium', 'nlpOpt', nlpOpt2);
    
    case 'rungeKuttaGrad'
        nlpOpt1.GradConstr = 'on';
        nlpOpt1.GradObj = 'on';
        nlpOpt1.DerivativeCheck = 'off';
        nlpOpt2.GradConstr = 'on';
        nlpOpt2.GradObj = 'on';
        
        problem.options = struct('method', 'rungeKutta', 'defaultAccuracy', 'low', 'nlpOpt', nlpOpt1);
        problem.options(2) = struct('method', 'rungeKutta', 'defaultAccuracy', 'medium', 'nlpOpt', nlpOpt2);
        
    case 'gpops'
        problem.options = struct('method', 'gpops', 'defaultAccuracy', 'high', 'gpops', struct('nlp', struct('solver', 'snopt')));
        
    otherwise
        error('Invalid method!');
end

% Solve the problem
soln = optimTraj(problem);
t = soln(end).grid.time;
q = soln(end).grid.state(1,:);
dq = soln(end).grid.state(2,:);
u = soln(end).grid.control;

% Plot the solution:
figure(1); clf;

subplot(3,1,1)
plot(t,q)
ylabel('q')
title('Single Pendulum Swing-Up');

subplot(3,1,2)
plot(t,dq)
ylabel('dq')

subplot(3,1,3)
plot(t,u)
ylabel('u')

% Plot the sparsity pattern
if isfield(soln(1).info,'sparsityPattern')
   figure(3); clf;
   spy(soln(1).info.sparsityPattern.equalityConstraint);
   axis equal
   title('Sparsity pattern in equality constraints')
end