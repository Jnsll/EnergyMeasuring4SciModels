clear; clc;

% Read data from Excel files
fushe = xlsread('cumcm.xls', 'sheet', 'E4:L8763');
dianban = xlsread('cumcm.xls', 'sheet1', 'B1:F24');

% Precompute constants
thta = 33 / 57.3;
sa = sin(thta);
ca = cos(thta);
p0 = 80; % Minimum intensity threshold
P = 295; % Rated power of the component

% Compute tz_zs, nx_zs, and fushe_renyi
tz_zs = fushe(:, 1) - fushe(:, 2);
nx_zs = fushe(:, 5) - 0.5 * fushe(:, 2);
fushe_renyi = tz_zs * ca + nx_zs * sa + fushe(:, 2) * (pi - thta) / pi;

% Apply intensity threshold and scaling
fushe(fushe < p0) = 0; % Set values below p0 to 0
fushe(fushe < 200) = fushe(fushe < 200) * 0.05; % Scale values below 200

% Calculate total energy output
Q = sum(fushe, 'all') * P / 1000000; % Sum all values and scale by P/1000, then convert to kWh