disp('Running: TEST_plotPropLoc.m') 
figure 

%% Define test parameters
test_params = {
    {0.1, [0 0 0]', [0 0 1]'}, 
    {0.1, [0 0 0]', [0 1 0]'}, 
    {0.5, [0.5 0.5 0]', [0 0 1]'}, 
    {0.5, [0.5 0.5 1]', [0 1 1]'}
};

%% Run tests
for i = 1:length(test_params)
    d_prop = test_params{i}{1};
    location = test_params{i}{2};
    ax = test_params{i}{3};
    plotPropLoc(d_prop, location, ax);
end

disp('TEST_plotPropLoc.m ran without error')