function movieList = loadMovieList()
%LOADMOVIELIST reads the fixed movie list in movie.txt and returns a
%cell array of the words
%   movieList = LOADMOVIELIST() reads the fixed movie list in movie.txt 
%   and returns a cell array of the words in movieList.

% Read the fixed movie list
fid = fopen('movie_ids.txt');

% Ensure the file opened successfully
if fid == -1
    error('Could not open the file movie_ids.txt');
end

% Initialize an empty cell array
movieList = {};

% Read each line and store in the cell array
while ~feof(fid)
    line = fgetl(fid);
    if ischar(line)
        % Extract the movie name
        [~, movieName] = strtok(line, ' ');
        % Store the trimmed movie name
        movieList{end+1} = strtrim(movieName);
    end
end

fclose(fid);

end