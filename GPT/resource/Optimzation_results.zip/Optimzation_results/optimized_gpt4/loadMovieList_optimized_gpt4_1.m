function movieList = loadMovieList()
%LOADMOVIELIST reads the fixed movie list in movie.txt and returns a
%cell array of the words
%   movieList = LOADMOVIELIST() reads the fixed movie list in movie.txt 
%   and returns a cell array of the words in movieList.

%% Read the fixed movie list
fid = fopen('movie_ids.txt');

% Store all movies in cell array movieList
movieList = textscan(fid, '%*d %s', 'Delimiter', '\n');
movieList = movieList{1};

fclose(fid);

end