function [env, versionString] = getEnvironment()
% Determine environment (Octave, MATLAB) and version string
% TODO: Unify private `getEnvironment` functions
    persistent cache_env cache_versionString

    if isempty(cache_env)
        if exist('OCTAVE_VERSION', 'builtin') ~= 0
            cache_env = 'Octave';
            cache_versionString = OCTAVE_VERSION;
        else
            cache_env = 'MATLAB';
            vData = ver('MATLAB');
            cache_versionString = vData.Version;
        end
    end
    
    env = cache_env;
    versionString = cache_versionString;
end