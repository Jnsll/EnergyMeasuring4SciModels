clear; clc;

% Load data from Excel sheets
fushe = xlsread('cumcm.xls', 'sheet', 'E4:M8763');
dianban = xlsread('cumcm.xls', 'sheet1', 'B1:F24');

% Precompute constants
thta = 59.76 / 57.3;
sa = sin(thta);
ca = cos(thta);
P = 52.5;  % Component rated power
p0 = 30;   % Minimum intensity, 80 for monocrystalline silicon, 30 for thin film

% Compute tz_zs and fushe_renyi
tz_zs = fushe(:, 1) - fushe(:, 2);
fushe_renyi = tz_zs * ca + fushe(:, 2) * (pi - thta) / pi;

% Apply threshold to fushe matrix
fushe(fushe < p0) = 0;

% Calculate total energy output
Q = sum(fushe(:) * P / 1000) / 1000;