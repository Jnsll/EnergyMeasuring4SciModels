function [env, versionString] = getEnvironment()
% Determine environment (Octave, MATLAB) and version string
% TODO: Unify private `getEnvironment` functions
    persistent cacheEnv cacheVersionString

    if isempty(cacheEnv)
        if exist('OCTAVE_VERSION', 'builtin') ~= 0
            cacheEnv = 'Octave';
            cacheVersionString = OCTAVE_VERSION;
        else
            cacheEnv = 'MATLAB';
            vData = ver('MATLAB');
            cacheVersionString = vData.Version;
        end
    end

    env = cacheEnv;
    versionString = cacheVersionString;
end