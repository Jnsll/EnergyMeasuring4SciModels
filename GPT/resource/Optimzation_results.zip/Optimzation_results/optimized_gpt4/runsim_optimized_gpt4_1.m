close all;
clear all;
clc;
addpath(genpath('./'));

%% Plan paths
maps = {'maps/map1.txt', 'maps/map3.txt'};
map_params = {[0.1, 2, 0.25], [0.2, 0.5, 0.25]};
starts = {[0.0, -4.9, 0.2], [0.0, 5, 5.0]};
stops = {[6.0, 18.0-1, 5.0], [20, 5, 5]};
num_maps = length(maps);

for i = 1:num_maps
    disp(['Planning for map ', num2str(i), '...']);
    map = load_map(maps{i}, map_params{i}{:});
    start = starts(i);
    stop = stops(i);
    nquad = length(start);
    for qn = 1:nquad
        tic
        path{qn} = dijkstra(map, start{qn}, stop{qn}, true);
        toc
    end
    if nquad == 1
        plot_path(map, path{1});
    else
        % you could modify your plot_path to handle cell input for multiple robots
    end
end

%% Additional init script
init_script;

%% Run trajectory
trajectory = test_trajectory(start, stop, map, path, true); % with visualization