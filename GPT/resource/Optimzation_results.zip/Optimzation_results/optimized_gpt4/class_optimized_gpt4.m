```matlab
clear;
% b33=[55 90 100 115 137 144 147 213 215 223 233 245 288 293 298 300 315 375 382 396 409 10]; %�Ҷ�
b33 = [4 6 14 24 36 79 84 89 91 106 166 173 187 200 219 264 299 309 324 346 353 356]; %���

a1 = imread('000a.bmp');
b = 0:208;
[m, n] = size(a1);
N = numel(b);
a = zeros(m, n, N * 2);

% ��ȡa��b��
for i = 1:N
    if b(i) < 10
        imageName = sprintf('00%da.bmp', b(i));
    elseif b(i) < 100
        imageName = sprintf('0%da.bmp', b(i));
    else
        imageName = sprintf('%da.bmp', b(i));
    end
    a(:, :, i) = imread(imageName);

    if b(i) < 10
        imageName = sprintf('00%db.bmp', b(i));
    elseif b(i) < 100
        imageName = sprintf('0%db.bmp', b(i));
    else
        imageName = sprintf('%db.bmp', b(i));
    end
    a(:, :, i + N) = imread(imageName);
end

% ͼ����������
t = zeros(m, 2 * 11 * 19);
for i = 1:2 * 11 * 19
    t(:, i) = sum(a(:, :, i) == 0, 2);
end
dt = diff(t);
[ma, ind] = max(dt);

% �ҳ�����
t = zeros(m, 2 * 11 * 19);
ae = zeros(m, n, 2 * 11 * 19);
for i = 1:2 * 11 * 19
    for j = 1:m
        t(j, i) = sum(a(j, :, i) == 255);
        ae(j, :, i) = a(j, :, i) == 255;
    end
end
dt = diff(t);
[u3, r3] = sort(dt);
[ma, ind] = max(dt);

% ����հ�
N = 63;
ind = ind + 1;
for i = 1:2 * 11 * 19
    z = fix(ind(i) / N);
    ind(i) = ind(i) - z * N;
    if ind(i) <= N / 3
        t(1:ind(i), i) = 0;
        for k = 0:1
            t(ind(i) + k * N:ind(i) + k * N + N / 3, i) = 1;
            t(ind(i) + k * N + N / 3:ind(i) + k * N + N, i) = 0;
        end
        t(ind(i) + 2 * N:ind(i) + 2 * N + N / 3, i) = 1;
        t(ind(i) + 2 * N + N / 3:180, i) = 0;
    elseif ind(i) > N / 3 && ind(i) <= 2 * N / 3
        t(1:ind(i), i) = 0;
        for k = 0:1
            t(ind(i) + k * N:ind(i) + k * N + N / 3, i) = 1;
            t(ind(i) + k * N + N / 3:ind(i) + k * N + N, i) = 0;
        end
        if ind(i) + 2 * N + N / 3 > 180
            t(ind(i) + 2 * N:180, i) = 1;
        else
            t(ind(i) + 2 * N:ind(i) + 2 * N + N / 3, i) = 1;
            t(ind(i) + 2 * N + N / 3:180, i) = 0;
        end
    elseif ind(i) > 2 * N / 3 && ind(i) < N
        t(ind(i) - 2 * N / 3:ind(i), i) = 0;
        t(1:ind(i) - 2 * N / 3, i) = 1;
        for k = 0:1
            t(ind(i) + k * N:ind(i) + k * N + N / 3, i) = 1;
            t(ind(i) + k * N + N / 3:ind(i) + k * N + N, i) = 0;
        end
        if ind(i) + k * N + N < 180
            t(ind(i) + k * N:ind(i) + k * N + N / 3, i) = 1;
            t(ind(i) + k * N + N / 3:ind(i) + k * N + N, i) = 0;
            t(ind(i) + k * N + N:180, i) = 1;
        else
            t(ind(i) + k * N:ind(i) + k * N + N / 3, i) = 1;
            t(ind(i) + k * N + N / 3:180, i) = 0;
        end
    end
end

% ��ƥ�������ÿ��
s3 = zeros(2 * 11 * 19, 2 * 11);
for k = 1:2 * 11
    for i = 1:2 * 11 * 19
        if b33(k) <= 209 && i <= 209