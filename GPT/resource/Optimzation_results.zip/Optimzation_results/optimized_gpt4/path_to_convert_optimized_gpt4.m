function s = path_to_convert()
  % PATH_TO_CONVERT
  %
  % s = path_to_convert()
  %
  % Outputs:
  %   s path to convert executable
  %
  % See also: path_to_qslim
  %

  persistent cached_path;
  
  if isempty(cached_path)
    if ispc
      % replace this with path
      cached_path = 'c:/prg/lib/convert/Release/convert.exe';
    elseif isunix || ismac
      [status, cached_path] = system('which convert');
      cached_path = strtrim(cached_path);
      if status ~= 0
        guesses = { ...
          '/usr/local/bin/convert', ...
          '/opt/local/bin/convert'};
        cached_path = find_first_path(guesses);
      end
    end
  end
  
  s = cached_path;
end