% Optimized_Ergodic_Capacity_CDF.m
clear all;
close all;
figure
SNR_dB=10;  
SNR_linear=10.^(SNR_dB/10.);
N_iter=50000; 
sq2=sqrt(0.5); 
grps = {'b:', 'b-'};
nT_values = [2, 4];
nR_values = [2, 4];
CDF = zeros(2, 50);

for Icase=1:2 
   nT = nT_values(Icase);
   nR = nR_values(Icase);
   n = min(nT, nR);  
   I = eye(n);
   C = zeros(1, N_iter);
   
   for iter=1:N_iter
      H = sq2*(randn(nR,nT) + 1i*randn(nR,nT)); 
      C(iter) = log2(real(det(I + SNR_linear/nT * (H' * H))));
   end
   
   [PDF, Rate] = hist(C, 50);
   PDF = PDF / N_iter;
   CDF(Icase, :) = cumsum(PDF);
   
   plot(Rate, CDF(Icase, :), grps{Icase}); 
   hold on
end

xlabel('Rate[bps/Hz]');
ylabel('CDF');
axis([1 18 0 1]); 
grid on; 
set(gca, 'fontsize', 10); 
legend('{\it N_T}={\it N_R}=2', '{\it N_T}={\it N_R}=4');