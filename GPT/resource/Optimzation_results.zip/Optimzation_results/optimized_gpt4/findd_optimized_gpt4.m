%% ������
clear
a1 = imread('000.bmp');
[m, n] = size(a1);
numImages = 11 * 19;
a = zeros(m, n, numImages);

% Pre-generate image names
imageNames = strings(numImages, 1);
for i = 0:numImages-1
    if i < 10
        imageNames(i+1) = strcat('0', '0', int2str(i), '.bmp');
    elseif i < 100
        imageNames(i+1) = strcat('0', num2str(i), '.bmp');
    else
        imageNames(i+1) = strcat(num2str(i), '.bmp');
    end
end

% Read all images
for i = 1:numImages
    a(:, :, i) = imread(imageNames(i));
end

d = zeros(numImages, numImages);

% ����ƥ���
for i = 1:numImages
    for j = 1:numImages
        if i ~= j
            s = abs(a(:, n, i) - a(:, 1, j));
            d(i, j) = sum(s(:));
        end
    end
end

% �����Ͻ�
tou = zeros(numImages, 1);
for i = 1:numImages
    s = all(a(1:37, :, i) == 255, 1);
    tou(i) = sum(s);
end

tou1 = zeros(numImages, 1);
for i = 1:numImages
    s = all(a(:, 1:17, i) == 255, 2);
    tou1(i) = sum(s);
end

s = (tou == 72) & (tou1 == 180);
ind = find(s) - 1; % �õ���Ϊͼ�ı��