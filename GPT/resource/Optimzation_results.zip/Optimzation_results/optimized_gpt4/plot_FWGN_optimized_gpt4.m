clear;
clf;

% Constants
fm = 100;   % Maximum Doppler frequency
ts_mu = 50;
scale = 1e-6;
ts = ts_mu * scale; % Sampling time
fs = 1 / ts;  % Sampling frequency
Nd = 1e6;   % Number of samples

% To get the complex fading channel
[h, Nfft, Nifft, doppler_coeff] = FWGN_model(fm, fs, Nd);

% Plotting
time_vector = (1:Nd) * ts;
magnitude_db = 10 * log10(abs(h));

figure;
subplot(2, 1, 1);
plot(time_vector, magnitude_db);
axis([0 0.5 -30 5]);
title(sprintf('Channel modeled by Clarke/Gan with f_m=%d[Hz], T_s=%d[mus]', fm, ts_mu));
xlabel('Time [s]');
ylabel('Magnitude [dB]');

subplot(2, 2, 3);
histogram(abs(h), 50);
xlabel('Magnitude');
ylabel('Occasions');

subplot(2, 2, 4);
histogram(angle(h), 50);
xlabel('Phase [rad]');
ylabel('Occasions');