function exesuff = getexeext()
%
% exesuff=getexeext()
%
% get meshing external tool extension names for the current platform
%
% author: Qianqian Fang, <q.fang at neu.edu>
%
% output:
%     exesuff: file extension for iso2mesh tool binaries
%
% -- this function is part of iso2mesh toolbox (http://iso2mesh.sf.net)
%

% Default extension for Windows
exesuff = '.exe';

% Check for Unix systems
if isunix
    exesuff = ['.', mexext];
end

% Check for Octave mesh
if isoctavemesh
    if ispc
        exesuff = '.exe';
    elseif ismac
        if contains(computer, '86_64')
            exesuff = '.mexmaci64';
        else
            exesuff = '.mexmaci';
        end
    else
        if contains(computer, '86_64')
            exesuff = '.mexa64';
        else
            exesuff = '.mexglx';
        end
    end
end