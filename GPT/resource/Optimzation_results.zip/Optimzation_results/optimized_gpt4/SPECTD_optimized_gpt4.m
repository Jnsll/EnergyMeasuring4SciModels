% Load data
SPECT_A = load('-ascii', 'SPECT_A');
SPECT_T = load('-ascii', 'SPECT_T');

[N, m] = size(SPECT_A);

class = N;

app  = SPECT_A;
test = SPECT_T;

Napp = size(app, 2);
Ntest = size(test, 2);

unique(app(class, :));
unique(test(class, :));

ns1 = max(SPECT_A, [], 2);
ns2 = max(SPECT_T, [], 2);
ns = max(max(ns1), max(ns2));

clear SPECT_A SPECT_T ns1 ns2;

% N, ns(class), Napp, Ntest, mean(ns),