%����11-8��
I = imread('hill.jpg');
HSV = rgb2hsv(I);
Hgray = rgb2gray(HSV);

% Calculate 64-level gray co-occurrence matrix
glcms1 = graycomatrix(Hgray, 'NumLevels', 64, 'Offset', [0 1; -1 1; -1 0; -1 -1]);

% Texture feature statistics (including contrast, correlation, entropy, homogeneity, energy)
stats = graycoprops(glcms1, {'contrast', 'correlation', 'energy', 'homogeneity'});

% Extract individual GLCMs for different angles
ga1 = glcms1(:, :, 1); % 0 degrees
ga2 = glcms1(:, :, 2); % 45 degrees
ga3 = glcms1(:, :, 3); % 90 degrees
ga4 = glcms1(:, :, 4); % 135 degrees

% Calculate energy for each GLCM
energya1 = sum(ga1(:).^2);
energya2 = sum(ga2(:).^2);
energya3 = sum(ga3(:).^2);
energya4 = sum(ga4(:).^2);

% Sum up texture feature statistics
s1 = sum(stats.Contrast);
s2 = sum(stats.Correlation);
s3 = sum(stats.Energy);
s4 = sum(stats.Homogeneity);

% Calculate total energy
s5 = 0.000001 * (energya1 + energya2 + energya3 + energya4);

% Read additional images
I = imread('hill.jpg');
J = imread('sea.jpg');
K = imread('house.jpg');

% Set default figure properties
set(0, 'DefaultFigurePosition', [100, 100, 1000, 500]); % Modify default settings for figure position
set(0, 'DefaultFigureColor', [1 1 1]);

% Display images in a figure with subplots
figure;
subplot(131); imshow(I);
subplot(132); imshow(J);
subplot(133); imshow(K);