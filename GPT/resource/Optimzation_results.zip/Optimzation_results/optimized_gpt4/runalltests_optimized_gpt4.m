clc;
addpath(genpath('.'));
dirlist = dir('tests/test_*.m');
for i = 1:length(dirlist)
    name = dirlist(i).name(1:end-2);
    feval(name);
end