%% Clear Environment
warning off             % Disable warning messages
close all               % Close all figure windows
clear                   % Clear all variables
clc                     % Clear command window

%% Import Data
res = xlsread('���ݼ�.xlsx');

%% Split Training and Testing Data
temp = randperm(357);
P_train = res(temp(1:240), 1:12)';
T_train = res(temp(1:240), 13)';
P_test = res(temp(241:end), 1:12)';
T_test = res(temp(241:end), 13)';

%% Normalize Data
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

%% Transpose Data
p_train = p_train'; 
p_test = p_test';
t_train = T_train'; 
t_test = T_test';

%% PSO Options
pso_option = struct('c1', 1.5, 'c2', 1.7, 'maxgen', 100, 'sizepop', 5, ...
                    'k', 0.6, 'wV', 1, 'wP', 1, 'v', 3, ...
                    'popcmax', 100, 'popcmin', 0.1, ...
                    'popgmax', 100, 'popgmin', 0.1);

%% Extract Best Parameters c and g
[bestacc, bestc, bestg] = pso_svm_class(t_train, p_train, pso_option);

%% Build Model
cmd = ['-c ', num2str(bestc), ' -g ', num2str(bestg)];
model = svmtrain(t_train, p_train, cmd);

%% Simulation Testing
T_sim_train = svmpredict(t_train, p_train, model);
T_sim_test = svmpredict(t_test, p_test, model);

%% Sort Data
[T_train, index_train] = sort(T_train);
[T_test, index_test] = sort(T_test);
T_sim_train = T_sim_train(index_train);
T_sim_test = T_sim_test(index_test);

%% Performance Evaluation
accuracy_train = sum(T_sim_train' == T_train) / numel(T_train) * 100;
accuracy_test = sum(T_sim_test' == T_test) / numel(T_test) * 100;

%% Plot Results
figure
plot(1:numel(T_train), T_train, 'r-*', 1:numel(T_train), T_sim_train, 'b-o', 'LineWidth', 1)
legend('True Values', 'Predicted Values')
xlabel('Sample Index')
ylabel('Prediction')
title({'Training Set Prediction Comparison'; ['Accuracy = ' num2str(accuracy_train) '%']})
grid on

figure
plot(1:numel(T_test), T_test, 'r-*', 1:numel(T_test), T_sim_test, 'b-o', 'LineWidth', 1)
legend('True Values', 'Predicted Values')
xlabel('Sample Index')
ylabel('Prediction')
title({'Testing Set Prediction Comparison'; ['Accuracy = ' num2str(accuracy_test) '%']})
grid on

%% Confusion Matrix
figure
cm_train = confusionchart(T_train, T_sim_train);
cm_train.Title = 'Confusion Matrix for Training Data';
cm_train.ColumnSummary = 'column-normalized';
cm_train.RowSummary = 'row-normalized';

figure
cm_test = confusionchart(T_test, T_sim_test);
cm_test.Title = 'Confusion Matrix for Testing Data';
cm_test.ColumnSummary = 'column-normalized';
cm_test.RowSummary = 'row-normalized';