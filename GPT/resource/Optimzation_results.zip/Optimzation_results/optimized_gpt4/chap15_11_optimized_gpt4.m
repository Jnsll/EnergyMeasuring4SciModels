% Clear workspace, close all figures, and clear command window
clear;
close all;
clc;

% Define input patterns
X1 = [1 1 1 1, 1 0 0 1, 1 1 1 1, 1 0 0 1];  % Recognition pattern
X2 = [0 1 0 0, 0 1 0 0, 0 1 0 0, 0 1 0 0];
X3 = [1 1 1 1, 1 0 0 1, 1 0 0 1, 1 1 1 1];
X = [X1; X2; X3];

% Define output patterns
Y1 = [1 0 0];  % Output pattern
Y2 = [0 1 0];
Y3 = [0 0 1];
Yo = [Y1; Y2; Y3];

% Network parameters
n = 16; % Number of input layer neurons
p = 8;  % Number of hidden layer neurons
q = 3;  % Number of output neurons
k = 3;  % Number of training patterns
a1 = 0.2; % Learning rate
b1 = 0.2; % Learning rate
emax = 0.01; % Maximum error
cntmax = 100; % Maximum training iterations

% Train the network
[w, v, theta, r, t, mse] = bptrain(n, p, q, X, Yo, k, emax, cntmax, a1, b1);

% Test patterns
X4 = [1 1 1 1, 1 0 0 1, 1 1 1 1, 1 0 1 1];

% Display recognition results
disp('Recognition results for pattern X1:')
c1 = bptest(p, q, n, w, v, theta, r, X1)
disp('Recognition results for pattern X2:')
c2 = bptest(p, q, n, w, v, theta, r, X2)
disp('Recognition results for pattern X3:')
c3 = bptest(p, q, n, w, v, theta, r, X3)
disp('Recognition results for pattern X4:')
c4 = bptest(p, q, n, w, v, theta, r, X4)

% Combine results
c = [c1; c2; c3; c4];

% Post-process results
c(c > 0.5) = 1;
c(c < 0.2) = 0;

% Display final recognition results
disp('Recognition results for patterns X1~X4:')
disp(c)