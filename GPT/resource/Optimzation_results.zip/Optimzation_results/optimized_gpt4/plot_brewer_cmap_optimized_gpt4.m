function f = plot_brewer_cmap()
% Plots and identifies the various colorbrewer tables available.
% Is called by cbrewer.m when no arguments are given.
% 
% f = plot_brewer_cmap()
%
% Outputs:
%  f  handle to new figure
%
% See also: cbrewer
%
% Author: Charles Robert
% email: tannoudji@hotmail.com
% Date: 14.10.2011
%

  load('colorbrewer.mat')
  
  ctypes = {'div', 'seq', 'qual'};
  ctypes_title = {'div', 'seq', 'qual'};
  cnames = {
      {'BrBG', 'PiYG', 'PRGn', 'PuOr', 'RdBu', 'RdGy', 'RdYlBu', 'RdYlGn'}, ...
      {'Blues','BuGn','BuPu','GnBu','Greens','Greys','Oranges','OrRd','PuBu','PuBuGn','PuRd', ...
       'Purples','RdPu', 'Reds', 'YlGn', 'YlGnBu', 'YlOrBr', 'YlOrRd'}, ...
      {'Accent', 'Dark2', 'Paired', 'Pastel1', 'Pastel2', 'Set1', 'Set2', 'Set3'}
  };
  
  f = figure('Position', [314 327 807 420], 'MenuBar', 'none', 'Name', 'ColorBrewer Color maps', 'Color', [1 1 1]);
  
  for itype = 1:3
      subplot(1,3,itype)
      
      for iname = 1:length(cnames{itype})
          ncol = length(colorbrewer.(ctypes{itype}).(cnames{itype}{iname}));
          fg = 1 / ncol; % geometrical factor
  
          X = fg * [0 0 1 1];
          Y = 0.1 * [1 0 0 1] + (2 * iname - 1) * 0.1;
          F = cbrewer(cnames{itype}{iname}, ncol);
  
          for icol = 1:ncol
              X2 = X + fg * (icol - 1);
              fill(X2, Y, F(icol, :), 'LineStyle', 'none')
              text(-0.1, mean(Y), cnames{itype}{iname}, 'HorizontalAlignment', 'right', 'FontSize', 18);
              xlim([-0.4, 1])
              hold on
          end % icol
          
          title(ctypes_title{itype}, 'FontWeight', 'bold', 'FontSize', 16, 'FontName', 'AvantGarde')
          axis off
      end % iname
  end % itype
end