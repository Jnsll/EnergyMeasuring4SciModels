sh=[4 6 14 24 36 79 84 89 91 106 166 173 187 200 219 264 299 309 324 346 353 356]';
xia=[4 6 14 24 36 79 84 89 91 106 166 173 187 200 219 264 299 309 324 346 353 356]';

a1 = imread('000a.bmp');
b = 0:208;
[m, n] = size(a1);
N = length(b);
a = zeros(m, n, N*2);

% Preallocate aa and read images
aa = zeros(m, n, N*2);

for i = 1:N
    imageNameA = sprintf('%03da.bmp', b(i));
    imageNameB = sprintf('%03db.bmp', b(i));
    aa(:,:,i) = imread(imageNameA);
    aa(:,:,i+209) = imread(imageNameB);
end

d = zeros(2*209, 2*209);

for i = 1:2*11*19
    for j = 1:2*11*19
        if i ~= j
            s = abs(aa(m,:,i) - aa(1,:,j));
            d(i,j) = sum(s, 'all');
        end
    end
end

ss9 = zeros(length(xia), length(sh));
for i = 1:length(xia)
    for j = 1:length(sh)
        if xia(i) < 209 && sh(j) < 209
            ss9(i,j) = d(xia(i), sh(j)) + d(xia(i)+209, sh(j)+209);
        elseif xia(i) < 209
            ss9(i,j) = d(xia(i), sh(j)) + d(xia(i)+209, sh(j)-209);
        elseif sh(j) < 209
            ss9(i,j) = d(xia(i), sh(j)) + d(xia(i)-209, sh(j)+209);
        else
            ss9(i,j) = d(xia(i), sh(j)) + d(xia(i)-209, sh(j)-209);
        end
    end
end

t1 = zeros(m, 2*11*19);

for i = 1:2*11*19
    for j = 1:m
        t1(j,i) = sum(aa(j,:,i) == 255);
    end
end

dt = diff(t1);
[~, ind] = max(dt, [], 1);

N = 63;
ind = mod(ind-1, N) + 1;

ss2 = zeros(length(xia), length(sh));
for i = 1:length(xia)
    for j = 1:length(sh)
        if xia(i) < 209 && sh(j) < 209
            ss2(i,j) = abs(N - sum([ind(xia(i)), ind(sh(j))])) + abs(N - sum([ind(xia(i)+209), ind(sh(j)+209)]));
        elseif xia(i) < 209
            ss2(i,j) = abs(N - sum([ind(xia(i)), ind(sh(j))])) + abs(N - sum([ind(xia(i)+209), ind(sh(j)-209)]));
        elseif sh(j) < 209
            ss2(i,j) = abs(N - sum([ind(xia(i)), ind(sh(j))])) + abs(N - sum([ind(xia(i)-209), ind(sh(j)+209)]));
        else
            ss2(i,j) = abs(N - sum([ind(xia(i)), ind(sh(j))])) + abs(N - sum([ind(xia(i)-209), ind(sh(j)-209)]));
        end
    end
end

ma = max(ss2, [], 'all');
ma2 = max(ss9, [], 'all');
ss2 = ss2 / ma;
ss9 = ss9 / ma2;
juli = ss2 + ss9;

[~, ind] = min(juli, [], 2);
size = size(ind');