close all; % Close all figure windows
clear; % Clear workspace variables
clc; % Clear command window

I = imread('flower.tif'); % Read the flower image
J = I + 30; % Increase each pixel value by 30

% Set default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]); 
set(0, 'defaultFigureColor', [1, 1, 1]);

% Display original and modified images
subplot(1, 2, 1), imshow(I);
subplot(1, 2, 2), imshow(J);