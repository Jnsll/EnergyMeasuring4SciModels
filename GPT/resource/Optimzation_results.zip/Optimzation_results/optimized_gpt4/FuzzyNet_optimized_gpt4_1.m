```matlab
%% Water Quality Evaluation Code Based on Fuzzy Neural Network

% Clear environment variables
clc;
clear;

%% Parameter Initialization
xite = 0.001;
alfa = 0.05;

% Network nodes
I = 6;   % Input nodes
M = 12;  % Hidden nodes
O = 1;   % Output nodes

% Coefficients initialization
p = 0.3 * ones(M, 7); % Combine all p parameters into one matrix
p_1 = p;
p_2 = p_1;

% Parameters initialization
c = 1 + rands(M, I);
c_1 = c;
c_2 = c_1;
b = 1 + rands(M, I);
b_1 = b;
b_2 = b_1;

maxgen = 100; % Number of evolutions

% Load and normalize network test data
load data1 input_train output_train input_test output_test
[inputn, inputps] = mapminmax(input_train);
[outputn, outputps] = mapminmax(output_train);
[n, m] = size(input_train);

%% Network Training
for iii = 1:maxgen
    for k = 1:m        
        x = inputn(:, k);
        
        % Output layer calculation
        u = exp(-(x - c).^2 ./ b);
        
        % Fuzzy rule calculation
        w = prod(u, 1);
        addw = sum(w);
        
        yi = p_1(:, 1) + sum(p_1(:, 2:end) .* x