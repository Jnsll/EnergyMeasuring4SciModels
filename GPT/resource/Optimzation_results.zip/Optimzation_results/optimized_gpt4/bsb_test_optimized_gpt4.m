% bsb_test.m
x = [-0.5; -0.4];
beta = 0.5;
c = 100;

% Call the bsb function
bsb(x, beta, c);

% Add text annotation to the plot
text(x(1), x(2), sprintf('(%0.1f,%0.1f)', x(1), x(2)));