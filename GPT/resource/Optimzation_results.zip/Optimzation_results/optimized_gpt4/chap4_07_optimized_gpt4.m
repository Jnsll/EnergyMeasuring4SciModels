close all; % Close all figure windows
clear; % Clear variables
clc; % Clear command window

RGB = imread('eight.tif'); % Read the image

M_values = [3, 9];
running_times = zeros(1, length(M_values));
BW_images = cell(1, length(M_values));

for i = 1:length(M_values)
    [BW_images{i}, running_times(i)] = Denoise(RGB, M_values(i));
end

set(0, 'defaultFigurePosition', [100, 100, 1000, 500]); % Set default figure position
set(0, 'defaultFigureColor', [1 1 1]); % Set default figure color

figure;
for i = 1:length(BW_images)
    subplot(1, length(BW_images), i);
    imshow(BW_images{i});
end

disp('����4������ʱ��');
disp(running_times(1));
disp('����10������ʱ��');
disp(running_times(2));