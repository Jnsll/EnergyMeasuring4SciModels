function [orig] = initializeGlobalState()
% Initialize global state. Set working directory and various properties of
% the graphical root to ensure reliable output of the ACID testsuite.
% See #542 and #552

    fprintf('Initialize global state...\n');
    orig = struct();

    %--- Extract user defined default properties and set factory state
    default = get(0,'Default');
    factory = get(0,'Factory');

    %--- Define desired global state properties
    new = struct(...
        'defaultAxesColorOrder', struct('val', [0.000 0.447 0.741; 0.850 0.325 0.098; 0.929 0.694 0.125; 0.494 0.184 0.556; 0.466 0.674 0.188; 0.301 0.745 0.933; 0.635 0.0780 0.184], 'ignore', false), ...
        'defaultFigurePosition', struct('val', [300, 200, 560, 420], 'ignore', false), ...
        'ScreenPixelsPerInch', struct('val', 96, 'ignore', strcmpi(getEnvironment, 'octave')), ...
        'defaultAxesColor', struct('val', [1 1 1], 'ignore', false), ...
        'defaultLineColor', struct('val', [0 0 0], 'ignore', false), ...
        'defaultTextColor', struct('val', [0 0 0], 'ignore', false), ...
        'defaultAxesXColor', struct('val', [0 0 0], 'ignore', false), ...
        'defaultAxesYColor', struct('val', [0 0 0], 'ignore', false), ...
        'defaultAxesZColor', struct('val', [0 0 0], 'ignore', false), ...
        'defaultFigureColor', struct('val', [0.8 0.8 0.8], 'ignore', false), ...
        'defaultPatchEdgeColor', struct('val', [0 0 0], 'ignore', false), ...
        'defaultPatchFaceColor', struct('val', [0 0 0], 'ignore', false), ...
        'defaultFigurePaperType', struct('val', 'A4', 'ignore', false), ...
        'defaultFigurePaperSize', struct('val', [20.9840 29.6774], 'ignore', false), ...
        'defaultFigurePaperUnits', struct('val', 'centimeters', 'ignore', false) ...
    );

    %--- Extract relevant properties and set desired state
    f = fieldnames(default);    % fields of user's default state
    for i = 1:length(f)
        factory_property_name = strrep(f{i}, 'default', 'factory');
        factory_property_value = factory.(factory_property_name);
        orig.(f{i}).val = swapPropertyState(0, f{i}, factory_property_value);
    end

    %--- Set new properties
    f_new = fieldnames(new);    % fields of new state
    for i = 1:length(f_new)
        % ignore property on specified environments
        if ~new.(f_new{i}).ignore
            val = swapPropertyState(0, f_new{i}, new.(f_new{i}).val);

            % store original value only if not set by user's defaults
            if ~isfield(orig, f_new{i})
                orig.(f_new{i}).val = val;
            end
        end
    end
end

% =========================================================================
function old = swapPropertyState(h, property, new)
    % Read current property of graphical object
    % Set new value if not empty
    if nargin < 3, new = []; end

    old = get(h, property);

    if ~isempty(new)
        set(h, property, new);
    end
end