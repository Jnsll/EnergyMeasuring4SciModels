load -ascii monks_A1
load -ascii monks_T

[N, m] = size(monks_T);

class = 1;

app  = monks_A1;
test = monks_T;

Napp = size(app, 2);
Ntest = size(test, 2);

uniqueClassesApp = unique(app(class, :));
uniqueClassesTest = unique(test(class, :));

ns = max(monks_T, [], 2);
clear monks_A1 monks_T

% N, ns(class), Napp, Ntest, mean(ns)