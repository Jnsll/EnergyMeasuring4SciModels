% Clear workspace, close all figures, clear command window
clear all;
close all;
clc;

% Read images
B = imread('girl2.bmp');
C = imread('boy1.bmp');

% Face detection
BW1 = face_detection(B);
BW2 = face_detection(C);

% Set default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1200, 450]);
set(0, 'defaultFigureColor', [1 1 1]);

% Display images and results
figure;
subplot(2, 2, 1), imshow(B);
subplot(2, 2, 2), imshow(BW1);
subplot(2, 2, 3), imshow(C);
subplot(2, 2, 4), imshow(BW2);