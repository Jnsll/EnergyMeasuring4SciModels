clear;                        % Clear workspace
close all;                    % Close all figure windows
clc;                          % Clear command window

N = 64;                       % Define quantization value N
m = 15;
L = 2.0;

[x, h] = RLfilter(N, L);
range = (N-m):(N+m);
x1 = x(range);
h1 = h(range);

set(0, 'defaultFigurePosition', [100, 100, 1200, 450]); % Set default figure position
set(0, 'defaultFigureColor', [1 1 1]);                  % Set default figure background color

figure;
subplot(1, 2, 1);
plot(x, h);
axis tight;
grid on;                       % Display waveform

subplot(1, 2, 2);
plot(x1, h1);
axis tight;
grid on;                       % Display waveform