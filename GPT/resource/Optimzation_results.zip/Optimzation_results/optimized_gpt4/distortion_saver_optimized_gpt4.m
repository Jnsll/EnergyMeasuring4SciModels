% Generate different distortions 
file = dir('./pristine_images/*.bmp');   % The folder path of dataset

num_files = length(file);
distortion_types = 1:4;
distortion_levels = 1:5;

for i = 1:num_files
    refI = open_bitfield_bmp(fullfile('.', 'pristine_images', file(i).name));
    for type = distortion_types
        for level = distortion_levels
            distortion_generator(refI, type, level, file(i)); % #ok
        end
    end
    if mod(i, 10) == 0 || i == num_files
        fprintf('Finished image %d / %d...\n', i, num_files);
    end
end