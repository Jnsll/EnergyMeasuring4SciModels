% runs all tests in 'test' folder

clc; clear;
addpath('./test', './utilities');

tests = dir('./test/*TEST*.m');

disp('running TESTRUNNER');
for i = 1:numel(tests)
    run(fullfile(tests(i).folder, tests(i).name));
    if i < numel(tests)
        clearvars -except tests i;
    end
end

disp('TESTRUNNER ran without error');