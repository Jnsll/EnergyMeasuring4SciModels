function class_info = gen_class_info_voc()
    % Initialize class_info structure
    class_info = struct();

    % Define class names
    class_info.class_names = { 'background', 'aeroplane', 'bicycle', 'bird', 'boat', 'bottle', 'bus', ...
        'car', 'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse', ...
        'motorbike', 'person', 'pottedplant', 'sheep', 'sofa', 'train', 'tvmonitor', ...
        'void' }';

    % Define class label values
    void_class_value = 255;
    class_info.class_label_values = uint8([0:20, void_class_value]);
    class_info.background_label_value = uint8(0);
    class_info.void_label_values = uint8(void_class_value);

    % Generate mask color map
    class_info.mask_cmap = VOClabelcolormap(256);

    % Process class information
    class_info = process_class_info(class_info);
end