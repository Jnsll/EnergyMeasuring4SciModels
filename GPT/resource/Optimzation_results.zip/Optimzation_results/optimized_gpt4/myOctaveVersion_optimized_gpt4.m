% Return OCTAVE_VERSION or 'undefined' as a string
function result = myOctaveVersion()
    persistent isOctaveFlag
    if isempty(isOctaveFlag)
        isOctaveFlag = (exist('OCTAVE_VERSION', 'builtin') ~= 0);
    end
    
    if isOctaveFlag
        result = OCTAVE_VERSION;
    else
        result = 'undefined';
    end
end