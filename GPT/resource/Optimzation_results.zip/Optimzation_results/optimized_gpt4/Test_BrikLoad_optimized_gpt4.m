%script Test_BrikLoad
%
%
%
%Purpose:
%
%
%
%Input:
%
%
%
%Output:
%
%
%
%
%
%Key Terms:
%
%More Info :
%
%
%
%
%     Author : Ziad Saad
%     Date : Fri Dec 15 20:19:14 PST 2000
%     LBC/NIMH/ National Institutes of Health, Bethesda Maryland

% Debug Flag
DBG = 1;

BrikName = 'ARzs_CW_avvr.DEL+orig.BRIK';

% Load BRIK file once and reuse data for different formats
[err, V, Info, ErrMessage] = BrikLoad(BrikName);

% Check if there was an error loading the BRIK file
if err
    error(['Error loading BRIK file: ' ErrMessage]);
end

% Convert loaded data to vector format
Opt.Format = 'vector';
Vv = convertFormat(V, Opt);

% Convert loaded data to matrix format
Opt.Format = 'matrix';
Vm = convertFormat(V, Opt);

% Function to convert data to specified format
function dataOut = convertFormat(dataIn, Opt)
    switch Opt.Format
        case 'vector'
            dataOut = dataIn(:); % Convert to vector
        case 'matrix'
            dataOut = reshape(dataIn, size(dataIn)); % Ensure it is a matrix
        otherwise
            error('Unknown format specified');
    end
end