% Close all figure windows, clear workspace variables, and clear command window
close all;
clc;
clear;

% Read images
I = imread('girl.bmp');
J = imread('lenna.bmp');

% Convert images to binary
I1 = im2bw(I);
J1 = im2bw(J);

% Perform logical operations on binary images
H = ~(I1 | J1);
G = ~(I1 & J1);

% Set default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(0, 'defaultFigureColor', [1, 1, 1]);

% Display original and binary images
figure;
subplot(1, 2, 1);
imshow(I1);
axis on;
title('Binary Image I1');

subplot(1, 2, 2);
imshow(J1);
axis on;
title('Binary Image J1');

% Display results of logical operations
figure;
subplot(1, 2, 1);
imshow(H);
axis on;
title('Result of ~(I1 | J1)');

subplot(1, 2, 2);
imshow(G);
axis on;
title('Result of ~(I1 & J1)');