clear; clc;

% Read data from Excel file
a = xlsread('cumcm.xls', 'sheet1', 'B1:H24'); % Battery information
b = xlsread('cumcm.xls', 'sheet2', 'A1:M18'); % Inverter information
c = xlsread('cumcm.xls', 'sheet3', 'B1:F24'); % Power generation information
d = xlsread('cumcm.xls', 'sheet3', 'A27:D37304'); % Arrangement information

f = 4; % Direction, eastward is 2
N = 26; % Area of each face

% Preallocate arrays for efficiency
numRecords = size(d, 1);
Q = zeros(numRecords, size(d, 2) + 3);
r = false(numRecords, 1);

for i = 1:numRecords
    area = d(i, 3) * d(i, 4);
    q = area * c(d(i, 2), f) * b(d(i, 1), 10) * 0.5 * 31.5 - b(d(i, 1), 13) - area * a(d(i, 2), 6);
    q_ = q / (area * a(d(i, 2), 7));
    Q(i, :) = [d(i, :), q, q_, area * a(d(i, 2), 7)];

    if (area * a(d(i, 2), 7)) > N
        r(i) = true;
    end
end

% Remove rows where the condition is met
Q(r, :) = [];