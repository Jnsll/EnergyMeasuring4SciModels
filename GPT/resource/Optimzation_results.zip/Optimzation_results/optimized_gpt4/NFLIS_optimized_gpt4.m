clear all;
% NFLIS��������
data_path = 'MCM_NFLIS_Data.xlsx';
[data, text] = xlsread(data_path, 'Data', 'A2:J24063');

years = data(:, 1);
drug_report = data(:, 8);
drug_state_report = data(:, 10);
drug_county_report = data(:, 9);

state = text(:, 3);
county = text(:, 5);
drug = text(:, 6);

data_len = length(years);
county_list = {};
drug_list = {};
state_list = {'39', '21', '54', '51', '42'};
state2id = containers.Map(state_list, num2cell(1:length(state_list)));
county2state = containers.Map();
drug2id = containers.Map();
county_list_map = containers.Map();
state_county_num = zeros(1, length(state_list));

for i = 1:data_len
    drug_code = cell2mat(drug(i));
    county_code = cell2mat(county(i));
    state_code = cell2mat(state(i));
    
    if ~isKey(drug2id, drug_code)
        drug_list{end+1} = drug_code;
        drug2id(drug_code) = length(drug_list);
    end
    
    if ~isKey(county_list_map, county_code)
        state_idx = state2id(state_code);
        county_list{end+1} = county_code;
        county_list_map(county_code) = length(county_list);
        county2state(county_code) = state_code;
        state_county_num(state_idx) = state_county_num(state_idx) + 1;
    end
end

year_list = 2010:2017;
num_years = length(year_list);
num_states = length(state_list);
num_counties = length(county_list);
num_drugs = length(drug_list);

drug_state = zeros(num_states, num_years, num_drugs);
drug_county = zeros(num_counties, num_years, num_drugs);
drug_state_total = zeros(num_states, num_years);
drug_county_total = zeros(num_counties, num_years);

for i = 1:data_len
    state_idx = state2id(cell2mat(state(i)));
    year_idx = years(i) - 2009;
    drug_idx = drug2id(cell2mat(drug(i)));
    county_list_idx = county_list_map(cell2mat(county(i)));
    
    drug_county(county_list_idx, year_idx, drug_idx) = drug_report(i);
    drug_state(state_idx, year_idx, drug_idx) = drug_state(state_idx, year_idx, drug_idx) + drug_report(i);
    drug_state_total(state_idx, year_idx) = drug_state_report(i);
    drug_county_total(county_list_idx, year_idx) = drug_county_report(i);
end