% MAIN.m
%
% Solve the cart-pole swing-up problem

clc; clear;
addpath ../../

p.m1 = 2.0;  % (kg) Cart mass
p.m2 = 0.5;  % (kg) pole mass
p.g = 9.81;  % (m/s^2) gravity
p.l = 0.5;   % (m) pendulum (pole) length

dist = 0.8;  % How far must the cart translate during its swing-up
maxForce = 100;  % Maximum actuator forces
duration = 2;

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                     Set up function handles                             %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

dynamics = @(t,x,u) cartPoleDynamics(x,u,p);
pathObj = @(t,x,u) u.^2;  % Force-squared cost function

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                     Set up problem bounds                               %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

bounds.initialTime = struct('low', 0, 'upp', 0);
bounds.finalTime = struct('low', duration, 'upp', duration);

bounds.initialState = struct('low', zeros(4,1), 'upp', zeros(4,1));
bounds.finalState = struct('low', [dist; pi; 0; 0], 'upp', [dist; pi; 0; 0]);

bounds.state = struct('low', [-2*dist; -2*pi; -inf; -inf], 'upp', [2*dist; 2*pi; inf; inf]);
bounds.control = struct('low', -maxForce, 'upp', maxForce);

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                    Initial guess at trajectory                          %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

guess.time = [0, duration];
guess.state = [bounds.initialState.low, bounds.finalState.low];
guess.control = [0, 0];

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                         Solver options                                  %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

nlpOpt = optimset('Display', 'iter', 'MaxFunEvals', 1e5);

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                            Solve!                                       %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

problem = struct('func', struct('dynamics', dynamics, 'pathObj', pathObj), ...
                 'bounds', bounds, ...
                 'guess', guess, ...
                 'options', struct('nlpOpt', nlpOpt));

soln = optimTraj(problem);

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
%                        Display Solution                                 %
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%

% Unpack the simulation
t = linspace(soln.grid.time(1), soln.grid.time(end), 150);
z = soln.interp.state(t);
u = soln.interp.control(t);

% Draw Trajectory:
[p1, p2] = cartPoleKinematics(z, p);

figure(2); clf;
nFrame = 9;  % Number of frames to draw
drawCartPoleTraj(t, p1, p2, nFrame);

% Show the error in the collocation constraint between grid points:
if ismember(soln.problem.options.method, {'trapezoid', 'hermiteSimpson'})
    figure(5); clf;

    % Collocation constraint error estimation
    cc = soln.interp.collCst(t);
    
    subplot(2,2,1);
    plot(t, cc(1,:));
    title('Collocation Error:   dx/dt - f(t,x,u)');
    ylabel('d/dt cart position');
    
    subplot(2,2,3);
    plot(t, cc(2,:));
    xlabel('time');
    ylabel('d/dt pole angle');
    
    idx = 1:length(soln.info.error);
    subplot(2,2,2); hold on;
    plot(idx, soln.info.error(1,:), 'ko');
    title('State Error');
    ylabel('cart position');
    
    subplot(2,2,4); hold on;
    plot(idx, soln.info.error(2,:), 'ko');
    xlabel('segment index');
    ylabel('pole angle');
end

% Plot the state and control against time
figure(1); clf;
plotPendulumCart(t, z, u, p);