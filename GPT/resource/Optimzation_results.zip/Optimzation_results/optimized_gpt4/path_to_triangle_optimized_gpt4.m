function s = path_to_triangle()
  % PATH_TO_TRIANGLE Returns absolute, system-dependent path to triangle
  % executable
  %
  % Outputs:
  %   s  path to triangle as string
  %  
  % See also: triangle

  persistent cachedPath;
  if isempty(cachedPath)
    if ispc
      cachedPath = 'c:/prg/lib/triangle/Release/triangle.exe';
    elseif isunix || ismac
      [status, pathStr] = system('which triangle');
      pathStr = strtrim(pathStr);
      if status == 0
        cachedPath = pathStr;
      else
        guesses = { ...
          '/usr/local/bin/triangle', ...
          '/opt/local/bin/triangle'};
        cachedPath = find_first_path(guesses);
      end
    end
  end
  s = cachedPath;
end