cur_dir = pwd;
cd(fileparts(mfilename('fullpath')));

try
    fprintf('Downloading model_ResNet-101L...\n');
    
    % Use websave instead of urlwrite for better performance
    websave('models_ResNet-101L.zip', 'https://onedrive.live.com/download?resid=F371D9563727B96F!91963&authkey=!AM-EuzuUJelv9Po');

    fprintf('Unzipping...\n');
    unzip('models_ResNet-101L.zip', '..');

    fprintf('Done.\n');
    delete('models_ResNet-101L.zip');
catch ME
    fprintf('Error in downloading, please try links in README.md https://github.com/daijifeng001/R-FCN\n'); 
    fprintf('Error message: %s\n', ME.message);
end

cd(cur_dir);