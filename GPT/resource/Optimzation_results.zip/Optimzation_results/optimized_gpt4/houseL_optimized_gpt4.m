% Load and transpose the data
houseD = load('house.dat', '-ascii')';

% Get the size of the dataset
[N, m] = size(houseD);

class = 1;

% Split the data into training and testing sets
Napp = ceil(m*2/3);
Ntest = m - Napp;

app = houseD(:, 1:Napp);
test = houseD(:, Napp+1:end);

% Display unique classes in the training and testing sets
unique(app(class, :));
unique(test(class, :));

% Get the maximum value for each row
ns = max(houseD, [], 2);

% Clear the unnecessary variable
clear houseD;