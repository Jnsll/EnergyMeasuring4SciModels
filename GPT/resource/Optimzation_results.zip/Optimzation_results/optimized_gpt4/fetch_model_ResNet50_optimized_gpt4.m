cur_dir = pwd;
cd(fileparts(mfilename('fullpath')));

try
    fprintf('Downloading model_ResNet-50L...\n');
    websave('models_ResNet-50L.zip', 'https://onedrive.live.com/download?resid=F371D9563727B96F!91962&authkey=!AET2I7W3WzcDyf8');

    fprintf('Unzipping...\n');
    unzip('models_ResNet-50L.zip', '..');

    fprintf('Done.\n');
    delete('models_ResNet-50L.zip');
catch ME
    fprintf('Error in downloading, please try links in README.md https://github.com/daijifeng001/R-FCN\n'); 
    disp(ME.message);
end

cd(cur_dir);