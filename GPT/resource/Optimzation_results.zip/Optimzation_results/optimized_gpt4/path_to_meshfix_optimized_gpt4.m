function s = path_to_meshfix()
  % PATH_TO_MESHFIX Returns absolute, system-dependent path to meshfix executable
  %
  % Outputs:
  %   s  path to meshfix as string
  %  
  % See also: meshfix

  if ispc
    s = 'c:/prg/lib/meshfix/Release/meshfix.exe';
  elseif isunix || ismac
    % I guess this means linux
    [status, s] = system('which meshfix');
    s = strtrim(s);
    if status ~= 0
      guesses = { ...
        '/usr/local/bin/meshfix', ...
        '/opt/local/bin/meshfix', ...
        '/usr/local/igl/libigl/external/MeshFix/meshfix', ...
        '/usr/local/libigl/external/MeshFix/meshfix'};
      s = find_first_path(guesses);
    end
  end
end

function s = find_first_path(guesses)
  % FIND_FIRST_PATH Checks the existence of paths and returns the first valid path
  %
  % Inputs:
  %   guesses  cell array of path strings to check
  % Outputs:
  %   s  first valid path as string or empty if none found
  %
  % See also: path_to_meshfix

  s = '';
  for i = 1:length(guesses)
    if exist(guesses{i}, 'file') == 2
      s = guesses{i};
      return;
    end
  end
end