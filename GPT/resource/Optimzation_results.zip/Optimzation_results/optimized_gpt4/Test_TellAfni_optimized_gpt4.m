%script Test_TellAfni
%
%
%
%Purpose:
%
%   A script to demonstrate the use of the matlab AFNI driver tools (TellAfni).
%   Make sure no current AFNI session is running with the -yesplugouts option.
%
%   The script is not fancy and some steps might go by too quickly but it should
%   be a simple read to figure it all out.
%
%Input:
%
%   Needs the datasets distributed with AFNI's matlab library
%   https://afni.nimh.nih.gov/pub/dist/data/afni_matlab_data.tgz
%
%Output:
%
%  Follow instructions, watch AFNI
%
%
%
%More Info :
%
%    TellAfni
%    TellAfni_Commands
%    NewCs
%    AFNI's README.driver file
%    AFNI's plugout_drive program
%
%     Author : Ziad Saad
%     Date : Tue Dec 6 14:17:34 EST 2005
%     SSCC/NIMH/ National Institutes of Health, Bethesda Maryland


% Debug Flag
DBG = 1;

% Get the directory
dirname = uigetdir(cd,'Select directory that has AFNI''s matlab demo data');
% dirname = '/Users/ziad/DownLoad/Demo_Bricks'

% Check for datasets
if exist(fullfile(dirname, 'ARzsspgrax+orig.HEAD'), 'file') ~= 2
   fprintf(2,'Error: Could not find test data in selected directory:\n%s\n', dirname);
   return;
end

% Launch AFNI
cs = NewCs('start_afni', '', dirname);
err = TellAfni(cs);
if err
   fprintf(2,'Error: Failed to start AFNI in listening mode.\n');
   return;
end

% Switch to relevant datasets
commands = {
    NewCs('Set_Anatomy', 'A', 'ARzsspgrax')
    NewCs('open_window', '', 'axialimage', 'mont=2x2:8 keypress=v geom=500x500+800+50')
};
err = TellAfni(commands);
if err
   fprintf(2,'Error: Failed telling AFNI.\n');
   return;
end

fprintf(1,'Sleeping for a few seconds...\n'); pause(4);

commands = {
    NewCs('open_window', '', 'axialimage', 'keypress=" "')
    NewCs('OPEN_PANEL', '', 'Define_Overlay')
    NewCs('Set_Function', 'A', 'ARzs_CW_avvr.DEL')
    NewCs('See_Overlay', '', '+')
    NewCs('SET_DICOM_XYZ', '', '-6 86 -3')
    NewCs('SET_PBAR_SIGN', '' ,'+')
    NewCs('SET_PBAR_NUMBER', '' ,'20')
    NewCs('SET_SUBBRICKS', '', '-1 0 2')
    NewCs('SET_FUNC_RANGE', '', 30)
    NewCs('SET_THRESHNEW','', 1e-9, '*p')
    NewCs('SET_FUNC_RESAM','', 'Cu.Cu')
};
err = TellAfni(commands);
if err
   fprintf(2,'Error: Failed telling AFNI.\n');
   return;
end

fprintf(1,'Sleeping for a few seconds...\n'); pause(4);

commands = {
    NewCs('open_window', 'B', 'coronalgraph', 'geom=500x500+50+550')
    NewCs('Set_Anatomy', 'B', 'ARzs_CW_avvr+orig')
    NewCs('SET_DICOM_XYZ', 'B', '-6 86 -3')
};
err = TellAfni(commands);
if err
   fprintf(2,'Error: Failed telling AFNI.\n');
   return;
end

fprintf(1,'Sleeping for a few seconds...\n'); pause(4);

commands = {
    NewCs('open_window', 'A', 'coronalimage', 'geom=500x500+550+750')
    NewCs('open_window', '', 'axialimage', 'mont=1x1')
};
err = TellAfni(commands);
if err
   fprintf(2,'Error: Failed telling AFNI.\n');
   return;
end

fprintf(1,'Sleeping for a few seconds...\n'); pause(4);

commands = cell(1, 40); % Preallocate cell array for efficiency
for k = 1:20
    commands{2*k-1} = NewCs('PBAR_ROTATE', '', '+');
    fnm = sprintf('Rot_%02d.jpg', k);
    unix(sprintf('rm %s', fnm));
    commands{2*k} = NewCs('SAVE_JPEG', '', 'coronalimage', fnm);
end
err = TellAfni(commands);
if err
   fprintf(2,'Error: Failed telling AFNI.\n');
   return;
end

% Load then show the images written to disk
ts = struct('im', cell(1, 20)); % Preallocate struct array for efficiency
for i = 1:20
    fnm = sprintf('Rot_%02d.jpg', i);
    ts(i).im = imread(fnm);
end
figure(1); clf;
for i = 1:200
    imshow(ts(mod(i-1, 20) + 1).im); drawnow
end

input('All done, hit "enter" to quit\n','s');
err = TellAfni(NewCs('Quit'));
if err
   fprintf(2,'Error: Failed telling AFNI.\n');
   return;
end