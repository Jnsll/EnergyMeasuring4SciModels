function s = path_to_tetgen()
  % PATH_TO_TETGEN Returns absolute, system-dependent path to tetgen executable
  %
  % Outputs:
  %   s  path to tetgen as string
  %  
  % See also: tetgen

  persistent cachedPath;
  
  if isempty(cachedPath)
    if ispc
      % replace this with path
      cachedPath = 'c:/prg/lib/tetgen/Release/tetgen.exe';
    elseif ismac || isunix
      [status, cachedPath] = system('which tetgen');
      cachedPath = strtrim(cachedPath);
      if status ~= 0
        guesses = { ...
          '/usr/local/bin/tetgen', ...
          '/opt/local/bin/tetgen', ...
          '/Users/ajx/Repos/tetgen/build/tetgen', ...
          '/usr/local/igl/libigl/external/tetgen/tetgen', ...
          '/usr/local/libigl/external/tetgen/tetgen'};
        cachedPath = find_first_path(guesses);
      end
    end
  end
  
  s = cachedPath;
end