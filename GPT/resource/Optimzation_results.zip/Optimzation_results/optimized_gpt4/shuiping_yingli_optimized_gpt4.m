clear; clc;

% Load data from Excel file
a = xlsread('cumcm.xls', 'sheet1', 'B1:H24'); % Battery information
b = xlsread('cumcm.xls', 'sheet2', 'A1:M18'); % Inverter information
c = xlsread('cumcm.xls', 'sheet3', 'B1:F24'); % Power generation
d = xlsread('cumcm.xls', 'sheet3', 'A27:D1266'); % Arrangement information

% Preallocate arrays for efficiency
numRows = size(d, 1);
Q = zeros(numRows, 1);
Q_ = zeros(numRows, size(d, 2) + 2);

N = 18; % Area of each surface

% Vectorized calculations for efficiency
d34 = d(:, 3) .* d(:, 4);
c1 = c(d(:, 2), 1);
b10 = b(d(:, 1), 10);
b13 = b(d(:, 1), 13);
a6 = a(d(:, 2), 6);
a7 = a(d(:, 2), 7);

q = d34 .* c1 .* b10 * 0.5 * 31.5 - b13 - d34 .* a6;
q_ = q ./ (d34 .* a7);

Q = q;
Q_ = [d, q_, d34 .* a7];

% Optional filtering step commented out
% r = (d34 .* a7) > N;
% Q_(r, :) = [];