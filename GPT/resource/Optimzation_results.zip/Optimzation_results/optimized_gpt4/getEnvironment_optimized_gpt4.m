function [env, versionString] = getEnvironment()
% Determine environment (Octave, MATLAB) and version string
% TODO: Unify private `getEnvironment` functions
    persistent envCache versionCache

    if isempty(envCache)
        if exist('OCTAVE_VERSION', 'builtin') ~= 0
            envCache = 'Octave';
            versionCache = OCTAVE_VERSION;
        else
            envCache = 'MATLAB';
            versionCache = ver('MATLAB').Version;
        end
    end

    env = envCache;
    versionString = versionCache;
end