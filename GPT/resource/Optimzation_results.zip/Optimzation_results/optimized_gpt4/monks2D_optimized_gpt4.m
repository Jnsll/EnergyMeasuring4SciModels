% Load data
load -ascii monks_A2
load -ascii monks_T

% Determine the size of the test data
[N, m] = size(monks_T);

% Define class index
class = 1;

% Assign app and test datasets
app = monks_A2;
test = monks_T;

% Get the number of columns for app and test datasets
Napp = size(app, 2);
Ntest = size(test, 2);

% Find unique values in the specified class
unique_app_class = unique(app(class, :));
unique_test_class = unique(test(class, :));

% Get the maximum values in each row of monks_T
ns = max(monks_T, [], 2);

% Clear unnecessary variables to free up memory
clear monks_A2 monks_T

% Display the results
disp(['N: ' num2str(N)]);
disp(['ns(class): ' num2str(ns(class))]);
disp(['Napp: ' num2str(Napp)]);
disp(['Ntest: ' num2str(Ntest)]);
disp(['mean(ns): ' num2str(mean(ns))]);