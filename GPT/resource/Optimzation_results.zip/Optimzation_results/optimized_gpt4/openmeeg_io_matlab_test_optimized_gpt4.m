% =============================
% = Testing standard matrices =
% =============================

data = randn(4,9);

om_save_full(data,'test.txt','ascii');
om_save_full(data,'test.bin','binary');
om_save_full(data,'test.mat','matlab');

data_txt = om_load_full('test.txt','ascii');
data_bin = om_load_full('test.bin','binary');
data_mat = om_load_full('test.mat','matlab');

disp(norm(data_txt - data))
disp(norm(data_bin - data))
disp(norm(data_mat - data))

delete('test.txt', 'test.bin', 'test.mat');

% =============================
% = Testing symmetric matrices =
% =============================

rng(0); % Use rng instead of randn('seed',0)
data = randn(5,5);
data = (data+data')/2;

om_save_sym(data,'test.txt','ascii');
om_save_sym(data,'test.bin','binary');
om_save_sym(data,'test.mat','matlab');

data_txt = om_load_sym('test.txt','ascii');
data_bin = om_load_sym('test.bin','binary');
data_mat = om_load_sym('test.mat','matlab');

disp(norm(data_txt - data))
disp(norm(data_bin - data))
disp(norm(data_mat - data))

delete('test.txt', 'test.bin', 'test.mat');

% =============================
% = Testing sparse matrices =
% =============================

data = sprand(5,5,0.5);

om_save_sparse(data,'test.txt','ascii');
om_save_sparse(data,'test.bin','binary');
om_save_sparse(data,'test.mat','matlab');

data_txt = om_load_sparse('test.txt','ascii');
data_bin = om_load_sparse('test.bin','binary');
data_mat = om_load_sparse('test.mat','matlab');

disp(norm(full(data_txt - data)))
disp(norm(full(data_bin - data)))
disp(norm(full(data_mat - data)))

delete('test.txt', 'test.bin', 'test.mat');