function [sig, mixedsig] = demosig()
    % 
    % function [sig, mixedsig] = demosig()
    % 
    % Returns artificially generated test signals, sig, and mixed
    % signals, mixedsig. Signals are row vectors of
    % matrices. Input mixedsig to FastICA to see how it works.

    % @(#)$Id$

    % Create source signals (independent components)
    N = 500; % Data size

    v = 0:N-1;
    sig = zeros(4, N); % Preallocate memory for efficiency

    % Generate signals
    sig(1, :) = sin(v / 2); % Sinusoid
    sig(2, :) = ((rem(v, 23) - 11) / 9) .^ 5; % Funny curve
    sig(3, :) = (rem(v, 27) - 13) / 9; % Saw-tooth
    sig(4, :) = ((rand(1, N) < 0.5) * 2 - 1) .* log(rand(1, N)); % Impulsive noise

    % Normalize signals
    for t = 1:4
        sig(t, :) = sig(t, :) / std(sig(t, :));
    end

    % Remove mean (not really necessary)
    sig = remmean(sig); % Note: `remmean` should return only the signal without mean

    % Create mixtures
    Aorig = rand(size(sig, 1));
    mixedsig = Aorig * sig;
end