% Close all figure windows, clear workspace variables, and clear command window
close all;
clearvars;
clc;

% Load the original two images
X1 = imread('girl.bmp');
X2 = imread('lenna.bmp');

% Perform image fusion using wavelet transform with 'db2' wavelet at level 5
FUSmean = wfusimg(X1, X2, 'db2', 5, 'mean', 'mean');
FUSmaxmin = wfusimg(X1, X2, 'db2', 5, 'max', 'min');

% Set default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(0, 'defaultFigureColor', [1 1 1]);

% Create figure window and display the fused images
figure;
subplot(1, 2, 1), imshow(FUSmean, []);
title('Fused Image (Mean)');
subplot(1, 2, 2), imshow(FUSmaxmin, []);
title('Fused Image (Max-Min)');