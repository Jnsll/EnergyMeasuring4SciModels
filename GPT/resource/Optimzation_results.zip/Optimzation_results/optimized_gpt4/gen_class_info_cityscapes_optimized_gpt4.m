function class_info = gen_class_info_cityscapes()

% Initialize class_info structure
class_info = struct();

% Define class names
class_info.class_names = {'road', 'sidewalk', 'building', 'wall', 'fence', 'pole', ...
    'trafficlight', 'trafficsign', 'vegetation', 'terrain', 'sky', 'person', ...
    'rider', 'car', 'truck', 'bus', 'train', 'motorcycle', 'bicycle', 'void'};

% Define class label values
class_info.class_label_values = uint8([0:18 255]);

% Define background and void label values
class_info.background_label_value = uint8(0);
class_info.void_label_values = uint8(255);

% Load colormap and convert to double
cmap = load('cityscape_cmap.mat', 'cityscape_cmap');
class_info.mask_cmap = im2double(uint8(cmap.cityscape_cmap));

% Process class info
class_info = process_class_info(class_info);

end