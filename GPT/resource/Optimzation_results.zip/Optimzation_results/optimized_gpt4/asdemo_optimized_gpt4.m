% ASORT
% A pedestrian NUMERICAL SORTER of ALPHANUMERIC data

% Create some data
data = {
    % Strings with one valid alphanumeric number, sorted numerically
    '-inf', 'x-3.2e4y', 'f-1.4', '-.1', '+ .1d-2', '.1', 'f.1', 'f -+1.4', ...
    'f.2', 'f.3', 'f.10', 'f.11', '+inf', ' -nan', '+ nan', 'nan', ...
    % Strings with many numbers or invalid/ambiguous numbers, sorted in ASCII dictionary order
    ' nan nan', '+ .1e-.2', '-1 2', 'Z12e12ez', 'inf -inf', 's.3TT.4', 'z12e12ez', ...
    % Strings without numbers, sorted in ASCII dictionary order
    ' . .. ', '.', '...', '.b a.', 'a string', 'a. .b'
};

% Scramble the data
rng(10); % Use rng instead of rand('seed', 10) for better practice
data = data(randperm(numel(data)));

% Run ASORT with verbose output and keep additional results
output = asort(data, '-v', '-d');

% Show results
disp(output);
disp(output.anr);

% Run ASORT with no-space/template options
% Note the impact of -w/-t order!
sampleStrings = {'ff - 1', 'ff + 1', '- 12'};

% RAW
output = asort(sampleStrings, '-v');

% Remove SPACEs
output = asort(sampleStrings, '-v', '-w');

% Remove TEMPLATE(s)
output = asort(sampleStrings, '-v', '-t', {'ff', '1'});

% Remove TEMPLATE(s) then SPACEs
output = asort(sampleStrings, '-v', '-t', '1', '-w');

% Remove SPACEs then TEMPLATE(s)
output = asort(sampleStrings, '-v', '-w', '-t', '1');