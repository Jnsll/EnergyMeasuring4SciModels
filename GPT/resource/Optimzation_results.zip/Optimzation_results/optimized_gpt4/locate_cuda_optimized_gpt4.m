function [cuda_path, cuda_ver] = locate_cuda()

cuda_ver = -1;

% Guess 1:
cuda_path = getenv('CUDA_PATH');
if isempty(cuda_path)
    cuda_path = getenv('CUDA_HOME');
end
if ~isempty(cuda_path) % we have something.
    cuda_ver = get_cuda_ver(cuda_path);
    return;
end

% Guess 2:
if ispc
    command = 'where nvcc';
else
    command = 'which nvcc';
end
[status, cmout] = system(command);
if status == 0 % succeeded
    verstr = strsplit(cmout, '\n', 'CollapseDelimiters', true);
    % Use the first one
    verstr = verstr{1};
    cuda_path = fileparts(verstr);
    cuda_ver = get_cuda_ver(cuda_path);
    return;
end

% Guess 3
if ispc
    guess_cuda_path = 'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/';
    if exist(guess_cuda_path, 'dir')
        versions = dir(guess_cuda_path);
        versions = versions([versions.isdir] & ~ismember({versions.name}, {'.', '..'}));
        % Grab the latest version
        versions_num = arrayfun(@(x) str2double(x.name), versions);
        [~, idx] = max(versions_num);
        cuda_path = fullfile(guess_cuda_path, versions(idx).name);
        cuda_ver = get_cuda_ver(cuda_path);
        return;
    end
else
    % symlink
    guess_cuda_path = '/usr/local/cuda';
    if exist(guess_cuda_path, 'dir')
        cuda_path = guess_cuda_path;
        cuda_ver = get_cuda_ver(cuda_path);
        return;
    end
end

end