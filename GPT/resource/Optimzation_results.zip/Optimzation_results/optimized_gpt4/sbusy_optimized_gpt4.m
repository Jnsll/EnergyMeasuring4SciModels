clc;
clear;

% Read data from Excel files
x1 = readmatrix('ÿʱ��θ�վ��Ľ賵Ƶ��.xls', 'Sheet', 'Sheet1', 'Range', 'B3:BI182');
x2 = readmatrix('ÿʱ��θ�վ��Ļ���Ƶ��.xls', 'Sheet', 'Sheet1', 'Range', 'B3:BI182');

% Process data
y1 = duiqi(x1);
gaofeng1 = gaofengqi(y1);
y2 = duiqi(x2);
gaofeng2 = gaofengqi(y2);

% Write results to new Excel files
writematrix(gaofeng1, 'day_20_gaofeng_jie.xlsx');
writematrix(gaofeng2, 'day_20_gaofeng_huan.xlsx');