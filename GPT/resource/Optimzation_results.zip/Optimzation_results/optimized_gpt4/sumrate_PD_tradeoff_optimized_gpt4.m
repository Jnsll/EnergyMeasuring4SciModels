%% Producing Fig. 5
clc;
clear;
close all;
warning off;

N = 16;
L = 20;
power = 10^(0/10);
amp = sqrt(power);
N_montecarlo = 100;
SNRdB = 10;

%%-------------Radar Parameters-------------------
delta = pi/180;
theta = -pi/2:delta:pi/2;
target_DoA = [-pi/3, 0, pi/3]; 
beam_width = 9;
l = ceil((target_DoA + pi/2) / delta + 1);
Pd_theta = zeros(length(theta), 1);

for ii = 1:length(target_DoA)
    Pd_theta(l(ii) - (beam_width - 1)/2 : l(ii) + (beam_width - 1)/2) = 1;
end

c = 3e8;
fc = 3.2e9;
lamda = c / fc;
spacing = lamda / 2;

a = zeros(N, length(theta));
for tt = 1:N
    for jj = 1:length(theta)
        a(tt, jj) = exp(1j * pi * (tt - ceil(N/2)) * sin(theta(jj)));
    end
end

SNRr = 10^(-6/10);
uu = 36;

Nii = 20;
N0 = power / (10^(SNRdB / 10));
Nkk = 3;

sumrate2 = zeros(Nii-1, Nkk, N_montecarlo);
PD2 = zeros(Nii-1, Nkk, N_montecarlo);

for kk = 1:Nkk
    K = 4 + (kk - 1) * 2;
    for nn = 1:N_montecarlo
        H = (randn(N, K) + 1j * randn(N, K)) / sqrt(2);
        N_pbits = 2 * K * L;
        msg_bits = randi([0, 1], 1, N_pbits);
        Y = reshape(QPSK_mapper(msg_bits), [K, L]);
        X1 = Orthogonal_Com_Rad(H, Y, power);

        for ii = 1:Nii-1
            rou = ii / Nii;
            X2 = sqrt(N) * tradeoff_comrad(rou, H, Y, power, X1);
            MUI2 = abs(H.' * X2 / sqrt(N) - amp * Y).^2;
            EMUI2 = mean(MUI2, 2);
            sumrate2(ii, kk, nn) = sum(log2(1 + power ./ (EMUI2 + N0 * ones(K, 1)))) / K;
            PD2(ii, kk, nn) = PD_Orthogonal(X2, a(:, uu), SNRr);

            clc;
            disp(['Progress - ', num2str((kk - 1) * N_montecarlo * Nii + (nn - 1) * Nii + ii), '/', num2str(Nii * N_montecarlo * Nkk)]);
        end
    end
end

figure(1);
for kk = 1:Nkk
    plot(mean(sumrate2(:, kk, :), 3), mean(PD2(:, kk, :), 3), '-', 'LineWidth', 1.5, 'MarkerSize', 8); hold on;
end
grid on;
legend('K = 4', 'K = 6', 'K = 8');
xlabel('Average achievable rate (bps/Hz/user)');
ylabel('P_D');