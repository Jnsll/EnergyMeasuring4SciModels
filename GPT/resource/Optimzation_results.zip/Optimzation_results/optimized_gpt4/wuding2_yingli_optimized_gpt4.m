clear; clc;

% Read data from Excel files
a = xlsread('cumcm.xls', 'sheet1', 'B1:H24'); % Battery information
b = xlsread('cumcm.xls', 'sheet2', 'A1:M18'); % Inverter information
c = xlsread('cumcm.xls', 'sheet3', 'B1:H24'); % Power generation
d = xlsread('cumcm.xls', 'sheet3', 'A27:D37304'); % Arrangement information

% Preallocate memory for efficiency
Q = zeros(size(d, 1), size(d, 2) + 3);
f = 7; % Direction, roof is 7
N = 14; % Area threshold
r = false(size(d, 1), 1); % Logical array for rows to be removed

for i = 1:size(d, 1)
    area = d(i, 3) * d(i, 4);
    power_gen = c(d(i, 2), f);
    inverter_eff = b(d(i, 1), 10);
    battery_cost = a(d(i, 2), 6);
    inverter_cost = b(d(i, 1), 13);
    battery_capacity = a(d(i, 2), 7);

    q = area * power_gen * inverter_eff * 0.5 * 31.5 - inverter_cost - area * battery_cost;
    q_ = q / (area * battery_capacity);
    
    Q(i, :) = [d(i, :), q, q_, area * battery_capacity];

    if (area * battery_capacity) > N
        r(i) = true;
    end
end

Q(r, :) = [];