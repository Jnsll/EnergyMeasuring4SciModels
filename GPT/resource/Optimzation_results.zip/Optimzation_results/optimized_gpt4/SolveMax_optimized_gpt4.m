clear all
clc
Ants = 300;
Times = 80;
Rou = 0.9;
P0 = 0.2;
x_lower = -1;
y_lower = -1;
x_upper = 1;
y_upper = 1;

% Preallocate arrays for efficiency
ant = zeros(Ants, 2);
Tau = zeros(Ants, 1);
P = zeros(Times, Ants);
Tau_Best = zeros(Times, 1);

% Vectorized random generation of ant positions
ant(:, 1) = x_lower + (x_upper - x_lower) * rand(Ants, 1);
ant(:, 2) = y_lower + (y_upper - y_lower) * rand(Ants, 1);

% Vectorized calculation of initial pheromone levels
Tau = arrayfun(@(x, y) F(x, y), ant(:, 1), ant(:, 2));

step = 0.05;
f = '-(x.^4 + 3 * y.^4 - 0.2 * cos(3 * pi * x) - 0.4 * cos(4 * pi * y) + 0.6)';

% Vectorized meshgrid and evaluation
[x, y] = meshgrid(x_lower:step:x_upper, y_lower:step:y_upper);
z = eval(f);
figure(1);
subplot(121);
mesh(x, y, z);
hold on;
plot3(ant(:, 1), ant(:, 2), Tau, 'k*');
hold on;

% Iteration process
for T = 1:Times
    lamda = 1 / T;
    [Tau_Best(T), BestIndex] = max(Tau);
    
    % Vectorized calculation of probabilities
    P(T, :) = (Tau(BestIndex) - Tau) / Tau(BestIndex);
    
    for i = 1:Ants
        if P(T, i) < P0  % Local search
            temp1 = ant(i, 1) + (2 * rand - 1) * lamda;
            temp2 = ant(i, 2) + (2 * rand - 1) * lamda;
        else  % Global search
            temp1 = ant(i, 1) + (2 * rand - 1);
            temp2 = ant(i, 2) + (2 * rand - 1);
        end
        
        % Boundary conditions
        temp1 = min(max(temp1, x_lower), x_upper);
        temp2 = min(max(temp2, y_lower), y_upper);
        
        % Update positions if new position is better
        if F(temp1, temp2) > F(ant(i, 1), ant(i, 2))
            ant(i, 1) = temp1;
            ant(i, 2) = temp2;
        end
    end
    
    % Vectorized update of pheromone levels
    Tau = (1 - Rou) * Tau + arrayfun(@(x, y) F(x, y), ant(:, 1), ant(:, 2));
end

subplot(122);
mesh(x, y, z);
hold on;
x = ant(:, 1);
y = ant(:, 2);
plot3(x, y, eval(f), 'k*');
hold on;

[max_value, max_index] = max(Tau);
max_X = ant(max_index, 1);
max_Y = ant(max_index, 2);
max_value = F(max_X, max_Y);
fprintf('max_X = %d, max_Y = %d, max_value = %d', max_X, max_Y, max_value);