function DrawGriewank()
x = -8:0.1:8;
y = x;
[X, Y] = meshgrid(x, y);
Z = arrayfun(@(x, y) Griewank([x, y]), X, Y);
surf(X, Y, Z);
shading interp
end