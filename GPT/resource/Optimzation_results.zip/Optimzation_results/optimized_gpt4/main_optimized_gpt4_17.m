%% Multi-objective Comprehensive Evaluation Example
clc; clear;

% Input prototype of fuzzy matrix
x = [4700 6700 5900 8800 7600
     5000 5500 5300 6800 6000
     4.0 6.1 5.5 7.0 6.8
     30 50 40 200 160
     1500 700 1000 50 100];

% Perform multi-objective fuzzy analysis
r = muti_objective_fuzzy_analysis(x);

% Weights of each index in decision making (expert system, provided by user)
A = [0.25, 0.20, 0.20, 0.10, 0.25];

% Comprehensive evaluation results of each scheme (level)
b = A * r;