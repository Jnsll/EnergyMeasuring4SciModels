% Optimized Matlab Code
I = imread('leaf1.bmp');                   % Read the image
I = im2bw(I);                              % Convert to binary image
C = bwlabel(I, 4);                         % Label connected components with 4-connectivity

% Combine regionprops calls to reduce redundant processing
stats = regionprops(C, 'Area', 'Centroid'); 

% Extract Area and Centroid from the stats structure
Ar = {stats.Area};
Ce = {stats.Centroid};

Ar
Ce