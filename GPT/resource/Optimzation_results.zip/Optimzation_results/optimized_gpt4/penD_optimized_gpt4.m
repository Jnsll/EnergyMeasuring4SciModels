load -ascii pen_A
load -ascii pen_T

[N, m] = size(pen_A);

class = N;

app = pen_A;
test = pen_T;

Napp = m;
Ntest = size(test, 2);

unique(app(class, :));
unique(test(class, :));

ns1 = max(pen_A, [], 2);
ns2 = max(pen_T, [], 2);
ns = max(ns1, ns2);
clear pen_A pen_T ns1 ns2;

% N, ns(class), Napp, Ntest, mean(ns),