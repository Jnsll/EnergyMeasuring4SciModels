function NPMKverChecker()
% NPMKverChecker
%
% Checks to see if there is a newer version of NPMK available for
% download.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Use NPMKverChecker
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Kian Torab
%   support@blackrockmicro.com
%   Blackrock Microsystems
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Version History
%
% 1.0.0.0: September 13, 2017
%   - Initial release.
%
% 1.0.1.0: September 13, 2017
%   - Fixed a crash in case there is no Internet connection.
%
% 1.0.2.0: January 10, 2018
%   - Added a clickable URL to the prompt.
%
% 1.1.0.0: January 27, 2020
%   - Only checks for a new version once a week instead of every time.
%

%% Variables and constants
gitHubURL = 'https://github.com/BlackrockMicrosystems/NPMK/releases/latest';
versionFileName = 'Versions.txt';

%% Find full path of NPMKverChecker.m
fileFullPath = which('NPMKverChecker.m');
datFilePath = strrep(fileFullPath, 'NPMKverChecker.m', 'NPMKverChecker.dat');

%% Check for the latest version of NPMK
try
    checkver = 1;
    if exist(datFilePath, 'file') == 2
        load(datFilePath, '-mat');
        if isfield(checkeddate, 'checkeddate') && (now - datenum(checkeddate)) <= 8
            checkver = 0;
        end
    end
    
    if checkver
        if exist(versionFileName, 'file') == 2
            FIDv = fopen(versionFileName, 'r');
            verFile = fscanf(FIDv, '%s'); 
            fclose(FIDv);
            latestVersion = extractBetween(verFile, 'LATEST:', ' ');
            gitHubPage = webread(gitHubURL);
            newVersionAvailable = contains(gitHubPage, latestVersion);
            if ~newVersionAvailable
                disp('A new version of NPMK may be available.');
                fprintf('Please visit <a href="%s">GitHub NPMK Page</a> to get the latest version.\n', gitHubURL);
            end
            checkeddate = datetime;
            save(datFilePath, 'checkeddate');
        else
            warning('Version file not found.');
        end
    end
catch ME
    warning('An error occurred: %s', ME.message);
end