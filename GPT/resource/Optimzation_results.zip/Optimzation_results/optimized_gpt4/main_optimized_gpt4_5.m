%
% This is the main script to find a (near) optimal solution to the Traveling
% Salesman Problem (TSP), by setting up a Genetic Algorithm (GA) to search 
% for the shortest route (least distance for the salesman to travel to each 
% city exactly once and return to the starting city).
%

clear; clc;

load china;                         % geographic information
plotcities(province, border, city); % draw the map of China

numberofcities = length(city);      % number of cities
% distance matrix: dis(i,j) is the distance between city i and j.
dis = distancematrix(city);   

popSize = 100;                      % population size
max_generation = 1000;              % number of generations
probmutation = 0.16;                % probability of mutation

% Initialize random number generator with "seed". 
rng(103);  % Using rng instead of rand('seed', ...) for better practice

% Initialize the population: start from random routes
pop = zeros(popSize, numberofcities); 
for i = 1:popSize
    pop(i, :) = randperm(numberofcities);
end

% Preallocate memory for popDist and fitness arrays
popDist = zeros(popSize, 1);
fitness = zeros(popSize, 1);

% Main genetic algorithm loop
for generation = 1:max_generation
    
    % Evaluate: compute fitness (1/totaldistance) for each individual in pop
    popDist = totaldistance(pop, dis);
    fitness = 1 ./ popDist;
   
    % Find the best route & distance
    [mindist, bestID] = min(popDist); 
    bestPop = pop(bestID, :);       % best route
    
    % Update best route on figure every 10 generations
    if mod(generation, 10) == 0
        plotroute(city, bestPop, mindist, generation);
    end
    
    % Selection (competition / roulette)
    pop = select(pop, fitness, popSize, 'competition');
    
    % Crossover
    pop = crossover(pop);
    
    % Mutation
    pop = mutation(pop, probmutation);
   
    % Save elitism (best path) and put it into the next generation without changes
    pop(1, :) = bestPop;
end

% Return the best route
[mindist, bestID] = min(popDist); 
bestPop = pop(bestID, :);

% Plot and output final solution
plotroute(city, bestPop, mindist, generation);
fpdfprinter('Final Solution');