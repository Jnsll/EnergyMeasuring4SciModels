%%%%% EM PLANNER Initialization and Configuration File
%%%%% Main Functions: Load Global Path, Load Throttle and Brake Calibration Tables, Set Planning and Control Parameters

%%%% Load throttle and brake calibration table
load('table_calibration.mat');
%%%% Load global path
load('global_path.mat');

%%%% Mapping between front wheel angle and steering wheel angle
right_wheel_ground = linspace(-70, 70, 50);
rack_displacement = [-39.14, -37.2, -35.29, -33.43, -31.6, -29.81, -28.06, -26.34, -24.66, ...
    -23.01, -21.38, -19.79, -18.23, -16.69, -15.18, -13.7, -12.23, -10.8, -9.38, -7.98, ...
    -6.61, -5.25, -3.91, -2.59, -1.29, 0, 1.27, 2.54, 3.78, 5.02, 6.24, 7.46, 8.66, ...
    9.86, 11.05, 12.24, 13.41, 14.59, 15.76, 16.92, 18.09, 19.25, 20.42, 21.59, 22.76, ...
    23.93, 25.11, 26.3, 27.5, 28.71, 29.94];

% Steering system C characteristic
c_factor = 43.75; % Unit: mm/rev

%%% Parameter Settings %%%
DEG2RAD = pi / 180;
RAD2DEG = 180 / pi;

%%%% Vehicle Parameters %%%%
cf = -175016;
cr = -130634;
m = 2020;
Iz = 4095.0;
la = 1.265;
lb = 2.947 - 1.265;

%%%% Lateral LQR Parameters %%%%
LQR_Q = diag([25, 3, 10, 4]);
LQR_R = 15;

%%%% Longitudinal Dual PID Parameters %%%%
KP_PID_distance = 0.5;
KI_PID_distance = 0.0;
KD_PID_distance = 0.0;
KP_PID_speed = 1.8;
KI_PID_speed = 0;
KD_PID_speed = 0;

%%%% LQR Offline %%%%
vx_break_point = linspace(0.01, 50, 5000);
k = zeros(5000, 4);

for i = 1:5000
    vx = vx_break_point(i);
    A = [0, 1, 0, 0;
         0, (cf + cr) / (m * vx), -(cf + cr) / m, (la * cf - lb * cr) / (m * vx);
         0, 0, 0, 1;
         0, (la * cf - lb * cr) / (Iz * vx), -(la * cf - lb * cr) / Iz, (la^2 * cf + lb^2 * cr) / (Iz * vx)];
    B = [0; -cf / m; 0; -la * cf / Iz];
    k(i, :) = lqr(A, B, LQR_Q, LQR_R);
end

LQR_K1 = k(:, 1)';
LQR_K2 = k(:, 2)';
LQR_K3 = k(:, 3)';
LQR_K4 = k(:, 4)';

%%%% Initial Vehicle Position %%%%
host_x_init = 0; 
host_y_init = 0;