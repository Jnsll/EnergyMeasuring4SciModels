load -ascii monks_A3
load -ascii monks_T

[N, m] = size(monks_T);

class = 1;

app  = monks_A3;
test = monks_T;

% Precompute sizes once
[Napp, ~] = size(app);
[Ntest, ~] = size(test);

% Use unique directly on the column
unique(app(:, class));
unique(test(:, class));

% Compute max across the columns once
ns = max(monks_T, [], 2);

clear monks_A3 monks_T

% Display results
disp([N, ns(class), Napp, Ntest, mean(ns)]);