close all;                           % Close all figure windows
clear;                               % Clear workspace variables
clc;                                 % Clear command window

% Function to calculate RGB mean and standard deviation
function [Ravg, Gavg, Bavg, Rstd, Gstd, Bstd] = calculateRGBStats(image)
    R = double(image(:,:,1));        % Red channel
    G = double(image(:,:,2));        % Green channel
    B = double(image(:,:,3));        % Blue channel
    Ravg = mean2(R);                 % Mean of Red channel
    Gavg = mean2(G);                 % Mean of Green channel
    Bavg = mean2(B);                 % Mean of Blue channel
    Rstd = std2(R);                  % Standard deviation of Red channel
    Gstd = std2(G);                  % Standard deviation of Green channel
    Bstd = std2(B);                  % Standard deviation of Blue channel
end

% Read images
I = imread('hua.jpg');               % Flower image
J = imread('yezi.jpg');              % Leaf image

% Calculate statistics for flower image
[Ravg1, Gavg1, Bavg1, Rstd1, Gstd1, Bstd1] = calculateRGBStats(I);

% Calculate statistics for leaf image
[Ravg2, Gavg2, Bavg2, Rstd2, Gstd2, Bstd2] = calculateRGBStats(J);

% Set default figure properties
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(0, 'defaultFigureColor', [1 1 1]);

% Display images
K = imread('flower1.jpg'); 
figure;
subplot(131), imshow(K);             % Display original image
subplot(132), imshow(I);             % Display flower image
subplot(133), imshow(J);             % Display leaf image