clear;clc

% Load data from Excel sheets
fushe = xlsread('cumcm.xls', 'sheet', 'E4:K8763');
dc = xlsread('cumcm.xls', 'sheet1', 'B1:K24');
nbq = xlsread('cumcm.xls', 'sheet2', 'A1:M18'); % Inverter information
d = xlsread('cumcm.xls', 'sheet3', 'A27:D37304'); % Arrangement information

% Precompute frequently used values
sp_zs = fushe(:, 1) - fushe(:, 2);
n_zs = fushe(:, 5) - 0.5 * fushe(:, 2);
d_zs = fushe(:, 4) - 0.5 * fushe(:, 2);
x_zs = fushe(:, 6) - 0.5 * fushe(:, 2);

N = 23; % Area of each surface
a = pi / 2; % Inclination angle
b = -pi / 2; % Azimuth angle

% Precompute trigonometric values
sa = sin(a);
ca = cos(a);
sb = sin(b);
cb = cos(b);

S = zeros(24, 1);

% Vectorized computation of fushe_ry
if sb < 0
    fushe_ry = -d_zs * sa * sb + n_zs * sa * cb + sp_zs * ca + fushe(:, 2) * (pi - a) / pi;
else
    fushe_ry = x_zs * sa * sb + n_zs * sa * cb + sp_zs * ca + fushe(:, 2) * (pi - a) / pi;
end

% Loop over m for computations
for m = 1:24
    fushe_ry_m = fushe_ry;
    fushe_ry_m(fushe_ry_m < dc(m, 9)) = 0;
    fushe_ry_m(fushe_ry_m < 200) = fushe_ry_m(fushe_ry_m < 200) * dc(m, 8);
    fushe_ry_m = fushe_ry_m * dc(m, 10);

    S(m) = sum(fushe_ry_m * dc(m, 1) / 1000) / 1000;
end

S = S';
c = S;

% Initialize Q and r
Q = [];
r = [];

% Vectorized computation of q and q_
q = d(:, 3) .* d(:, 4) .* c(d(:, 2)) .* nbq(d(:, 1), 10) * 0.5 * 31.5 - nbq(d(:, 1), 13) - d(:, 3) .* d(:, 4) .* dc(d(:, 2), 6);
q_ = q ./ (d(:, 3) .* d(:, 4) .* dc(d(:, 2), 7));

% Filter rows based on condition
valid_rows = (d(:, 3) .* d(:, 4) .* dc(d(:, 2), 7)) <= N;

Q = [d(valid_rows, :), q(valid_rows), d(valid_rows, 3) .* d(valid_rows, 4) .* c(d(valid_rows, 2)) .* nbq(valid_rows, 1) * 0.5, q_(valid_rows), (d(valid_rows, 3) .* d(valid_rows, 4) .* dc(valid_rows, 2, 7)), c(d(valid_rows, 2))];