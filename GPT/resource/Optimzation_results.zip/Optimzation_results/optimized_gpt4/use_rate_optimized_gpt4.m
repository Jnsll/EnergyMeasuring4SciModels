% Optimized Matlab Code

% Read constraints
SW = xlsread('SW_src2.xlsx');
FW = xlsread('Flight_W.xlsx');
SN = xlsread('SN_src2.xlsx');
FN = xlsread('Flight_N.xlsx');

% Initialize use rate arrays
use_rate_SW = calculate_use_rate(SW, FW, 24);
use_rate_SN = calculate_use_rate(SN, FN, 45);

function use_rate = calculate_use_rate(S, F, num_gates)
    use_rate = zeros(1, num_gates);
    for i = 1:num_gates
        flight_id = find(S(:, i) == 1); % Get flight IDs
        if ~isempty(flight_id) % If gate is used
            use_time = sum(arrayfun(@(fid) calculate_use_time(F(fid, 1), F(fid, 2)), flight_id));
            use_rate(i) = use_time / (24 * 60);
        end
    end
end

function use_time = calculate_use_time(in_time, out_time)
    % Apply constraints to in_time and out_time
    in_time = max(in_time, 24 * 60);
    out_time = min(out_time, 24 * 60 * 2);
    use_time = out_time - in_time;
end