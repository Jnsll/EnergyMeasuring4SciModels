function vocabList = getVocabList()
%GETVOCABLIST reads the fixed vocabulary list in vocab.txt and returns a
%cell array of the words
%   vocabList = GETVOCABLIST() reads the fixed vocabulary list in vocab.txt 
%   and returns a cell array of the words in vocabList.

%% Read the fixed vocabulary list
fid = fopen('vocab.txt');

% Check if file opened successfully
if fid == -1
    error('Cannot open vocab.txt');
end

% Store all dictionary words in cell array vocabList
vocabList = {};

% Read the file line by line
line = fgetl(fid);
while ischar(line)
    % Extract the word from the line
    [~, word] = strtok(line, ' ');
    vocabList{end+1} = strtrim(word);
    line = fgetl(fid);
end

fclose(fid);

end