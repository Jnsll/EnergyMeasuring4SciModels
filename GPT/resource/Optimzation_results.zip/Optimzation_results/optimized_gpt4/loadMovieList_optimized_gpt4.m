function movieList = loadMovieList()
%LOADMOVIELIST reads the fixed movie list in movie_ids.txt and returns a
%cell array of the movie names.
%   movieList = LOADMOVIELIST() reads the fixed movie list in movie_ids.txt 
%   and returns a cell array of the movie names in movieList.

% Open the file
fid = fopen('movie_ids.txt');

% Verify if the file opened successfully
if fid == -1
    error('Could not open the file movie_ids.txt');
end

% Initialize an empty cell array to store movie names
movieList = {};

% Read the file line by line and store movie names in movieList
tline = fgetl(fid);
while ischar(tline)
    % Extract the movie name from the line
    [~, movieName] = strtok(tline, ' ');
    movieList{end+1} = strtrim(movieName);
    tline = fgetl(fid);
end

% Close the file
fclose(fid);

end