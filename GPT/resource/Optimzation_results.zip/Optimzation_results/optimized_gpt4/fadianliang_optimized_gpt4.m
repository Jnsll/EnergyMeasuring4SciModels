clear; clc;

% Read data from Excel files
fushe = xlsread('cumcm.xls', 'sheet', 'E4:K8763');
dianban = xlsread('cumcm.xls', 'sheet1', 'B1:F24');

% Constants
P = 52.5; % ��������
p0 = 30; % ���ǿ�ȣ�������ྦྷ��Ϊ80����ĤΪ30

% Vectorized operation to replace nested loops
fushe(fushe < p0) = 0;

% Calculate total energy
Q = sum(fushe * P / 1000, 1) / 1000;

% Extract specific values
shuiping = Q(1);
dong = Q(4);
nan = Q(5);
xi = Q(6);
bei = Q(7);

% Display results
fprintf('shuiping: %.2f\n', shuiping);
fprintf('dong: %.2f\n', dong);
fprintf('nan: %.2f\n', nan);
fprintf('xi: %.2f\n', xi);
fprintf('bei: %.2f\n', bei);