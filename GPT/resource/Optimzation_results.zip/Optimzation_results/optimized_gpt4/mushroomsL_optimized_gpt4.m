% Load the data and transpose it
load -ascii mushrooms.dat
mushroomsD = mushrooms';
clear mushrooms

% Get the size of the data matrix
[N, m] = size(mushroomsD);
class = 1;

% Replace unique values with sequential integers for each node
for node = 1:N
    unique_vals = unique(mushroomsD(node,:));
    unique_vals(unique_vals == -9999) = [];
    for val = 1:length(unique_vals)
        mushroomsD(node, mushroomsD(node,:) == unique_vals(val)) = val;
    end
end

% Remove rows where all values are the same
ns = max(mushroomsD, [], 2);
seul = find(ns == 1);
mushroomsD(seul, :) = [];
[N, m] = size(mushroomsD);
ns = max(mushroomsD, [], 2);

% Partition the data into training and testing sets
Napp = ceil(m * 2 / 3);
Ntest = m - Napp;

app = mushroomsD(:, 1:Napp);
test = mushroomsD(:, Napp + 1:end);

% Display the unique values in the class column of training and testing sets
unique(app(class, :))
unique(test(class, :))

% Clear unnecessary variables
clear seul unique_vals node val