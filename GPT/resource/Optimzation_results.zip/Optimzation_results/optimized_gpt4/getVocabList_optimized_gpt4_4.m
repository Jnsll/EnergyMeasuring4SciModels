function vocabList = getVocabList()
%GETVOCABLIST reads the fixed vocabulary list in vocab.txt and returns a
%cell array of the words
%   vocabList = GETVOCABLIST() reads the fixed vocabulary list in vocab.txt 
%   and returns a cell array of the words in vocabList.

%% Read the fixed vocabulary list
fid = fopen('vocab.txt');

% Check if file opened successfully
if fid == -1
    error('Cannot open vocab.txt');
end

% Initialize an empty cell array
vocabList = {};

% Read the file line by line
line = fgetl(fid);
while ischar(line)
    % Split the line by spaces
    parts = strsplit(line, ' ');
    % Append the word (second part) to the vocabList
    vocabList{end+1} = parts{2}; 
    line = fgetl(fid);
end

fclose(fid);

end