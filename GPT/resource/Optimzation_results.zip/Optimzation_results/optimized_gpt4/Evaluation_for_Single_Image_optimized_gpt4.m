clc
clear all

easy = 1; % easy=1 for testing: EN, SF, SD, PSNR, MSE, MI, VIF, AG, CC, SCD, Qabf; easy=0 for testing: Nabf, SSIM, MS_SSIM, FMI_pixel, FMI_dct, FMI_w
source_image_name1 = '..\Image\Source-Image\TNO\ir\01.png';
source_image_name2 = '..\Image\Source-Image\TNO\vi\01.png';
fused_image_name = '..\Image\Algorithm\SeAFusion_TNO\01.png';

ir_image = imread(source_image_name1);
vi_image = imread(source_image_name2);
fused_image = imread(fused_image_name);

% Convert images to grayscale if they are RGB
ir_image = convert_to_grayscale(ir_image);
vi_image = convert_to_grayscale(vi_image);
fused_image = convert_to_grayscale(fused_image);

% Check if images are 2D
if is_2d_image(ir_image) && is_2d_image(vi_image)
    [EN, SF, SD, PSNR, MSE, MI, VIF, AG, CC, SCD, Qabf, Nabf, SSIM, MS_SSIM, FMI_pixel, FMI_dct, FMI_w] = analysis_Reference(fused_image, ir_image, vi_image, easy);
    display_results(easy, EN, SF, SD, PSNR, MSE, MI, VIF, AG, CC, SCD, Qabf, Nabf, SSIM, MS_SSIM, FMI_pixel, FMI_dct, FMI_w);
else
    disp('unsuccessful!')
end

function img = convert_to_grayscale(img)
    if size(img, 3) > 2
        img = rgb2gray(img);
    end
end

function is_2d = is_2d_image(img)
    is_2d = length(size(img)) < 3;
end

function display_results(easy, EN, SF, SD, PSNR, MSE, MI, VIF, AG, CC, SCD, Qabf, Nabf, SSIM, MS_SSIM, FMI_pixel, FMI_dct, FMI_w)
    if easy == 1
        fprintf('EN = %.4f\n', EN)
        fprintf('MI = %.4f\n', MI)
        fprintf('SD = %.4f\n', SD)
        fprintf('SF = %.4f\n', SF)
        fprintf('MSE = %.4f\n', MSE)
        fprintf('PSNR = %.4f\n', PSNR)        
        fprintf('VIF = %.4f\n', VIF)
        fprintf('AG = %.4f\n', AG)
        fprintf('SCD = %.4f\n', SCD)
        fprintf('CC = %.4f\n', CC)
        fprintf('Qabf = %.4f\n', Qabf)
    else
        fprintf('Nabf = %.4f\n', Nabf)
        fprintf('SSIM = %.4f\n', SSIM)
        fprintf('MS_SSIM = %.4f\n', MS_SSIM)
        fprintf('FMI_pixel = %.4f\n', FMI_pixel)
        fprintf('FMI_dct = %.4f\n', FMI_dct)
        fprintf('FMI_w = %.4f\n', FMI_w)
    end
end