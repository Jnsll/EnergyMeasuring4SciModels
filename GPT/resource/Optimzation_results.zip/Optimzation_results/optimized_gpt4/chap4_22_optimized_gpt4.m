close all;  % Close all figure windows
clear;      % Clear workspace variables
clc;        % Clear command window

% Read input images
I = imread('trees.tif');
I1 = imread('lenna.bmp');

% Transpose images
J1 = I.';
J2 = I1.';

% Set default properties for figures
set(0, 'defaultFigurePosition', [100, 100, 1000, 500]);
set(0, 'defaultFigureColor', [1 1 1]);

% Display images
figure;
subplot(1, 2, 1), imshow(J1);
subplot(1, 2, 2), imshow(J2);