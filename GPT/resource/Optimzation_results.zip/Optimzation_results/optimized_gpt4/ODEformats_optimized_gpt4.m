% Setting default properties for figures and axes
set(0, 'DefaultAxesXGrid', 'on', ...
       'DefaultAxesYGrid', 'on', ...
       'defaultfigureposition', [380 320 540 200], ...
       'defaultaxeslinewidth', 0.7, ...
       'defaultaxesfontsize', 7, ...
       'defaultlinelinewidth', 0.9, ...
       'defaultpatchlinewidth', 0.9, ...
       'defaultlinemarkersize', 15, ...
       'defaultaxesfontweight', 'normal', ...
       'defaulttextinterpreter', 'latex');

% Formatting
format compact
format short

% Setting default preferences for Chebfun
chebfunpref.setDefaults('factory');

% Defining constants for plot properties
FS = 'fontsize'; LW = 'linewidth'; MS = 'markersize'; CO = 'color';
IN = 'interpret'; LT = 'latex';
XT = 'xtick'; YT = 'ytick';
XTL = 'xticklabel'; YTL = 'yticklabel';
LO = 'location'; NE = 'northeast'; NO = 'north';
HA = 'HorizontalAlignment'; CT = 'center'; RT = 'right';
FN = 'fontname'; YS = 'ystretch'; LS = 'linestyle';

% Defining color constants
purple = [.8 0 1]; 
green = [.466 .674 0]; 
blue = [0 .447 .741];
ivp = [.466 .674 0]; 
ivpnl = [.23 .34 0];
bvp = [0 .447 .741]; 
bvpnl = [0 .23 .37];
ibvp = [1 .5 0]; 
ibvp0 = .6 * ibvp;