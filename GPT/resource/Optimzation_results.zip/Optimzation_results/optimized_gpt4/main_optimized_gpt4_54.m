% Clear command window and memory
clear;
clc;

N = 20;  % Number of cities
M = N - 1;  % Number of population

% Generate city coordinates
pos = randn(N, 2);

% Preallocate city distance matrix
D = squareform(pdist(pos));

% Parameters
pCharChange = 1;  % Character swap probability
pStrChange = 0.4;  % String shift probability
pStrReverse = 0.4;  % String reverse probability
pCharReCompose = 0.4;  % Character recomposition probability
MaxIterateNum = 100;  % Maximum iteration number

% Initialize population
mPopulation = zeros(M, N);
for rol = 1:M
    mPopulation(rol, :) = randperm(N);  % Generate initial antibodies
    mPopulation(rol, :) = DisplaceInit(mPopulation(rol, :));  % Preprocess
end

% Iteration
count = 0;
TmpResult = [];
TmpResult1 = [];
figure(2);
while count < MaxIterateNum
    % Generate new antibodies
    B = Mutation(mPopulation, [pCharChange, pStrChange, pStrReverse, pCharReCompose]);
    mPopulation = SelectAntigen(mPopulation, B);
    
    % Plot and display results
    hold on;
    plot(count, TmpResult(end), 'o');
    drawnow;
    display(TmpResult(end));
    display(TmpResult1(end));
    
    best_pop(count + 1, :) = mPopulation(1, :);
    count = count + 1;
end

% Plot results
hold on;
plot(TmpResult, '-r');
title('Best Fitness Trend');
xlabel('Iteration');
ylabel('Best Fitness');
figure(1);
DrawRouteGif(pos, best_pop);