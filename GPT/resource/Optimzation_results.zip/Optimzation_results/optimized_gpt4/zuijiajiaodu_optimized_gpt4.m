clear; clc;
fushe = xlsread('cumcm.xls', 'sheet', 'E4:K8763');
dc = xlsread('cumcm.xls', 'sheet1', 'B1:J24');
sp_zs = fushe(:,1) - fushe(:,2);
n_zs = fushe(:,5) - 0.5 * fushe(:,2);
d_zs = fushe(:,4) - 0.5 * fushe(:,2);
x_zs = fushe(:,6) - 0.5 * fushe(:,2);
fdl = [];

% Precompute constants outside the loop
i = 91;
a = (i - 1) * pi / 180;
sa = sin(a);
ca = cos(a);

S = zeros(12, 181);  % Preallocate S for efficiency

for j = 1:181
    b = (j - 91) * pi / 180;
    sb = sin(b);
    cb = cos(b);
    
    if sb < 0
        fushe_ry = -d_zs * sa * sb + n_zs * sa * cb + sp_zs * ca + fushe(:,2) * (pi - a) / pi;
    else
        fushe_ry = x_zs * sa * sb + n_zs * sa * cb + sp_zs * ca + fushe(:,2) * (pi - a) / pi;
    end
    
    % Compute monthly generation in a loop
    for month = 1:12
        start_idx = (month - 1) * 744 + 1;
        end_idx = min(month * 744, length(fushe_ry));
        S(month, j) = sum(fushe_ry(start_idx:end_idx));
    end
end

x = 1:181;
plot(x, S);

% [x, y] = find(S == max(max(S)));